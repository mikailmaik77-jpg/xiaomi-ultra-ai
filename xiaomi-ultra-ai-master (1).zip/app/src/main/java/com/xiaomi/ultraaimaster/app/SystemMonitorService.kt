package com.xiaomi.ultraaimaster.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat

class SystemMonitorService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private val channelId = "xiaomi_monitor_service_channel"
    private val notificationId = 8888

    private val monitorRunnable = object : Runnable {
        override fun run() {
            checkSystemStatus()
            // Check every 15 seconds to be extremely battery-efficient
            handler.postDelayed(this, 15000)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = createServiceNotification("Xiaomi AI Master Active", "مراقبة حرارة المعالج وصحة البطارية نشطة بالخلفية.")
        startForeground(notificationId, notification)

        // Start periodic monitoring
        handler.post(monitorRunnable)

        return START_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacks(monitorRunnable)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    private fun checkSystemStatus() {
        try {
            val batteryStatus: Intent? = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val temp: Int = batteryStatus?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0
            val tempC = temp.toFloat() / 10f
            val level = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1

            // If temperature is too high (> 42°C), send alert
            if (tempC > 42.0f) {
                sendAlertNotification(
                    "تحذير: ارتفاع حرارة الجهاز! 🔥",
                    "وصلت حرارة معالج Snapdragon إلى ${tempC}°م. يرجى تفعيل التبريد الفائق."
                )
            }

            // If battery is low (< 15%), send alert
            if (level in 1..15) {
                sendAlertNotification(
                    "تحذير: طاقة منخفضة ⚠️",
                    "مستوى البطارية الحالي ${level}%. يرجى توصيل شاحن Xiaomi بقوة 120 واط."
                )
            }

            // Update persistent foreground notification with actual current temperature and battery
            val updatedNotification = createServiceNotification(
                "Xiaomi Active Guard",
                "حرارة البطارية: ${tempC}°م | مستوى الطاقة: ${level}%"
            )
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.notify(notificationId, updatedNotification)

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val serviceChannel = NotificationChannel(
                channelId,
                "Xiaomi Active System Monitor",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Background optimization and battery temperature guard service"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(serviceChannel)
        }
    }

    private fun createServiceNotification(title: String, content: String): Notification {
        val notificationIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            notificationIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, channelId)
            .setContentTitle(title)
            .setContentText(content)
            .setSmallIcon(android.R.drawable.ic_lock_idle_low_battery)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    private fun sendAlertNotification(title: String, message: String) {
        val alertChannelId = "xiaomi_ultra_master_channel"
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(this, alertChannelId)
            .setSmallIcon(android.R.drawable.stat_sys_warning)
            .setContentTitle(title)
            .setContentText(message)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setDefaults(NotificationCompat.DEFAULT_ALL)

        notificationManager.notify(System.currentTimeMillis().toInt(), builder.build())
    }
}
