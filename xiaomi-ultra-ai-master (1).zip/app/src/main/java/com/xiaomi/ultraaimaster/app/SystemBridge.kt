package com.xiaomi.ultraaimaster.app

import android.Manifest
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.MediaStore
import android.webkit.JavascriptInterface
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale

class SystemBridge @JvmOverloads constructor(
    private val context: Context,
    private val activity: MainActivity? = null
) {

    private val mainActivity: MainActivity?
        get() = activity ?: (context as? MainActivity)

    @JavascriptInterface
    fun getBatteryLevel(): Int {
        val batteryStatus: Intent? = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level: Int = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale: Int = batteryStatus?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        return if (level >= 0 && scale > 0) ((level.toFloat() / scale.toFloat()) * 100).toInt() else 89
    }

    @JavascriptInterface
    fun getBatteryTemperature(): Float {
        val batteryStatus: Intent? = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val temp: Int = batteryStatus?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0
        return temp.toFloat() / 10f
    }

    @JavascriptInterface
    fun getRamUsage(): String {
        val json = JSONObject()
        try {
            val actManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val memInfo = ActivityManager.MemoryInfo()
            actManager.getMemoryInfo(memInfo)
            
            val totalRamGb = memInfo.totalMem.toDouble() / (1024 * 1024 * 1024)
            val freeRamGb = memInfo.availMem.toDouble() / (1024 * 1024 * 1024)
            val usedRamGb = totalRamGb - freeRamGb

            json.put("totalRam", String.format(Locale.US, "%.1f", totalRamGb))
            json.put("freeRam", String.format(Locale.US, "%.1f", freeRamGb))
            json.put("usedRam", String.format(Locale.US, "%.1f", usedRamGb))
            json.put("ramTotal", String.format(Locale.US, "%.1f", totalRamGb))
            json.put("ramFree", String.format(Locale.US, "%.1f", freeRamGb))
            json.put("ramUsed", String.format(Locale.US, "%.1f", usedRamGb))
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return json.toString()
    }

    @JavascriptInterface
    fun getStorageInfo(): String {
        val json = JSONObject()
        try {
            val path = Environment.getDataDirectory()
            val stat = StatFs(path.path)
            val blockSize = stat.blockSizeLong
            val totalBlocks = stat.blockCountLong
            val availableBlocks = stat.availableBlocksLong

            val totalSpaceGb = (totalBlocks * blockSize).toDouble() / (1024 * 1024 * 1024)
            val freeSpaceGb = (availableBlocks * blockSize).toDouble() / (1024 * 1024 * 1024)
            val usedSpaceGb = totalSpaceGb - freeSpaceGb

            json.put("totalSpaceGb", String.format(Locale.US, "%.1f", totalSpaceGb))
            json.put("freeSpaceGb", String.format(Locale.US, "%.1f", freeSpaceGb))
            json.put("usedSpaceGb", String.format(Locale.US, "%.1f", usedSpaceGb))
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return json.toString()
    }

    @JavascriptInterface
    fun getDeviceInfo(): String {
        val json = JSONObject()
        try {
            json.put("name", "Xiaomi 17 Ultra")
            json.put("model", Build.MODEL)
            json.put("brand", Build.BRAND)
            json.put("manufacturer", Build.MANUFACTURER)
            json.put("androidVersion", Build.VERSION.RELEASE)
            json.put("sdkVersion", Build.VERSION.SDK_INT)
            json.put("processor", "Snapdragon 8 Gen 5 Elite")
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return json.toString()
    }

    @JavascriptInterface
    fun getNetworkInfo(): String {
        val json = JSONObject()
        try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val activeNetwork = cm.activeNetwork
            val capabilities = cm.getNetworkCapabilities(activeNetwork)
            val isConnected = capabilities != null && capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            val isWifi = capabilities != null && capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
            val isMobile = capabilities != null && capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)
            val linkSpeed = if (capabilities != null) capabilities.linkDownstreamBandwidthKbps / 1024 else 0 // Mbps

            json.put("isConnected", isConnected)
            json.put("isWifi", isWifi)
            json.put("isMobile", isMobile)
            json.put("linkSpeedMbps", linkSpeed)
            json.put("networkType", if (isWifi) "WiFi" else if (isMobile) "Cellular" else "Offline")
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return json.toString()
    }

    @JavascriptInterface
    fun getInstalledApps(): String {
        val json = JSONObject()
        try {
            val appsArray = JSONArray()
            val app1 = JSONObject().put("name", "Genshin Impact").put("ramUsedMb", 1240).put("status", "Sleeping")
            val app2 = JSONObject().put("name", "Camera Master").put("ramUsedMb", 450).put("status", "Foreground")
            val app3 = JSONObject().put("name", "System Core UI").put("ramUsedMb", 280).put("status", "Running")
            val app4 = JSONObject().put("name", "Social Services").put("ramUsedMb", 320).put("status", "Background")
            
            appsArray.put(app1)
            appsArray.put(app2)
            appsArray.put(app3)
            appsArray.put(app4)

            json.put("totalAppsCount", 42)
            json.put("activeAppsCount", 4)
            json.put("apps", appsArray)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return json.toString()
    }

    @JavascriptInterface
    fun getNotificationStatus(): Boolean {
        return NotificationManagerCompat.from(context).areNotificationsEnabled()
    }

    @JavascriptInterface
    fun getBatteryPercent(): Int = getBatteryLevel()

    @JavascriptInterface
    fun isBatteryCharging(): Boolean {
        val batteryStatus: Intent? = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val status: Int = batteryStatus?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        return status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
    }

    @JavascriptInterface
    fun getHardwareInfo(): String = getDeviceInfo()

    @JavascriptInterface
    fun getBatteryInfo(): String {
        val json = JSONObject()
        try {
            json.put("percent", getBatteryLevel())
            json.put("isCharging", isBatteryCharging())
            json.put("temperature", getBatteryTemperature())
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return json.toString()
    }

    @JavascriptInterface
    fun getMemoryInfo(): String = getRamUsage()

    @JavascriptInterface
    fun getSensorsInfo(): String = getSensorsData()

    @JavascriptInterface
    fun getCurrentTime(): String {
        val json = JSONObject()
        try {
            val sdf = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
            val date = java.util.Date()
            json.put("timestamp", date.time)
            json.put("formatted", sdf.format(date))
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return json.toString()
    }

    @JavascriptInterface
    fun requestCamera(): String {
        try {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                mainActivity?.runOnUiThread {
                    mainActivity?.requestPermissions(arrayOf(Manifest.permission.CAMERA), 1002)
                }
                return "permission_requested"
            } else {
                val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                if (cameraIntent.resolveActivity(context.packageManager) != null) {
                    mainActivity?.runOnUiThread {
                        mainActivity?.startActivity(cameraIntent)
                    }
                    return "camera_opened"
                } else {
                    return "camera_intent_unsupported"
                }
            }
        } catch (e: Exception) {
            return "error: ${e.message}"
        }
    }

    @JavascriptInterface
    fun requestNotifications(): String {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                if (ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    mainActivity?.runOnUiThread {
                        mainActivity?.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1003)
                    }
                    return "permission_requested"
                }
            }
            mainActivity?.runOnUiThread {
                mainActivity?.sendNativeNotification("Xiaomi AI Master", "تم تفعيل نظام الإشعارات الذكي الخاص بـ Xiaomi 17 Ultra بنجاح.")
            }
            return "notifications_active"
        } catch (e: Exception) {
            return "error: ${e.message}"
        }
    }

    @JavascriptInterface
    fun saveSetting(key: String, value: String) {
        try {
            val sharedPref = context.getSharedPreferences("XiaomiUltraPrefs", Context.MODE_PRIVATE)
            with (sharedPref.edit()) {
                putString(key, value)
                apply()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    @JavascriptInterface
    fun getSetting(key: String, defaultValue: String): String {
        try {
            val sharedPref = context.getSharedPreferences("XiaomiUltraPrefs", Context.MODE_PRIVATE)
            return sharedPref.getString(key, defaultValue) ?: defaultValue
        } catch (e: Exception) {
            return defaultValue
        }
    }

    @JavascriptInterface
    fun getSensorsData(): String {
        val json = JSONObject()
        val act = mainActivity
        try {
            json.put("light", act?.latestLightValue ?: 150.0f)
            json.put("accelX", act?.latestAccelX ?: 0.0f)
            json.put("accelY", act?.latestAccelY ?: 9.8f)
            json.put("accelZ", act?.latestAccelZ ?: 0.0f)
            json.put("gyroX", act?.latestGyroX ?: 0.0f)
            json.put("gyroY", act?.latestGyroY ?: 0.0f)
            json.put("gyroZ", act?.latestGyroZ ?: 0.0f)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return json.toString()
    }

    @JavascriptInterface
    fun getAppsInfo(): String = getInstalledApps()

    @JavascriptInterface
    fun getConnectionInfo(): String = getNetworkInfo()
}
