import fs from 'fs';
import path from 'path';

function copyDir(src, dest) {
  fs.mkdirSync(dest, { recursive: true });
  const entries = fs.readdirSync(src, { withFileTypes: true });

  for (const entry of entries) {
    const srcPath = path.join(src, entry.name);
    const destPath = path.join(dest, entry.name);

    if (entry.isDirectory()) {
      copyDir(srcPath, destPath);
    } else {
      fs.copyFileSync(srcPath, destPath);
    }
  }
}

const srcDir = path.join(process.cwd(), 'dist');
const destDir = path.join(process.cwd(), 'app', 'src', 'main', 'assets');

console.log(`Copying web build from ${srcDir} to ${destDir}...`);
if (fs.existsSync(srcDir)) {
  // Clear dest directory first to prevent stale files
  if (fs.existsSync(destDir)) {
    fs.rmSync(destDir, { recursive: true, force: true });
  }
  copyDir(srcDir, destDir);
  console.log('Web build copied successfully to Android assets!');
} else {
  console.error('Error: dist/ directory does not exist. Run vite build first.');
  process.exit(1);
}
