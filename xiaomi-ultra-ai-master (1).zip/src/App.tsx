import React, { useState, useEffect } from 'react';
import { 
  Camera, 
  Cpu, 
  Gamepad2, 
  Bot, 
  Globe, 
  Sparkles, 
  Thermometer, 
  Battery, 
  Info, 
  Layers, 
  Wifi, 
  CheckCircle,
  BellRing,
  Smartphone,
  RefreshCw,
  ShieldCheck,
  Trash2,
  Flame,
  ArrowRight,
  Sliders
} from 'lucide-react';
import CameraStudio from './components/CameraStudio';
import PhoneOptimizer from './components/PhoneOptimizer';
import GameBooster from './components/GameBooster';
import PersonalAssistant from './components/PersonalAssistant';
import Settings from './components/Settings';
import SplashScreen from './components/SplashScreen';

const translations = {
  ar: {
    appTitle: 'Xiaomi Ultra AI Master',
    appSubtitle: 'لوحة التحكم الفائقة والمستشار الذكي لهاتف Xiaomi Ultra',
    tempTitle: 'حرارة المعالج (SoC)',
    batteryTitle: 'البطارية والشحن',
    cpuTitle: 'أداء المعالجة',
    cameraTitle: 'حالة مستشعر Leica',
    tabCamera: 'AI Camera Studio',
    tabOptimizer: 'Phone Optimizer',
    tabBooster: 'AI Game Booster',
    tabAssistant: 'AI Assistant',
    tabSettings: 'الإعدادات والمحاذاة',
    activeAperture: 'الفتحة النشطة',
    balancedProfile: 'الوضع المتوازن',
    perfProfile: 'الأداء الفائق',
    batteryDischarging: 'تفريغ ذكي مستمر',
    leicaActive: 'مستشعر 1-inch Leica نشط',
    controlPanel: 'لوحة التحكم المركزية بالهاتف',
    activeTabIndicator: 'القسم المفتوح حالياً',
    langToggle: 'عربي / English'
  },
  en: {
    appTitle: 'Xiaomi Ultra AI Master',
    appSubtitle: 'Ultimate Control Center & Computational Companion for Xiaomi Ultra',
    tempTitle: 'SoC Thermals',
    batteryTitle: 'Battery & 120W Charge',
    cpuTitle: 'CPU Core Operations',
    cameraTitle: 'Leica Sensor Status',
    tabCamera: 'AI Camera Studio',
    tabOptimizer: 'Phone Optimizer',
    tabBooster: 'AI Game Booster',
    tabAssistant: 'AI Personal Assistant',
    tabSettings: 'System Settings',
    activeAperture: 'Active Aperture',
    balancedProfile: 'Balanced Mode',
    perfProfile: 'Performance Boost',
    batteryDischarging: 'Optimal Discharging',
    leicaActive: 'Leica 1-inch Sensor Ready',
    controlPanel: 'Unified Phone HUD & Control Center',
    activeTabIndicator: 'Currently Administering Slot',
    langToggle: 'English / عربي'
  }
};

interface Notification {
  id: string;
  text: string;
  type: 'success' | 'error';
}

export default function App() {
  const [lang, setLang] = useState<'ar' | 'en'>(() => {
    try {
      const stored = localStorage.getItem('lang');
      if (stored === 'ar' || stored === 'en') return stored;
    } catch (e) {}
    return 'ar';
  });
  const [activeTab, setActiveTab] = useState<'camera' | 'optimizer' | 'game' | 'assistant' | 'settings'>('optimizer');
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [showSplash, setShowSplash] = useState<boolean>(true);

  // Sync initial language with local settings stored in SharedPreferences
  useEffect(() => {
    try {
      const bridge = (window as any).AndroidBridge || (window as any).AndroidSystem;
      if (bridge && typeof bridge.getSetting === 'function') {
        const savedLang = bridge.getSetting("lang", "ar");
        if (savedLang === "ar" || savedLang === "en") {
          setLang(savedLang);
        }
      }
    } catch (e) {
      console.warn("Could not load setting lang:", e);
    }
  }, []);
  const [showWelcome, setShowWelcome] = useState<boolean>(true);

  const welcomeTexts = {
    ar: {
      title: "مرحباً بك في لوحة تحكم Xiaomi 17 Ultra",
      subtitle: "المساعد الحوسبي ونظام المعايرة والضبط الفائق بالذات الاصطناعي",
      badge: "الإصدار النخبوي الفائق",
      intro: "تم تصميم هذا النظام الذكي لمراقبة ومعايرة خصائص جهاز Xiaomi Ultra بأعلى المعايير البصرية والهندسية. استكشف القوة الكاملة لعتاد جهازك:",
      feat1: "استوديو الكاميرا الاحترافي Leica Studio",
      feat1Desc: "اختبار معايير ألوان Leica، وضبط البعد البؤري وفتحة العدسة الديناميكية، بالإضافة للمعاينة الحية وتثبيت الاهتزاز والالتقاط الليلي فائق النقاء.",
      feat2: "منظف ومحسن الأداء الذكي Optimizer",
      feat2Desc: "تنظيف الذاكرة المؤقتة LPDDR5X، وتقليل الضغط على طاقة المعالج، وتفريغ كتل التخزين UFS لتجربة تصفح سريعة وخالية من التباطؤ.",
      feat3: "مسرع الألعاب المتقدم Booster",
      feat3Desc: "تفعيل خوارزمية WildBoost الفائقة، وزيادة استقرار الإطارات FPS، والتحكم في توزيع الموارد ومراقبة الحرارة لتجنب الاختناق الحراري.",
      feat4: "مساعد الذكاء الاصطناعي الهجين Chat Assistant",
      feat4Desc: "مستشار تقني مدمج للإجابة الفورية عن تساؤلاتك حول إمكانيات الكاميرا وصحة البطارية ومستوى تبريد النظام باللغتين العربية والإنجليزية.",
      action: "ابدأ تشغيل لوحة التحكم",
      langSwitch: "English / الإنجليزية"
    },
    en: {
      title: "Welcome to Xiaomi 17 Ultra Center",
      subtitle: "The Ultimate Computational Dashboard & Intelligent Hardware Tuning Companion",
      badge: "Elite Master Edition",
      intro: "This advanced diagnostic system is engineered to supervise, calibrate and unlock your Xiaomi Ultra device characteristics. Explore its flagship systems:",
      feat1: "Leica Camera Studio Pro",
      feat1Desc: "Simulate dual-lens presets, Leica Authentic/Vibrant colors, adjust dynamic apertures, night vision integration, and gyro tracking.",
      feat2: "Deep Phone Optimizer Engine",
      feat2Desc: "Purge LPDDR5X memory logs, monitor battery health, calibrate copper-chamber heat dissipation, and optimize UFS storage streams.",
      feat3: "WildBoost Advanced Game Booster",
      feat3Desc: "Lock WildBoost system threads, control active frame-rate (FPS) caps, analyze thermal throttling, and maximize core stability under load.",
      feat4: "AI Hybrid Personal Advisor",
      feat4Desc: "An integrated technical advisor prepared to chat and give immediate recommendations regarding sensor calibrations and overall device status.",
      action: "Launch Control Center",
      langSwitch: "العربية / Arabic"
    }
  };

  const w = welcomeTexts[lang];
  
  // Optimization report states
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [optimizationLogged, setOptimizationLogged] = useState(false);
  const [optimizationPhase, setOptimizationPhase] = useState('');
  const [report, setReport] = useState<{
    tempBefore: number; tempAfter: number;
    ramBefore: number; ramAfter: number;
    junkBefore: string; junkAfter: string;
    leicaBefore: string; leicaAfter: string;
    pingBefore: number; pingAfter: number;
  } | null>(null);

  // HUD Telemetry states (Shared metrics)
  const [telemetry, setTelemetry] = useState({
    temperature: 37,
    battery: 89,
    isCharging: false,
    cpuLoad: 24,
    wifiSignal: 'Excellent',
    cameraStatus: 'Leica f/1.4 Ready'
  });

  const t = translations[lang === 'en' ? 'en' : 'ar'];

  // Helper notification dispatcher
  const triggerNotification = (text: string, type: 'success' | 'error' = 'success') => {
    const newNotif = {
      id: `notif-${Date.now()}`,
      text,
      type
    };
    setNotifications((prev) => [newNotif, ...prev]);
    setTimeout(() => {
      setNotifications((prev) => prev.filter(n => n.id !== newNotif.id))
    }, 4500);

    // Trigger real Android Native Notification if bridge is available
    try {
      const bridge = (window as any).AndroidSystem || (window as any).AndroidBridge;
      if (bridge && typeof bridge.showAndroidNotification === 'function') {
        bridge.showAndroidNotification("Xiaomi AI Master", text);
      }
    } catch (e) {
      console.warn("AndroidBridge notification failed:", e);
    }
  };

  const startFullOptimization = () => {
    setIsOptimizing(true);
    setOptimizationLogged(false);
    setReport(null);
    
    // Simulate steps in sequence
    const phases = [
      lang === 'ar' ? '🔍 فحص وإفراغ الذاكرة العشوائية LPDDR5X وتهيئة الكتل...' : '🔍 Scanning and purging LPDDR5X RAM tables...',
      lang === 'ar' ? '🚽 مسح الملفات المؤقتة وبقايا الكاش لـ 120GB...' : '🚽 Clearing temporary junk and cached residues...',
      lang === 'ar' ? '📷 ضبط المستشعر البصري الذكي للعدسات Leica 1-inch...' : '📷 Aligning optoelectronic elements for Leica...',
      lang === 'ar' ? '🎮 تحسين خيوط نظام معالجة الألعاب بوضع WildBoost...' : '🎮 Organizing game processor threads for WildBoost...',
      lang === 'ar' ? '🥶 تحسين تبريد الهيكل النحاسي وخفض حرارة المعالج...' : '🥶 Calibrating cooling distribution to lower thermals...'
    ];

    let currentStep = 0;
    setOptimizationPhase(phases[0]);

    const interval = setInterval(() => {
      currentStep++;
      if (currentStep < phases.length) {
        setOptimizationPhase(phases[currentStep]);
      } else {
        clearInterval(interval);
        setIsOptimizing(false);
        setOptimizationLogged(true);
        // Set dynamic report metrics
        setReport({
          tempBefore: 43.8, tempAfter: 31.2,
          ramBefore: 4.8, ramAfter: 12.6,
          junkBefore: '8.64 GB', junkAfter: '0 MB',
          leicaBefore: 'Degraded / Blurred', leicaAfter: 'Ultra Stabilized / Raw Sharp',
          pingBefore: 48, pingAfter: 12
        });
        // Improve telemetry values
        setTelemetry(prev => ({
          ...prev,
          temperature: 31.2,
          cpuLoad: 12,
          cameraStatus: 'Leica f/1.4 (Calibrated)'
        }));
        triggerNotification(
          lang === 'ar' ? '✨ تم الانتهاء من فحص وتحسين الهاتف بنجاح!' : '✨ Full master optimization completed successfully!',
          'success'
        );
      }
    }, 1200);
  };

  // Poll real-time system metrics from Android native bridge or simulate if not present
  useEffect(() => {
    const updateMetrics = () => {
      setTelemetry(prev => {
        try {
          const bridge = (window as any).AndroidSystem || (window as any).AndroidBridge;
          if (bridge) {
            let realBattery = prev.battery;
            if (typeof bridge.getBatteryLevel === 'function') {
              const val = bridge.getBatteryLevel();
              const parsedVal = typeof val === 'number' ? val : parseInt(String(val), 10);
              if (!isNaN(parsedVal)) {
                realBattery = parsedVal;
              }
            } else if (typeof bridge.getBatteryPercent === 'function') {
              const val = bridge.getBatteryPercent();
              const parsedVal = typeof val === 'number' ? val : parseInt(String(val), 10);
              if (!isNaN(parsedVal)) {
                realBattery = parsedVal;
              }
            }

            let realTemp = prev.temperature;
            if (typeof bridge.getBatteryTemperature === 'function') {
              const val = bridge.getBatteryTemperature();
              const parsedVal = typeof val === 'number' ? val : parseFloat(String(val));
              if (!isNaN(parsedVal)) {
                realTemp = parsedVal;
              }
            }

            let realCharging = prev.isCharging;
            if (typeof bridge.isBatteryCharging === 'function') {
              const val = bridge.isBatteryCharging();
              realCharging = typeof val === 'boolean' ? val : String(val) === 'true';
            }

            // Generate CPU loads with realistic fluctuations
            const cpuFluctuate = Math.floor(Math.random() * 7) - 3;
            const nextCpu = Math.max(8, Math.min(92, prev.cpuLoad + cpuFluctuate));

            return {
              ...prev,
              battery: realBattery,
              temperature: realTemp,
              isCharging: realCharging,
              cpuLoad: nextCpu
            };
          }
        } catch (e) {
          console.error("Failed to fetch native metrics from AndroidBridge:", e);
        }

        // Fallback simulation
        const chargingOffset = prev.isCharging ? 1 : -0.1;
        const nextBattery = Math.min(100, Math.max(1, prev.battery + chargingOffset));
        const tempFluctuate = Math.floor(Math.random() * 3) - 1;
        const cpuFluctuate = Math.floor(Math.random() * 9) - 4;
        
        return {
          ...prev,
          battery: parseFloat(nextBattery.toFixed(1)),
          temperature: Math.max(28, Math.min(52, prev.temperature + (tempFluctuate * 0.2))),
          cpuLoad: Math.max(4, Math.min(98, prev.cpuLoad + cpuFluctuate))
        };
      });
    };

    // Update every 1500ms for high performance
    const timer = setInterval(updateMetrics, 1500);
    updateMetrics();

    return () => clearInterval(timer);
  }, []);

  const toggleCharging = () => {
    setTelemetry(prev => {
      const nextCharging = !prev.isCharging;
      triggerNotification(
        lang === 'ar' 
          ? (nextCharging ? 'تم ربط الشاحن فائق السرعة الغالي بقوة 120W! الكشف نشط.' : 'تم فصل شاحن الـ HyperOS.') 
          : (nextCharging ? '120W HyperCharge plugged in successfully!' : 'Power adapter unplugged.'),
        'success'
      );
      return {
        ...prev,
        isCharging: nextCharging,
        temperature: nextCharging ? prev.temperature + 2.5 : prev.temperature - 1.5
      };
    });
  };

  if (showSplash) {
    return <SplashScreen lang={lang} onComplete={() => setShowSplash(false)} />;
  }

  return (
    <div 
      className="min-h-screen bg-neutral-950 text-neutral-100 font-sans selection:bg-amber-500 selection:text-neutral-950 flex flex-col relative"
      dir={lang === 'ar' ? 'rtl' : 'ltr'}
    >
      {/* Premium Welcome Modal Overlay */}
      {showWelcome && (
        <div className="fixed inset-0 bg-neutral-950/95 backdrop-blur-xl z-[150] flex items-center justify-center p-4 overflow-y-auto">
          {/* Ambient red and orange light behind */}
          <div className="absolute inset-0 bg-radial-gradient from-red-600/10 via-transparent to-transparent pointer-events-none"></div>
          
          <div className="bg-neutral-900 border border-neutral-800 rounded-3xl max-w-2xl w-full p-6 md:p-8 space-y-6 md:space-y-8 shadow-2xl relative overflow-hidden animate-slide-up max-h-[90vh] flex flex-col justify-between">
            <div className="absolute top-0 right-0 w-32 h-32 bg-red-600/10 rounded-full blur-3xl pointer-events-none"></div>
            <div className="absolute bottom-0 left-0 w-32 h-32 bg-amber-500/10 rounded-full blur-3xl pointer-events-none"></div>

            {/* Language Badge */}
            <div className="flex items-center justify-between border-b border-neutral-800/80 pb-4">
              <span className="text-[10px] font-mono tracking-widest text-red-500 bg-red-500/10 border border-red-500/20 px-2.5 py-1 rounded-full font-bold uppercase">
                {w.badge}
              </span>
            </div>

            {/* Title / Description */}
            <div className="space-y-2 text-center md:text-right">
              <h2 className="text-xl md:text-2xl font-black text-white tracking-tight flex items-center justify-center md:justify-start gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-pulse inline-block"></span>
                {w.title}
              </h2>
              <p className="text-xs text-neutral-400 leading-relaxed">
                {w.subtitle}
              </p>
            </div>

            {/* Features layout list */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 my-2 overflow-y-auto max-h-[40vh] pr-1">
              <div className="bg-neutral-950/60 border border-neutral-850/80 rounded-2xl p-4 flex items-start gap-3 hover:border-neutral-800 transition-colors">
                <div className="w-8 h-8 rounded-lg bg-red-500/10 text-red-400 flex items-center justify-center shrink-0">
                  <Camera className="w-4 h-4" />
                </div>
                <div className="text-right">
                  <h4 className="text-xs font-bold text-neutral-200">{w.feat1}</h4>
                  <p className="text-[10px] text-neutral-500 mt-1 leading-normal">{w.feat1Desc}</p>
                </div>
              </div>

              <div className="bg-neutral-950/60 border border-neutral-850/80 rounded-2xl p-4 flex items-start gap-3 hover:border-neutral-800 transition-colors">
                <div className="w-8 h-8 rounded-lg bg-amber-500/10 text-amber-400 flex items-center justify-center shrink-0">
                  <Cpu className="w-4 h-4" />
                </div>
                <div className="text-right">
                  <h4 className="text-xs font-bold text-neutral-200">{w.feat2}</h4>
                  <p className="text-[10px] text-neutral-500 mt-1 leading-normal">{w.feat2Desc}</p>
                </div>
              </div>

              <div className="bg-neutral-950/60 border border-neutral-850/80 rounded-2xl p-4 flex items-start gap-3 hover:border-neutral-800 transition-colors">
                <div className="w-8 h-8 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center justify-center shrink-0">
                  <Gamepad2 className="w-4 h-4" />
                </div>
                <div className="text-right">
                  <h4 className="text-xs font-bold text-neutral-200">{w.feat3}</h4>
                  <p className="text-[10px] text-neutral-500 mt-1 leading-normal">{w.feat3Desc}</p>
                </div>
              </div>

              <div className="bg-neutral-950/60 border border-neutral-850/80 rounded-2xl p-4 flex items-start gap-3 hover:border-neutral-800 transition-colors">
                <div className="w-8 h-8 rounded-lg bg-cyan-500/10 text-cyan-400 flex items-center justify-center shrink-0">
                  <Bot className="w-4 h-4" />
                </div>
                <div className="text-right">
                  <h4 className="text-xs font-bold text-neutral-200">{w.feat4}</h4>
                  <p className="text-[10px] text-neutral-500 mt-1 leading-normal">{w.feat4Desc}</p>
                </div>
              </div>
            </div>

            {/* Action footer */}
            <div className="border-t border-neutral-800/80 pt-4 flex flex-col sm:flex-row items-center justify-between gap-4">
              <p className="text-[10px] text-neutral-500 text-center sm:text-right">
                Xiaomi Ultra AI Master Control Center Platform. Powered by HyperOS & Leica Optics.
              </p>
              <button
                onClick={() => {
                  setShowWelcome(false);
                  triggerNotification(
                    lang === 'ar' ? '🚀 مرحباً بك! تم تشغيل لوحة التحكم بنجاح.' : '🚀 Welcome! Control center active.',
                    'success'
                  );
                }}
                className="w-full sm:w-auto bg-gradient-to-r from-red-600 to-amber-500 text-white font-bold text-xs py-2.5 px-6 rounded-xl hover:opacity-90 shadow-lg shadow-red-600/10 transition-all flex items-center justify-center gap-2 cursor-pointer group"
              >
                <span>{w.action}</span>
                <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Background neon meshes */}
      <div className="absolute inset-0 bg-neutral-950 pointer-events-none overflow-hidden z-0">
        <div className="absolute top-[-10%] left-[-20%] w-[80%] h-[60%] bg-gradient-to-tr from-red-600/5 to-transparent rounded-full blur-[140px]"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-[60%] h-[50%] bg-gradient-to-tr from-amber-500/5 to-transparent rounded-full blur-[130px]"></div>
      </div>

      {/* STICKY TOP HUD TELEMETRY CONTROLS */}
      <header className="sticky top-0 z-50 bg-neutral-950/80 backdrop-blur-md border-b border-neutral-900 px-4 py-3 select-none">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-red-600 to-amber-500 flex items-center justify-center text-white font-black shadow-lg shadow-red-600/15 ring-2 ring-neutral-900 border border-red-500/30">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-md font-black tracking-tight flex items-center gap-2">
                {t.appTitle}
                <span className="text-[9px] font-mono text-amber-500 bg-amber-500/10 border border-amber-500/20 px-1.5 py-0.5 rounded font-bold uppercase">
                  17 Ultra Master
                </span>
              </h1>
              <p className="text-[10px] text-neutral-500 leading-tight block">
                {t.appSubtitle}
              </p>
            </div>
          </div>

          {/* Quick HUD Rings Deck */}
          <div className="grid grid-cols-2 md:flex items-center gap-3 w-full md:w-auto">
            {/* SoC Thermals widget */}
            <div className="bg-neutral-900/60 border border-neutral-800 rounded-xl px-3 py-1.5 flex items-center gap-2">
              <Thermometer className={`w-4 h-4 ${telemetry.temperature > 40 ? 'text-red-500 animate-pulse' : 'text-emerald-400'}`} />
              <div className="text-right">
                <p className="text-[8px] font-mono text-neutral-500 uppercase">{t.tempTitle}</p>
                <p className="text-xs font-bold font-mono text-neutral-200">
                  {telemetry.temperature.toFixed(1)}°C
                </p>
              </div>
            </div>

            {/* Battery state widget with click to simulate plug */}
            <button 
              onClick={toggleCharging}
              className="bg-neutral-900/60 hover:bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-1.5 flex items-center gap-2 text-right transition-all group cursor-pointer"
              title="Click to simulate connecting 120W HyperCharger"
            >
              <Battery className={`w-4 h-4 ${telemetry.isCharging ? 'text-amber-400 animate-bounce' : 'text-emerald-400'}`} />
              <div>
                <p className="text-[8px] font-mono text-neutral-500 uppercase flex items-center gap-1">
                  {t.batteryTitle}
                  <span className="text-[7px] text-amber-500 font-bold group-hover:underline">🔋 CHARGE</span>
                </p>
                <p className="text-xs font-bold font-mono text-neutral-200">
                  {telemetry.battery}% {telemetry.isCharging && '⚡'}
                </p>
              </div>
            </button>

            {/* CPU Load widget */}
            <div className="bg-neutral-900/60 border border-neutral-800 rounded-xl px-3 py-1.5 flex items-center gap-2">
              <Cpu className="w-4 h-4 text-amber-500" />
              <div className="text-right">
                <p className="text-[8px] font-mono text-neutral-500 uppercase">{t.cpuTitle}</p>
                <p className="text-xs font-bold font-mono text-neutral-200">
                  {telemetry.cpuLoad}%
                </p>
              </div>
            </div>

            {/* Active Camera Lens widget */}
            <div className="bg-neutral-900/60 border border-neutral-800 rounded-xl px-3 py-1.5 flex items-center gap-2">
              <Camera className="w-4 h-4 text-cyan-400" />
              <div className="text-right">
                <p className="text-[8px] font-mono text-neutral-500 uppercase">{t.cameraTitle}</p>
                <p className="text-xs font-bold text-neutral-200">
                  {telemetry.cameraStatus}
                </p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* GLOBAL BANNER / STATS RAIL */}
      <main className="flex-1 w-full max-w-7xl mx-auto px-4 py-6 z-10 space-y-6">
        
        {/* TAB BUTTONS BAR */}
        <section className="bg-neutral-900/40 p-1.5 rounded-2xl border border-neutral-900 grid grid-cols-2 md:flex items-center justify-between gap-1 gap-y-2 select-none">
          <div className="flex flex-col md:flex-row items-stretch md:items-center gap-1.5 w-full">
            {[
              { id: 'optimizer', label: t.tabOptimizer, icon: <Cpu className="w-4 h-4" />, color: 'hover:border-amber-500/40 text-amber-400' },
              { id: 'camera', label: t.tabCamera, icon: <Camera className="w-4 h-4" />, color: 'hover:border-red-500/40 text-red-400' },
              { id: 'game', label: t.tabBooster, icon: <Gamepad2 className="w-4 h-4" />, color: 'hover:border-emerald-500/40 text-emerald-400' },
              { id: 'assistant', label: t.tabAssistant, icon: <Bot className="w-4 h-4" />, color: 'hover:border-cyan-500/40 text-cyan-400' },
              { id: 'settings', label: t.tabSettings, icon: <Sliders className="w-4 h-4" />, color: 'hover:border-purple-500/40 text-purple-400' }
            ].map((tab) => {
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center justify-center gap-2 p-3 text-xs font-bold rounded-xl transition-all border outline-none cursor-pointer ${
                    isActive 
                      ? 'bg-neutral-900 border-neutral-800 text-neutral-100 shadow-xl shadow-black/30 w-full'
                      : 'bg-transparent border-transparent text-neutral-400 hover:bg-neutral-900/30'
                  } ${tab.color}`}
                >
                  {tab.icon}
                  <span>{tab.label}</span>
                  {isActive && (
                    <span className="w-1 h-1 rounded-full bg-amber-500 animate-ping"></span>
                  )}
                </button>
              );
            })}
          </div>
        </section>

        {/* SYSTEM OPTIMIZER CTA & REPORT WIDGET */}
        <section className="bg-gradient-to-br from-neutral-900 via-neutral-900 to-amber-950/20 border border-neutral-800 rounded-3xl p-6 relative overflow-hidden">
          <div className="absolute right-[-10%] top-[-20%] w-[40%] h-[120%] bg-amber-500/5 rounded-full blur-[100px] pointer-events-none"></div>
          
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
            {/* Left side: Action Button or Running status */}
            <div className="lg:col-span-5 flex flex-col items-center justify-center text-center p-4 border border-neutral-800/60 bg-neutral-950/60 rounded-2xl relative min-h-[220px]">
              {isOptimizing ? (
                <div className="space-y-4 py-6 w-full animate-pulse">
                  <div className="relative w-20 h-20 mx-auto flex items-center justify-center">
                    <div className="absolute inset-0 rounded-full border-4 border-amber-500/10 border-t-amber-500 animate-spin"></div>
                    <Sparkles className="w-8 h-8 text-amber-400 animate-bounce" />
                  </div>
                  <div className="space-y-1">
                    <p className="text-xs font-mono text-amber-500 font-extrabold tracking-widest uppercase">
                      HyperOS AI Core tuning
                    </p>
                    <p className="text-xs text-neutral-300 font-semibold px-4 line-clamp-2 h-10">
                      {optimizationPhase}
                    </p>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="relative w-20 h-20 mx-auto group">
                    <div className="absolute inset-0 bg-gradient-to-r from-amber-500 to-red-600 rounded-full blur-md opacity-40 group-hover:opacity-70 transition-opacity duration-300"></div>
                    <button
                      onClick={startFullOptimization}
                      className="absolute inset-0 rounded-full bg-gradient-to-r from-amber-500 to-red-600 hover:from-amber-400 hover:to-red-500 text-neutral-950 font-black text-xs uppercase tracking-wider flex flex-col items-center justify-center shadow-2xl transition-all active:scale-95 cursor-pointer"
                    >
                      <Sparkles className="w-5 h-5 mb-0.5 animate-spin" style={{ animationDuration: '6s' }} />
                      <span className="text-[10px]">{lang === 'ar' ? 'تحسين الآن' : 'OPTIMIZE'}</span>
                    </button>
                  </div>
                  <div className="space-y-1">
                    <h3 className="text-sm font-extrabold text-neutral-200">
                      {lang === 'ar' ? 'كبسة التحسين الفوري الشامل ⚡' : 'One-Touch System Calibration ⚡'}
                    </h3>
                    <p className="text-[11px] text-neutral-500 px-3 max-w-sm leading-relaxed">
                      {lang === 'ar' 
                        ? 'انقر لتشغيل الذكاء الاصطناعي لفحص كاش الملفات، كفاءة مستشعر الكاميرا، وذاكرة الوصول العشوائي ومعدلات الإطارات في اللحظة ذاتها.' 
                        : 'Calibrates Leica sensor matrix, cleans RAM cores, wipes system cache residues, and launches thread balancing.'}
                    </p>
                  </div>
                </div>
              )}
            </div>

            {/* Right side: Report or Intro text */}
            <div className="lg:col-span-7 space-y-4">
              {report ? (
                <div className="space-y-3">
                  <div className="flex items-center justify-between border-b border-neutral-800 pb-2">
                    <h3 className="text-xs font-extrabold text-emerald-400 flex items-center gap-1.5 uppercase tracking-wider">
                      <ShieldCheck className="w-4 h-4 text-emerald-400" />
                      {lang === 'ar' ? 'تقرير كفاءة النظام (قبل وعقب التحسين)' : 'System Efficiency Diagnostics (Before / After)'}
                    </h3>
                    <span className="text-[9px] font-mono text-neutral-500">REPORT_ID: {Math.floor(Math.random() * 900000 + 100000)}</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs font-mono">
                    <div className="bg-neutral-950/80 p-3 rounded-xl border border-neutral-800 flex flex-col justify-between">
                      <span className="text-neutral-500 text-[10px] uppercase block">{lang === 'ar' ? 'الحرارة والمقاومة' : 'Core Thermals'}</span>
                      <div className="flex items-center gap-2 mt-1.5">
                        <span className="text-red-500 line-through font-bold text-[11px]">{report.tempBefore}°C</span>
                        <ArrowRight className="w-3.5 h-3.5 text-neutral-500" />
                        <span className="text-emerald-400 font-black text-sm">{report.tempAfter}°C</span>
                      </div>
                    </div>

                    <div className="bg-neutral-950/80 p-3 rounded-xl border border-neutral-800 flex flex-col justify-between">
                      <span className="text-neutral-500 text-[10px] uppercase block">{lang === 'ar' ? 'الذاكرة العشوائية المستهدفة' : 'Available RAM Pool'}</span>
                      <div className="flex items-center gap-2 mt-1.5">
                        <span className="text-neutral-400 line-through font-semibold text-[11px]">{report.ramBefore} GB</span>
                        <ArrowRight className="w-3.5 h-3.5 text-neutral-500" />
                        <span className="text-cyan-400 font-extrabold text-sm">{report.ramAfter} GB</span>
                      </div>
                    </div>

                    <div className="bg-neutral-950/80 p-3 rounded-xl border border-neutral-800 flex flex-col justify-between">
                      <span className="text-neutral-500 text-[10px] uppercase block">{lang === 'ar' ? 'ملفات الكاش والمؤقتات' : 'Junk & Cache Residual'}</span>
                      <div className="flex items-center gap-2 mt-1.5">
                        <span className="text-red-400 line-through font-semibold text-[11px]">{report.junkBefore}</span>
                        <ArrowRight className="w-3.5 h-3.5 text-neutral-500" />
                        <span className="text-emerald-400 font-black text-sm">{report.junkAfter}</span>
                      </div>
                    </div>

                    <div className="bg-neutral-950/80 p-3 rounded-xl border border-neutral-800 flex flex-col justify-between">
                      <span className="text-neutral-500 text-[10px] uppercase block">{lang === 'ar' ? 'زمن استجابة الشبكة (Ping)' : 'Cellular Latency (Ping)'}</span>
                      <div className="flex items-center gap-2 mt-1.5">
                        <span className="text-amber-500 line-through font-semibold text-[11px]">{report.pingBefore} ms</span>
                        <ArrowRight className="w-3.5 h-3.5 text-neutral-500" />
                        <span className="text-emerald-400 font-black text-sm">{report.pingAfter} ms</span>
                      </div>
                    </div>
                  </div>

                  <div className="bg-emerald-950/20 border border-emerald-500/20 p-2.5 rounded-xl flex items-center justify-between">
                    <div className="flex items-center gap-2 text-[10px] text-emerald-300">
                      <ShieldCheck className="w-4 h-4 text-emerald-400" />
                      <span>{lang === 'ar' ? 'تم ضبط حساسية العدسات ومستشعر Leica بنجاح.' : 'Leica alignment calibrated successfully.'}</span>
                    </div>
                    <button 
                      onClick={() => setReport(null)}
                      className="text-[9px] text-neutral-400 hover:text-white underline font-bold cursor-pointer"
                    >
                      {lang === 'ar' ? 'إخفاء التقرير' : 'Hide diagnostics'}
                    </button>
                  </div>
                </div>
              ) : (
                <div className="space-y-4 py-2">
                  <div className="border-b border-neutral-800/80 pb-2">
                    <span className="text-[10px] font-mono tracking-widest text-amber-500 uppercase font-black">
                      HyperOS AI Diagnostic Console
                    </span>
                    <h3 className="text-md font-bold text-neutral-200 mt-1">
                      {lang === 'ar' ? 'لوحة المراقبة الشاملة وجاهزية المعالجات' : 'Integrated hardware alignment status'}
                    </h3>
                  </div>

                  <div className="space-y-2 text-xs text-neutral-400">
                    <p className="flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-amber-500"></span>
                      <span>{lang === 'ar' ? 'تم كشف ملفات كاش غير منظمة تزن حوالي 8.64 GB.' : 'Residual junk is weighing down current system processes by 8.64 GB.'}</span>
                    </p>
                    <p className="flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-amber-500"></span>
                      <span>{lang === 'ar' ? 'ذاكرة الوصول العشوائي المتاحة حالياً متعبة في حدود 4.8 GB.' : 'LPDDR5X memory headroom is limited, causing micro-stutters during heavy gaming.'}</span>
                    </p>
                    <p className="flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-amber-500"></span>
                      <span>{lang === 'ar' ? 'مستشعر Leica بحاجة للمعاينة ومعالجة الصور بطيئة.' : 'Leica camera processing pipelines require sensor realignments.'}</span>
                    </p>
                  </div>

                  <p className="text-[10px] text-neutral-500 italic">
                    {lang === 'ar' ? '*الرجاء الضغط على الزر الدائري للتحسين وبث الحيوية المتكاملة لعتاد الهيكل.' : '*Please hit the circular button to clean, align, and boost the entire system.'}
                  </p>
                </div>
              )}
            </div>
          </div>
        </section>

        {/* CONTAINER FOR CURRENT ACTIVE TAB PAGE */}
        <section className="transition-all duration-300 transform">
          {activeTab === 'camera' && (
            <CameraStudio 
              lang={lang} 
              triggerNotification={triggerNotification} 
            />
          )}

          {activeTab === 'optimizer' && (
            <PhoneOptimizer 
              lang={lang} 
              triggerNotification={triggerNotification} 
            />
          )}

          {activeTab === 'game' && (
            <GameBooster 
              lang={lang} 
              triggerNotification={triggerNotification} 
            />
          )}

          {activeTab === 'assistant' && (
            <PersonalAssistant 
              lang={lang} 
              triggerNotification={triggerNotification} 
            />
          )}

          {activeTab === 'settings' && (
            <Settings 
              lang={lang} 
              setLang={setLang}
              triggerNotification={triggerNotification} 
            />
          )}
        </section>
      </main>

      {/* NOTIFICATIONS CONTAINER */}
      <div 
        className={`fixed bottom-5 ${lang === 'ar' ? 'left-5' : 'right-5'} z-50 flex flex-col gap-2 max-w-sm w-full outline-none pointer-events-none select-none`}
      >
        {notifications.map((notif) => (
          <div
            key={notif.id}
            className="bg-neutral-900/95 border border-amber-500/20 rounded-xl p-3.5 shadow-2xl flex items-start gap-2.5 backdrop-blur-md text-xs font-semibold animate-slide-in pointer-events-auto"
          >
            <div className="bg-amber-500/10 text-amber-400 p-1 rounded-md shrink-0">
              <BellRing className="w-4 h-4 animate-bounce" />
            </div>
            <div className="flex-1 text-right">
              <p className="text-neutral-300">{notif.text}</p>
            </div>
          </div>
        ))}
      </div>

      {/* FOOTER */}
      <footer className="py-8 border-t border-neutral-900 bg-neutral-950 mt-12">
        <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row items-center justify-between gap-4 text-center">
          <p className="text-[11px] text-neutral-600 font-mono">
            Xiaomi Ultra AI Master Control Center Platform. Powered by HyperOS & Leica Optics.
          </p>
          <div className="flex items-center gap-1.5 text-[10px] text-neutral-500">
            <span className="w-1.5 h-1.5 rounded-full bg-green-500"></span>
            <span>All sub-systems active</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
