import React from 'react';
import { ShieldAlert, RefreshCw, AlertTriangle, Cpu } from 'lucide-react';

interface Props {
  children: React.ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
  errorInfo: React.ErrorInfo | null;
}

export default class ErrorBoundary extends React.Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null,
    errorInfo: null
  };

  public static getDerivedStateFromError(error: Error): State {
    // Update state so the next render will show the fallback UI.
    return { hasError: true, error, errorInfo: null };
  }

  public componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error("Uncaught error in Xiaomi Ultra AI Master UI:", error, errorInfo);
    this.setState({ errorInfo });
  }

  private handleReload = () => {
    window.location.reload();
  };

  public render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-neutral-950 text-neutral-100 flex items-center justify-center p-6 font-sans antialiased selection:bg-amber-500 selection:text-neutral-950">
          <div className="max-w-md w-full bg-neutral-900 border border-neutral-800 rounded-3xl p-6 md:p-8 space-y-6 shadow-2xl relative overflow-hidden">
            {/* Background glowing effects */}
            <div className="absolute -top-10 -right-10 w-32 h-32 bg-amber-500/10 rounded-full blur-2xl"></div>
            <div className="absolute -bottom-10 -left-10 w-32 h-32 bg-red-500/10 rounded-full blur-2xl"></div>

            {/* Header Shield */}
            <div className="flex flex-col items-center justify-center text-center space-y-3">
              <div className="bg-red-500/10 border border-red-500/30 text-red-500 p-4 rounded-2xl animate-pulse">
                <ShieldAlert className="w-8 h-8" />
              </div>
              <div className="space-y-1">
                <h1 className="text-md font-black tracking-tight text-neutral-100">AI Master Recovery</h1>
                <p className="text-[11px] font-semibold text-neutral-500 uppercase tracking-widest font-mono">System Exception Caught</p>
              </div>
            </div>

            {/* Error Message Details box */}
            <div className="bg-neutral-950 p-4 rounded-xl border border-neutral-850 space-y-2.5">
              <div className="flex items-center gap-1.5 text-amber-500">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span className="text-xs font-bold font-mono">FATAL_INTERFACE_CRASH</span>
              </div>
              <p className="text-xs text-neutral-300 font-mono overflow-x-auto break-all select-all py-1">
                {this.state.error?.toString() || "Unknown rendering exception occurred inside the core virtual DOM thread."}
              </p>
              {this.state.errorInfo?.componentStack && (
                <details className="mt-2 text-[9px] text-neutral-500 font-mono cursor-pointer outline-none select-none">
                  <summary className="hover:text-neutral-400 font-bold transition-all">Show stack trace</summary>
                  <pre className="mt-2 max-h-[120px] overflow-auto whitespace-pre-wrap leading-relaxed select-all border-t border-neutral-900 pt-2 text-neutral-600">
                    {this.state.errorInfo.componentStack}
                  </pre>
                </details>
              )}
            </div>

            {/* Advice Panel */}
            <div className="text-[11px] text-neutral-400 leading-relaxed flex items-start gap-2 bg-neutral-900 p-3 rounded-xl border border-neutral-800">
              <Cpu className="w-4 h-4 text-amber-500 shrink-0" />
              <span>
                The Xiaomi Ultra AI Master system bridge remained secure. This exception has been captured by the local ErrorBoundary to protect phone threads from leaking volatile state.
              </span>
            </div>

            {/* Reload Actions */}
            <button
              onClick={this.handleReload}
              className="w-full bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-neutral-950 py-3 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-amber-500/10"
            >
              <RefreshCw className="w-4 h-4" />
              <span>Restore Core Interface</span>
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
