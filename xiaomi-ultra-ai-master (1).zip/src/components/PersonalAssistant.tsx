import React, { useState, useEffect, useRef } from 'react';
import { 
  Mic, 
  MicOff, 
  Send, 
  MessageSquare, 
  Bot, 
  AlertTriangle, 
  User, 
  RefreshCw, 
  AudioLines,
  Sparkles,
  Info,
  Check,
  FolderOpen,
  Trash2,
  Cpu,
  Tv,
  HelpCircle
} from 'lucide-react';
import { ChatMessage } from '../types';

interface PersonalAssistantProps {
  lang: 'ar' | 'en';
  triggerNotification: (text: string, type?: 'success' | 'error') => void;
}

const translations = {
  ar: {
    assistantSubtitle: 'مساعد شاومي الذكي الفائق المتكامل. تحكم بالصوت أو النص لحل العقبات وضبط الكاميرا',
    micActive: 'جاري الاستماع للنبض الصوتي... وجه الأمر الآن',
    micInactive: 'اضغط على الميكروفون المضيء للتحدث بالصوت',
    presetHeading: 'الأوامر الصوتية المقترحة للجهاز:',
    preset1: 'كيف أقوم بحل مشكلة حرارة الهاتف أثناء اللعب؟ 🌡️',
    preset2: 'كيف التقط أفضل بورتريه ليلي بكاميرا Leica؟ 📸',
    preset3: 'طريقة تفعيل وضع الأداء الأقصى للبطارية ⚡',
    typePlaceholder: 'اكتب استفسارًا للمساعد الذكي الفائق Xiaomi...',
    serverError: 'فشل النظام السحابي في الاستجابة حالياً. تم استدعاء الـ Coprocessor الاحتياطي لحل استفسارك.',
    aiRole: 'مساعد شاومي الفائق',
    userRole: 'أنت',
    
    // Arabic Extra translations
    subTabChat: 'غرفة المحادثة الذكية',
    subTabFiles: 'إدارة التطبيقات والملفات الكبيرة',
    subTabSuggestions: 'لوحة الاقتراحات والإقران الفورية',
    
    largeFilesTitle: 'تصفية وإبادة الملفات المأهولة بالذاكرة (UFS)',
    largeFilesSubtitle: 'قم بتوفير مسح تفصيلي لملفات الذاكرة واستئصال الملفات الضخمة المعزولة',
    appManagerTitle: 'مراقب استخدام حزم التطبيقات',
    appManagerSubtitle: 'تطبيقات نشطة في الخلفية تستهلك الذاكرة والتخزين الإضافي',
    freeSpaceBtn: 'تحرير التخزين المختار',
    solvesSuccess: 'تم حسم المشكلة وتحرير الخوارزمية بنجاح!',
    smartSuggTitle: 'اقتراحات المعالجة الوقائية الموصى بها',
    smartSuggSubtitle: 'يقوم الذكي الفائق بمطالعة النظام تلقائياً واقتراح تعديلات لضبط تدفق المعالجة',
    fixInstantBtn: 'إصلاح وحل فوري',
    solvedStatus: 'تم الإصلاح'
  },
  en: {
    assistantSubtitle: 'Integrated flagship voice & text companion optimized to answer technical Xiaomi queries',
    micActive: 'Listening to voice signature... Speak custom query now',
    micInactive: 'Tap glowing microphone to dictate commands',
    presetHeading: 'Suggested Quick Voice Commands:',
    preset1: 'How do I solve device heat during long heavy gaming? 🌡️',
    preset2: 'How do I snap perfect night portraits with Leica lens? 📸',
    preset3: 'Activate extreme battery saver & boost performance ⚡',
    typePlaceholder: 'Ask Xiaomi AI Assistant anything about your phone...',
    serverError: 'Primary cloud cluster idle. Triggered local coprocessor to fulfill requests immediately.',
    aiRole: 'Xiaomi Ultra Assistant',
    userRole: 'You',
    
    // English Extra translations
    subTabChat: 'AI Chat Dialogue',
    subTabFiles: 'Application & File Manager',
    subTabSuggestions: 'Smart Proactive Suggestions',
    
    largeFilesTitle: 'UFS Duplicates & Storage Consolidation',
    largeFilesSubtitle: 'Deep-scour redundant directories and heavy redundant assets from flash',
    appManagerTitle: 'Installed App Pipeline Monitor',
    appManagerSubtitle: 'Detect and hibernate apps hogging communication and memory buffers',
    freeSpaceBtn: 'Wipe Selected File Caches',
    solvesSuccess: 'Proactive optimization loaded successfully!',
    smartSuggTitle: 'Real-time SoC Proactive Diagnostics',
    smartSuggSubtitle: 'Proactive system checks advising automatic parameter changes',
    fixInstantBtn: 'Solve Instantaneously',
    solvedStatus: 'Resolved'
  }
};

const INITIAL_SUGGESTIONS = [
  { 
    id: 'sugg-1', 
    title: { ar: 'حرارة معالج Snapdragon تتجاوز 42°C', en: 'Snapdragon SoC thermal limit warnings' }, 
    action: { ar: 'تفعيل خوارزمية التبريد المتسارع ونفق غرف البخار السائل', en: 'Activate rapid liquid cooling and close idle tabs' }, 
    solved: false 
  },
  { 
    id: 'sugg-2', 
    title: { ar: 'امتداد ذاكرة هائل في 9 مصنفات متصفح قديمة', en: 'Leaked RAM buffers in background pages' }, 
    action: { ar: 'تجميد إجباري للصفحات وتخفيف استهلاك LPDDR5X بمقدار 1.2G', en: 'Hibernate browser sandbox nodes to load 1.2G RAM space' }, 
    solved: false 
  },
  { 
    id: 'sugg-3', 
    title: { ar: 'ملفات متكررة في ذاكرة التلخيص وتخزين الكاميرا', en: 'Duplicate captured previews inside Leica cache' }, 
    action: { ar: 'إبادة ونقل الصور المعزولة المتشابهة لتوفير 3.2 جيجابايت', en: 'Consolidate redundant JPG bursts to save 3.2 GB storage' }, 
    solved: false 
  }
];

export default function PersonalAssistant({ lang, triggerNotification }: PersonalAssistantProps) {
  const t = translations[lang];

  // Primary navigation tabs within assistant section
  const [subTab, setSubTab] = useState<'chat' | 'files' | 'suggestions'>('chat');

  // Chat conversation state
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputText, setInputText] = useState<string>('');
  const [isListening, setIsListening] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  // File system simulation state
  const [heavyFiles, setHeavyFiles] = useState([
    { id: 'f-1', name: 'WhatsApp Media Duplicated Folder', size: '2.40 GB', path: '/UFS/Media/whatsapp_dup', selected: true },
    { id: 'f-2', name: 'Genshin Pre-compiled Shaders cache', size: '4.15 GB', path: '/UFS/Android/obb/genshin_shaders', selected: false },
    { id: 'f-3', name: 'Offline Map Blocks (Riyadh & Cairo)', size: '850 MB', path: '/UFS/Maps/offline_blocks', selected: true },
    { id: 'f-4', name: 'Duplicate Raw Lens Screen Captures', size: '320 MB', path: '/UFS/DCIM/raw_burst', selected: false }
  ]);

  // Proactive suggestions state
  const [suggestions, setSuggestions] = useState(INITIAL_SUGGESTIONS);

  // Seed default welcome message
  useEffect(() => {
    const welcomeText = lang === 'ar'
      ? `أهلاً بك! أنا المساعد الذكي الفائق لهواتف Xiaomi Ultra. 🚀
يمكنني مساعدتك في تخصيص إعدادات هاتف Xiaomi 17 Ultra، استكشاف كاميرا Leica وقدراتها، وتوفير حلول فورية للبطارية وحرارة الهاتف أو فحص نظام التشغيل.
كيف يمكنني توجيهك اليوم؟`
      : `Hello! I am your Xiaomi Ultra AI Master assistant. 🚀
I am here to guide you in tuning camera profiles, squeezing extreme FPS from Game Turbo, managing SoC storage, or answering phone questions. How can I assist you right now?`;

    setMessages([
      {
        id: 'welcome-msg',
        role: 'assistant',
        text: welcomeText,
        timestamp: new Date()
      }
    ]);
  }, [lang]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, loading]);

  const sendMessage = async (text: string) => {
    if (!text.trim()) return;

    const userMsg: ChatMessage = {
      id: `msg-user-${Date.now()}`,
      role: 'user',
      text,
      timestamp: new Date()
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputText('');
    setLoading(true);

    try {
      const chatPayload = [...messages, userMsg].map((m) => ({
        role: m.role,
        text: m.text
      }));

      const res = await fetch('/api/gemini/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          messages: chatPayload,
          lang,
          mode: 'xiaomi'
        })
      });

      if (!res.ok) {
        throw new Error('API server unreachable');
      }

      const data = await res.json();
      const assistantMsg: ChatMessage = {
        id: `msg-ai-${Date.now()}`,
        role: 'assistant',
        text: data.text || 'System Idle.',
        timestamp: new Date()
      };

      setMessages((prev) => [...prev, assistantMsg]);
    } catch (e) {
      console.error(e);
      const fallbackMsg: ChatMessage = {
        id: `msg-ai-fallback-${Date.now()}`,
        role: 'assistant',
        text: lang === 'ar'
          ? `مرحباً بك! بفضل كفاءة نظام Coprocessor الداخلي للهاتف، تم الرد على استفسارك الموقَّر: "${text}".
1. ⚡ **لإدارة الحرارة**: نوصي بالدخول لقسم "مُحسّن الهاتف" وتشغيل فحص التبريد السائل فورًا لخفض درجة حرارة المعالج وتوفير عمر البطارية.
2. 📸 **لقطات Leica الليلية**: اضبط الفتحة الميكانيكية للعدسة على f/1.4 للحصول على أقصى تركيز ضوئي مع تفعيل "Leica Master Super Resolution" للبورتريه.
3. 🎮 **الألعاب**: تفعيل وضع Game Turbo لمنع الإشعارات وتثبيت الإطارات على 120 إطار بالثانية.`
          : `Hello from local SoC backup! Re: your query: "${text}".
1. ⚡ **Heat / Thermals**: Open "Smart Optimizer" and launch the Unified Cleanse. This immediately clears hot loops in background processes, dropping CPU temp by 8-12°C.
2. 📸 **Pristine Night shots**: Toggle the physical aperture to f/1.4 inside the AI Camera Studio to capture 136% more light naturally.
3. 🎮 **Smooth Gaming**: Trigger DND Mode inside the Game Booster to allocate all bandwidth queues exclusively to your game.`,
        timestamp: new Date()
      };
      setMessages((prev) => [...prev, fallbackMsg]);
      triggerNotification(t.serverError, 'success');
    } finally {
      setLoading(false);
    }
  };

  const startVoiceSim = () => {
    setIsListening(true);
    triggerNotification(lang === 'ar' ? 'تم تنشيط ميكروفون Xiaomi الفائق' : 'Xiaomi Ultra Mic input enabled', 'success');
  };

  const stopVoiceSim = () => {
    setIsListening(false);
  };

  const handleVoicePreset = (prompt: string) => {
    setIsListening(false);
    sendMessage(prompt);
  };

  const deleteSelectedFiles = () => {
    const deletedCount = heavyFiles.filter(f => f.selected).length;
    if (deletedCount === 0) return;

    setHeavyFiles(prev => prev.filter(f => !f.selected));
    triggerNotification(
      lang === 'ar'
        ? `🔥 تم شطب وحذف ${deletedCount} ملفات كبيرة بنجاح لتوفير التخزين!`
        : `🔥 Purged ${deletedCount} major redundant storage folders!`,
      'success'
    );
  };

  const toggleFileSelect = (id: string) => {
    setHeavyFiles(prev => prev.map(f => f.id === id ? { ...f, selected: !f.selected } : f));
  };

  const solveSuggestion = (id: string) => {
    setSuggestions(prev => prev.map(s => s.id === id ? { ...s, solved: true } : s));
    triggerNotification(
      lang === 'ar' ? 'تم ضبط وحقن خيار الصيانة الأمثل للجهاز بنجاح!' : 'Optimization applied with zero delay response!',
      'success'
    );
  };

  return (
    <div className="space-y-6" id="ai-personal-assistant-section">
      {/* Top Card */}
      <div className="bg-gradient-to-r from-neutral-900 via-neutral-900 to-cyan-950/20 border border-cyan-500/15 rounded-2xl p-5 relative overflow-hidden">
        <div className="absolute right-0 top-0 w-48 h-48 bg-cyan-600/5 rounded-full blur-3xl pointer-events-none"></div>
        <div className="flex items-start gap-4">
          <div className="bg-cyan-500 text-neutral-950 p-3 rounded-xl shadow-lg ring-4 ring-cyan-500/20">
            <Bot className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-neutral-100 flex items-center gap-2">
              Xiaomi Ultra AI Assistant
              <span className="text-[10px] bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 px-2 py-0.5 rounded-full font-mono font-bold tracking-widest uppercase">
                Offline + Cloud NLU
              </span>
            </h2>
            <p className="text-xs text-neutral-400 mt-1 max-w-2xl leading-relaxed">
              {t.assistantSubtitle}
            </p>
          </div>
        </div>
      </div>

      {/* Internal navigation section tabs */}
      <div className="flex flex-wrap items-center gap-2 border-b border-neutral-800 pb-3">
        {[
          { id: 'chat', label: t.subTabChat, icon: <MessageSquare className="w-3.5 h-3.5" /> },
          { id: 'files', label: t.subTabFiles, icon: <FolderOpen className="w-3.5 h-3.5" /> },
          { id: 'suggestions', label: t.subTabSuggestions, icon: <Sparkles className="w-3.5 h-3.5" /> }
        ].map((sub) => {
          const isSelected = subTab === sub.id;
          return (
            <button
              key={sub.id}
              onClick={() => setSubTab(sub.id as any)}
              className={`flex items-center gap-2 px-3.5 py-2 text-xs font-bold rounded-lg border transition-all cursor-pointer ${
                isSelected 
                  ? 'bg-cyan-500 text-neutral-950 border-cyan-400 font-extrabold shadow-md shadow-cyan-500/10'
                  : 'bg-neutral-900/60 border-neutral-800 text-neutral-400 hover:text-white hover:bg-neutral-800/40'
              }`}
            >
              {sub.icon}
              <span>{sub.label}</span>
            </button>
          );
        })}
      </div>

      {subTab === 'chat' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
          {/* Left column Voice Microphone & Presets */}
          <div className="lg:col-span-5 bg-neutral-900/90 border border-neutral-800 rounded-2xl p-5 flex flex-col justify-between space-y-6">
            <div className="space-y-4">
              <h3 className="text-sm font-semibold text-neutral-300 flex items-center gap-2">
                <AudioLines className="w-4 h-4 text-cyan-400 animate-pulse" />
                {lang === 'ar' ? 'التحكم الصوتي التفاعلي الذكي' : 'Interactive Vocal Capture Matrix'}
              </h3>
              
              {/* Massive microphone button & voice wave simulation */}
              <div className="bg-neutral-950/80 rounded-xl border border-neutral-800 p-6 flex flex-col items-center justify-center text-center relative overflow-hidden">
                <div className="absolute inset-0 bg-radial-gradient from-cyan-500/5 to-transparent pointer-events-none"></div>

                {isListening ? (
                  /* Glowing active state & flex bars graph */
                  <div className="space-y-6 py-4 w-full flex flex-col items-center">
                    <button
                      onClick={stopVoiceSim}
                      className="w-16 h-16 rounded-full bg-red-600 hover:bg-red-500 text-white flex items-center justify-center shadow-lg ring-8 ring-red-500/20 transition-all cursor-pointer"
                    >
                      <Mic className="w-6 h-6 animate-ping" />
                    </button>
                    <p className="text-xs font-bold text-cyan-400 animate-pulse">{t.micActive}</p>

                    {/* Audio Frequency Wave Simulation */}
                    <div className="flex items-end justify-center gap-1.5 h-10 w-48">
                      {[22, 45, 12, 67, 34, 89, 56, 12, 78, 43, 91, 15, 60, 24].map((h, i) => (
                        <div 
                          key={i} 
                          className="w-2 bg-gradient-to-t from-cyan-500 to-cyan-400 rounded-full animate-pulse"
                          style={{ 
                            height: `${Math.floor(Math.random() * 30) + 10}px`,
                            animationDelay: `${i * 75}ms`,
                            animationDuration: '600ms'
                          }}
                        ></div>
                      ))}
                    </div>
                  </div>
                ) : (
                  /* Inactive state */
                  <div className="space-y-4 py-8 flex flex-col items-center">
                    <button
                      onClick={startVoiceSim}
                      className="w-16 h-16 rounded-full bg-gradient-to-b from-cyan-400 to-cyan-500 hover:from-cyan-300 hover:to-cyan-400 text-neutral-950 flex items-center justify-center shadow-lg hover:shadow-cyan-400/20 ring-4 ring-cyan-500/10 transition-all cursor-pointer animate-pulse"
                    >
                      <Mic className="w-6 h-6" />
                    </button>
                    <p className="text-[11px] text-neutral-400">{t.micInactive}</p>
                  </div>
                )}
              </div>
            </div>

            {/* Preset Voice triggers */}
            <div className="space-y-2 mt-auto">
              <p className="text-[11px] font-semibold text-neutral-400">{t.presetHeading}</p>
              <div className="flex flex-col gap-1.5">
                {[t.preset1, t.preset2, t.preset3].map((prs, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleVoicePreset(prs)}
                    className={`text-right ${lang === 'ar' ? 'text-right' : 'text-left'} text-[10px] p-2.5 rounded-xl bg-neutral-950 hover:bg-neutral-800/40 border border-neutral-800 text-neutral-300 hover:text-white transition-all cursor-pointer`}
                  >
                    {prs}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Right column Chat message thread & input */}
          <div className="lg:col-span-7 bg-neutral-900/90 border border-neutral-800 rounded-2xl flex flex-col h-[520px] overflow-hidden">
            {/* Thread Header */}
            <div className="p-3.5 bg-neutral-950 border-b border-neutral-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 text-right"></span>
                <span className="text-xs font-bold text-neutral-200">HyperOS AI Secure Matrix</span>
              </div>
              <button 
                onClick={() => {
                  setMessages([
                    {
                      id: 'welcome-msg',
                      role: 'assistant',
                      text: lang === 'ar' ? 'تم تصفير وبدء حوار جديد بالذكاء الاصطناعي.' : 'AI Dialogue thread reset.',
                      timestamp: new Date()
                    }
                  ]);
                }}
                className="text-[9px] hover:text-cyan-400 text-neutral-500 border border-neutral-800 rounded px-2.5 py-1 transition-all cursor-pointer"
              >
                Reset Session
              </button>
            </div>

            {/* Messages Scrollable list */}
            <div 
              ref={scrollRef}
              className="flex-1 p-4 overflow-y-auto space-y-4 scroll-smooth max-h-[380px]"
            >
              {messages.map((m) => {
                const isAi = m.role === 'assistant';
                return (
                  <div
                    key={m.id}
                    className={`flex gap-2.5 ${isAi ? 'justify-start' : 'justify-end'}`}
                  >
                    {isAi && (
                      <div className="w-7 h-7 rounded-lg bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center shrink-0">
                        <Bot className="w-4 h-4 text-cyan-400" />
                      </div>
                    )}
                    <div
                      className={`max-w-[85%] rounded-2xl p-3.5 text-xs text-neutral-200 leading-relaxed relative ${
                        isAi
                          ? 'bg-neutral-950 border border-neutral-800 rounded-tl-none text-right'
                          : 'bg-cyan-950/40 border border-cyan-500/25 rounded-tr-none text-right'
                      }`}
                    >
                      <p className="font-semibold text-[8px] opacity-40 mb-1">
                        {isAi ? t.aiRole : t.userRole}
                      </p>
                      <p className="whitespace-pre-line text-xs">{m.text}</p>
                      <span className="text-[7.5px] opacity-40 mt-1.5 block text-left">
                        {m.timestamp?.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) || ''}
                      </span>
                    </div>
                    {!isAi && (
                      <div className="w-7 h-7 rounded-lg bg-cyan-500 text-neutral-950 font-bold flex items-center justify-center shrink-0 text-xs">
                        U
                      </div>
                    )}
                  </div>
                );
              })}

              {loading && (
                <div className="flex items-center gap-2.5 justify-start">
                  <div className="w-7 h-7 rounded-lg bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center shrink-0">
                    <RefreshCw className="w-4 h-4 text-cyan-400 animate-spin" />
                  </div>
                  <div className="bg-neutral-950 border border-neutral-800 rounded-2xl rounded-tl-none p-3.5 max-w-[85%]">
                    <div className="flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-cyan-400/60 animate-bounce" style={{ animationDelay: '0ms' }}></span>
                      <span className="w-1.5 h-1.5 rounded-full bg-cyan-400/60 animate-bounce" style={{ animationDelay: '150ms' }}></span>
                      <span className="w-1.5 h-1.5 rounded-full bg-cyan-400/60 animate-bounce" style={{ animationDelay: '300ms' }}></span>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Form write input */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                sendMessage(inputText);
              }}
              className="p-3 bg-neutral-950 border-t border-neutral-800 flex items-center gap-2"
            >
              <input
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder={t.typePlaceholder}
                className="flex-1 bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2.5 text-xs text-neutral-100 placeholder-neutral-500 focus:outline-none focus:border-cyan-500 transition-all font-sans"
              />
              <button
                type="submit"
                disabled={loading || !inputText.trim()}
                className="bg-cyan-500 hover:bg-cyan-400 disabled:opacity-40 text-neutral-950 p-2.5 rounded-xl transition-all font-bold text-xs shadow-lg shadow-cyan-500/15 cursor-pointer flex items-center justify-center shrink-0"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </div>
        </div>
      )}

      {subTab === 'files' && (
        <div className="bg-neutral-900/90 border border-neutral-800 rounded-2xl p-6 space-y-6">
          <div>
            <h3 className="text-sm font-bold text-neutral-200 flex items-center gap-2">
              <FolderOpen className="w-4 h-4 text-cyan-400" />
              {t.largeFilesTitle}
            </h3>
            <p className="text-xs text-neutral-400 mt-1">
              {t.largeFilesSubtitle}
            </p>
          </div>

          <div className="space-y-3">
            {heavyFiles.length === 0 ? (
              <div className="bg-neutral-950 p-8 rounded-xl border border-neutral-800 text-center space-y-2">
                <Check className="w-10 h-10 text-emerald-400 mx-auto animate-bounce" />
                <p className="text-xs font-bold text-neutral-200">System solid space reclaimed fully!</p>
              </div>
            ) : (
              heavyFiles.map((file) => (
                <button
                  key={file.id}
                  onClick={() => toggleFileSelect(file.id)}
                  className={`w-full flex items-center justify-between p-4 rounded-xl border text-right transition-all cursor-pointer ${
                    file.selected 
                      ? 'bg-cyan-950/20 border-cyan-500/45 shadow-sm'
                      : 'bg-neutral-950 border-neutral-800/80 hover:bg-neutral-800/20'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-5 h-5 rounded flex items-center justify-center border transition-all ${
                      file.selected ? 'bg-cyan-500 border-cyan-400 text-neutral-950' : 'border-neutral-700 text-transparent'
                    }`}>
                      <Check className="w-3.5 h-3.5 font-extrabold" />
                    </div>
                    <div className={`text-right ${lang === 'ar' ? 'text-right' : 'text-left'}`}>
                      <p className="text-xs font-bold text-neutral-200">{file.name}</p>
                      <p className="text-[10px] text-neutral-500 font-mono mt-0.5">{file.path}</p>
                    </div>
                  </div>
                  
                  <span className="text-xs font-mono font-bold text-cyan-400">
                    {file.size}
                  </span>
                </button>
              ))
            )}
          </div>

          {heavyFiles.length > 0 && (
            <button
              onClick={deleteSelectedFiles}
              disabled={heavyFiles.filter(f => f.selected).length === 0}
              className="w-full bg-gradient-to-r from-red-600 to-amber-600 hover:from-red-500 hover:to-amber-500 text-white p-3.5 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg disabled:opacity-40"
            >
              <Trash2 className="w-4 h-4" />
              <span>{t.freeSpaceBtn}</span>
            </button>
          )}
        </div>
      )}

      {subTab === 'suggestions' && (
        <div className="bg-neutral-900/90 border border-neutral-800 rounded-2xl p-6 space-y-6">
          <div>
            <h3 className="text-sm font-bold text-neutral-200 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-cyan-400" />
              {t.smartSuggTitle}
            </h3>
            <p className="text-xs text-neutral-400 mt-1">
              {t.smartSuggSubtitle}
            </p>
          </div>

          <div className="space-y-3">
            {suggestions.map((sugg) => (
              <div key={sugg.id} className="bg-neutral-950 p-4 border border-neutral-800 rounded-xl flex items-center justify-between gap-4 flex-wrap">
                <div className="flex items-start gap-3">
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${sugg.solved ? 'bg-emerald-950/40 text-emerald-400 border border-emerald-500/20' : 'bg-amber-950/40 text-amber-500 border border-amber-500/20'} border`}>
                    {sugg.solved ? <Check className="w-4 h-4" /> : <AlertTriangle className="w-4 h-4 animate-bounce" />}
                  </div>
                  <div className={`text-right ${lang === 'ar' ? 'text-right' : 'text-left'}`}>
                    <p className={`text-xs font-extrabold ${sugg.solved ? 'text-neutral-500 line-through' : 'text-neutral-200'}`}>
                      {lang === 'ar' ? sugg.title.ar : sugg.title.en}
                    </p>
                    <p className="text-[10px] text-neutral-400 mt-1">
                      {lang === 'ar' ? sugg.action.ar : sugg.action.en}
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => solveSuggestion(sugg.id)}
                  disabled={sugg.solved}
                  className={`px-3.5 py-1.5 text-xs font-bold rounded-xl transition-all border shrink-0 cursor-pointer ${
                    sugg.solved
                      ? 'bg-neutral-900 border-neutral-800 text-neutral-600 cursor-not-allowed'
                      : 'bg-cyan-500 border-cyan-400 hover:bg-cyan-400 text-neutral-950 font-black shadow-lg shadow-cyan-500/10'
                  }`}
                >
                  {sugg.solved ? t.solvedStatus : t.fixInstantBtn}
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
