import React, { useState, useEffect } from 'react';
import { 
  Gamepad2, 
  ShieldAlert, 
  Wifi, 
  Zap, 
  VolumeX, 
  Sliders, 
  Play, 
  TrendingUp, 
  MonitorSmartphone, 
  Layers, 
  Check, 
  X, 
  BellOff, 
  SlidersHorizontal,
  Flame,
  Award,
  Maximize2,
  ChevronRight,
  Sparkles,
  Volume2
} from 'lucide-react';

interface GameBoosterProps {
  lang: 'ar' | 'en';
  triggerNotification: (text: string, type?: 'success' | 'error') => void;
}

const translations = {
  ar: {
    gameSubtitle: 'مركز تسريع الألعاب المعزز التوربيني ببروتوكول Game Turbo 6.0 الفائق',
    fpsMonitor: 'مراقب معدل الإطارات الفوري (Live FPS HUD)',
    gpuBoost: 'معزز الرسوميات والتردد الذكي (GPU Boost)',
    dndActive: 'وضع عدم الإزعاج وتكثيف الإشارة (Game DND)',
    boostSuccess: 'تم تركيز الموارد وقنوات المعالجة للعبة: ',
    launchButton: 'تشغيل اللعبة وبدء التسريع التلقائي 🚀',
    selectGame: 'حدد اللعبة لتهيئتها:',
    fpsStabilized: 'استقرار الإطارات والحد من زمن الاستملاك',
    settingsPanel: 'إعدادات التحكم المخصصة لزمن الاستجابة',
    touchResponse: 'حساسية شاشة اللمس الميكروية (2160Hz)',
    resolutionLimit: 'دقة التفاصيل الرسومية المحسّنة (AI Super Resolution)',
    antiLag: 'نظام حجب التأخير وتقليل زمن التوزيع',
    activeGame: 'اللعبة النشطة حالياً بالتخصيص',
    boostOn: 'تنشيط المعالج عالي التردد',
    boostOff: 'معالجة عادية لتوفير الطاقة',
    fpsUnit: 'إطار/ثانية',
    
    // Arabic Extra translations
    subTabLibrary: 'مكتبة الألعاب والإعدادات',
    subTabPerformance: 'لوحة قياس الموارد (HUD)',
    subTabWildboost: 'معزز WildBoost 3.0 التوربيني',
    subTabBlocker: 'حاجب المكالمات والإشعارات',
    
    blockedLogsTitle: 'سجل الإشعارات المحجوبة أثناء اللعب',
    incomingCallTitle: 'محاكي كسر التشويش وتصفير الرنين الذكي',
    blockCallBtn: 'محاكاة ورود مكالمة مزعجة لحجبها',
    blockSmsBtn: 'محاكاة رسالة سبام لحجبها',
    gameLaunchTitle: 'مستودع الألعاب الافتراضي (Game Space)',
    fpsLock: 'قفل الإطارات الأقصى',
    resolutionUpscale: 'دقة فائقة بالذكاء الاصطناعي',
    testNetwork: 'اختبار زمن استجابة خادم الألعاب (Ping)',
    testingPing: 'جاري فحص اتصال الخوادم الإقليمية للعبة...',
    pingSuccess: 'تم فحص استقرار الخادم! الخادم الحالي بنسبة تأخير: ',
    inGameHudTitle: 'لوحة التحكم العائمة في اللعبة',
    closeInGame: 'الخروج والعودة للوحة القيادة'
  },
  en: {
    gameSubtitle: 'Unleash Snapdragon Elite Core with Game Turbo 6.0 Hydro-Boost algorithms',
    fpsMonitor: 'Live HUD Performance Graph (FPS)',
    gpuBoost: 'GPU High-Frequency Booster',
    dndActive: 'DND Blocker & Network Prioritizer',
    boostSuccess: 'Game Turbo optimized fully for: ',
    launchButton: 'Launch & Inject Game Turbo 🚀',
    selectGame: 'Select Game to Configure:',
    fpsStabilized: 'Frame-rate stabilization active',
    settingsPanel: 'HyperOS 2160Hz Touch & Latency Controls',
    touchResponse: 'High-frequency 3D Touch Response',
    resolutionLimit: 'AI Super Resolution Upsampling',
    antiLag: 'Network Congestion Bypass (Anti-Lag)',
    activeGame: 'Target Gaming Slot',
    boostOn: 'Injected Turbo Clocks',
    boostOff: 'Standard Cooldown Model',
    fpsUnit: 'FPS',
    
    // English Extra translations
    subTabLibrary: 'Game Space Library & Setup',
    subTabPerformance: 'HUD Performance Monitor',
    subTabWildboost: 'WildBoost 3.0 Controller',
    subTabBlocker: 'DND Notification Blocker',
    
    blockedLogsTitle: 'Blocked Communications History (Session)',
    incomingCallTitle: 'Anti-Interruption Call Simulator',
    blockCallBtn: 'Simulate Incoming Call (Auto-Blocked)',
    blockSmsBtn: 'Simulate Incoming Spam SMS (Silently Logged)',
    gameLaunchTitle: 'Unified Game Space Vault',
    fpsLock: 'Max Frame-rate Lock Rate',
    resolutionUpscale: 'AI Spatial-Temps Upscaling',
    testNetwork: 'Test Gaming Server Latency (Ping)',
    testingPing: 'Scouting local region servers for optimum edge node...',
    pingSuccess: 'Server response checked successfully! Current network delay: ',
    inGameHudTitle: 'Xiaomi In-Game Floating Panel',
    closeInGame: 'Exit & Cool Down SoC'
  }
};

const INITIAL_GAMES = [
  { 
    id: 'genshin', 
    name: 'Genshin Impact', 
    genre: 'RPG / Open World', 
    bg: 'indigo', 
    defaultFps: 60,
    touchSensitivity: 95,
    resolutionMax: '1080p AI Upscale',
    antiLagLevel: 'Max Prioritization'
  },
  { 
    id: 'pubg', 
    name: 'PUBG Mobile', 
    genre: 'Battle Royale Esports', 
    bg: 'emerald', 
    defaultFps: 90,
    touchSensitivity: 100,
    resolutionMax: 'Native UHD 90Hz',
    antiLagLevel: 'Esports Bypass'
  },
  { 
    id: 'asphalt', 
    name: 'Asphalt Legends UNITE', 
    genre: 'Racing Simulation', 
    bg: 'red', 
    defaultFps: 120,
    touchSensitivity: 85,
    resolutionMax: '1440p HDR Extreme',
    antiLagLevel: 'Auto Dynamic Buffer'
  }
];

export default function GameBooster({ lang, triggerNotification }: GameBoosterProps) {
  const t = translations[lang === 'en' ? 'en' : 'ar'];

  // Active sub-page tab
  const [subTab, setSubTab] = useState<'library' | 'performance' | 'wildboost' | 'blocker'>('library');

  // Unified game states
  const [selectedGame, setSelectedGame] = useState<string>('genshin');
  const [gpuBoost, setGpuBoost] = useState<boolean>(true);
  const [dndMode, setDndMode] = useState<boolean>(true);
  const [touchResponse, setTouchResponse] = useState<number>(85); // %
  const [aiUpscaling, setAiUpscaling] = useState<boolean>(true);
  const [fpsTarget, setFpsTarget] = useState<60 | 90 | 120 | 144>(120);
  const [pingValue, setPingValue] = useState<number>(14); // ms
  const [isMeasuringPing, setIsMeasuringPing] = useState<boolean>(false);

  // Performance Mode selector: battery, balanced, performance, wildboost
  const [perfMode, setPerfMode] = useState<'battery' | 'balanced' | 'performance' | 'wildboost'>('balanced');

  // In-Game full-screen simulator state
  const [activeGameLaunched, setActiveGameLaunched] = useState<boolean>(false);
  const [gameScore, setGameScore] = useState<number>(0);

  // Blocked logs
  const [blockedItems, setBlockedItems] = useState([
    { id: '1', type: 'call', sender: '+966 50 123 4567', time: '14:20', text: 'Incoming Voice Call Blocked Safely' },
    { id: '2', type: 'sms', sender: 'PromoOffer', time: '14:24', text: 'HyperOS blocked notification: 50% discount on credit...' }
  ]);

  const [gameFpsData, setGameFpsData] = useState<{ name: string; fps: number }[]>([
    { name: '1s', fps: 118 },
    { name: '2s', fps: 119 },
    { name: '3s', fps: 120 },
    { name: '4s', fps: 118 },
    { name: '5s', fps: 120 },
    { name: '6s', fps: 121 }
  ]);

  const activeGameObj = INITIAL_GAMES.find(g => g.id === selectedGame) || INITIAL_GAMES[0];

  // Fluctuating real ping latency
  useEffect(() => {
    const timer = setInterval(() => {
      setPingValue((prev) => {
        let base = 25;
        if (perfMode === 'wildboost') base = 9;
        else if (perfMode === 'performance') base = 14;
        else if (perfMode === 'battery') base = 48;
        
        const offset = Math.floor(Math.random() * 5) - 2;
        const nextVal = base + offset;
        return nextVal < 4 ? 4 : nextVal;
      });
    }, 2000);
    return () => clearInterval(timer);
  }, [perfMode]);

  // Simulated Dynamic FPS fluctuations based on target setting and boost status & performance mode active
  useEffect(() => {
    const timer = setInterval(() => {
      setGameFpsData((prev) => {
        let baseTarget: number = fpsTarget;
        if (perfMode === 'battery') {
          baseTarget = 45;
        } else if (perfMode === 'balanced') {
          baseTarget = 60;
        } else if (perfMode === 'performance') {
          baseTarget = 90;
        } else if (perfMode === 'wildboost') {
          baseTarget = 144;
        }

        if (selectedGame === 'genshin' && baseTarget > 90) {
          // Genshin natively supports up to 60/90 fps
          baseTarget = 90;
        }

        let min = gpuBoost ? baseTarget - 2 : baseTarget - 12;
        let max = gpuBoost ? baseTarget + 2 : baseTarget + 4;
        
        // Anti lag affects performance stability
        if (aiUpscaling) {
          min -= 2;
        }

        let newFps = Math.floor(Math.random() * (max - min + 1)) + min;
        if (newFps < 20) newFps = 20;

        if (prev.length === 0) {
          return [{ name: '1s', fps: newFps }];
        }

        const nextData = [...prev.slice(1)];
        const lastItem = prev[prev.length - 1];
        let secIndex = 1;
        if (lastItem && lastItem.name) {
          const numPart = parseInt(lastItem.name.replace('s', ''), 10);
          if (!isNaN(numPart)) {
            secIndex = numPart + 1;
          }
        }
        nextData.push({ name: `${secIndex}s`, fps: newFps });
        return nextData;
      });
    }, 1500);

    return () => clearInterval(timer);
  }, [selectedGame, gpuBoost, fpsTarget, aiUpscaling, perfMode]);

  const launchPingTest = () => {
    setIsMeasuringPing(true);
    triggerNotification(t.testingPing, 'success');
    setTimeout(() => {
      const nextPing = Math.floor(Math.random() * 8) + 8; // 8 to 15 ms
      setPingValue(nextPing);
      setIsMeasuringPing(false);
      triggerNotification(`${t.pingSuccess} ${nextPing}ms (Dual Wi-Fi Acceleration Solidified)`, 'success');
    }, 100);
  };

  const handleLaunchGameSpace = () => {
    setActiveGameLaunched(true);
    setGameScore(0);
    triggerNotification(`${t.boostSuccess} ${activeGameObj.name}! Custom WildBoost 3.0 configurations active!`, 'success');
  };

  const simulateIncomingCall = () => {
    const timeNow = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const newBlocked = {
      id: `block-${Date.now()}`,
      type: 'call',
      sender: lang === 'ar' ? 'البنك العقاري / تمويل شخصي' : 'Fictitious spam caller',
      time: timeNow,
      text: lang === 'ar' ? 'تم كتم الرنين وحظر المكالمة الترويحية في الخلفية تلقائياً بنجاح' : 'Silenced + Blocked ringtone fully during active session'
    };
    setBlockedItems(prev => [newBlocked, ...prev]);
    triggerNotification(
      lang === 'ar'
        ? `🚫 وضع عدم الإزعاج حظر تلقائياً مكالمة واردة من [${newBlocked.sender}]`
        : `🚫 Game DND automatically blocked call from [${newBlocked.sender}]`,
      'success'
    );
  };

  const simulateIncomingSms = () => {
    const timeNow = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const newBlocked = {
      id: `block-${Date.now()}`,
      type: 'sms',
      sender: 'Xiaomi Promo VIP',
      time: timeNow,
      text: lang === 'ar' ? 'تم عزل الإشعار المعروض عن شاشة اللعب وحفظه في سجل المكالمات والمساعد' : 'Notification banner hidden securely, logged to trace'
    };
    setBlockedItems(prev => [newBlocked, ...prev]);
    triggerNotification(
      lang === 'ar'
        ? `✉️ الدعم السريع كتم رسالة سبام معزولة من [${newBlocked.sender}]`
        : `✉️ Silently frozen incoming message notification form [${newBlocked.sender}]`,
      'success'
    );
  };

  return (
    <div className="space-y-6" id="ai-game-booster-section">
      {/* If Game Launched in Emulator HUD overlay mode */}
      {activeGameLaunched ? (
        <div className="bg-neutral-900 border border-emerald-500 rounded-2xl p-6 relative overflow-hidden flex flex-col justify-between h-[520px] shadow-2xl animate-fade-in">
          {/* Neon background overlays */}
          <div className="absolute inset-0 bg-radial-gradient from-emerald-500/10 to-transparent pointer-events-none"></div>

          {/* HUD Status top band */}
          <div className="flex items-center justify-between border-b border-neutral-800 pb-3 z-10">
            <div className="flex items-center gap-3">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping"></span>
              <p className="text-sm font-black text-neutral-100 flex items-center gap-2">
                {activeGameObj.name}
                <span className="text-[10px] bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded-full font-mono">
                  Turbo HUD 6.0 Active
                </span>
              </p>
            </div>
            
            <div className="flex items-center gap-4 text-xs font-mono">
              <span className="text-emerald-400 font-bold">FPS: {gameFpsData[gameFpsData.length - 1]?.fps || 120}</span>
              <span className="text-cyan-400">Ping: {pingValue}ms</span>
              <span className="text-amber-400">GPU Load: 84%</span>
            </div>
            
            <button
              onClick={() => setActiveGameLaunched(false)}
              className="text-[11px] bg-red-950/40 border border-red-500/30 text-red-400 hover:bg-neutral-800 hover:text-white px-3.5 py-1.5 rounded-xl transition-all font-bold cursor-pointer"
            >
              {t.closeInGame}
            </button>
          </div>

          {/* Core Interactive Sandbox Game element */}
          <div className="flex-1 flex flex-col items-center justify-center text-center space-y-6 z-10">
            <div className="space-y-2">
              <p className="text-[10px] text-neutral-500 uppercase tracking-widest font-mono">Simulating High-Frequency Render Loop</p>
              <h2 className="text-2xl font-black text-neutral-100">{lang === 'ar' ? 'اضغط بسرعة لرفع ضخ جزيئات المعالجة الرسومية!' : 'Tap with touch rate speed simulation!'}</h2>
              <p className="text-xs text-neutral-400 max-w-lg leading-relaxed mx-auto">
                {lang === 'ar' 
                  ? 'يقيس هذا المحاكي زمن استجابة لمس شاشة Xiaomi بمعدل 2160Hz من اللمسات فائقة الحساسية. اضغط على الدائرة لجمع الإطارات!' 
                  : 'This interactive engine benchmarks the ultra high-frequency 2160Hz touch response. Beat your score and verify FPS drops!'}
              </p>
            </div>

            {/* Click Circle Trigger */}
            <button
               onClick={() => {
                 setGameScore(prev => prev + 1);
                 // Temporarily fluctuate FPS higher on click
                 setGameFpsData((prev) => {
                   const nextData = [...prev];
                   if (nextData.length > 0) {
                     nextData[nextData.length - 1].fps = Math.min(144, nextData[nextData.length - 1].fps + 5);
                   }
                   return nextData;
                 });
                 if (gameScore % 5 === 0) {
                   triggerNotification(lang === 'ar' ? '🚀 تم رصد مس الجهد لـ 2160Hz بنجاح!' : '🚀 Excellent 2160Hz instant gesture captured!', 'success');
                 }
               }}
               className="w-24 h-24 rounded-full bg-gradient-to-tr from-emerald-500 to-indigo-600 hover:from-emerald-400 hover:to-indigo-500 shadow-xl shadow-emerald-500/20 flex flex-col items-center justify-center font-bold text-neutral-950 hover:scale-105 active:scale-95 transition-all outline-none cursor-pointer border-2 border-emerald-400"
            >
              <span className="text-2xl font-black font-mono">{gameScore}</span>
              <span className="text-[9px] uppercase tracking-wider">TAP</span>
            </button>

            <div className="flex items-center gap-2">
              <Award className="w-4 h-4 text-amber-500" />
              <span className="text-xs text-neutral-300 font-bold font-mono">Gestures Registered: {gameScore}</span>
            </div>
          </div>

          <div className="p-3 bg-neutral-950/80 rounded-xl border border-neutral-800 flex items-center justify-between text-[11px] text-neutral-500 z-10">
            <span>DND Blockers Active: Messages & Ringing completely isolated</span>
            <span>HyperOS 2160Hz Sensor active</span>
          </div>
        </div>
      ) : (
        /* Regular Game Turbo Control Center panel dashboard */
        <div className="space-y-6">
          {/* Top Header Card */}
          <div className="bg-gradient-to-r from-neutral-900 via-neutral-900 to-emerald-950/20 border border-emerald-500/15 rounded-2xl p-5 relative overflow-hidden">
            <div className="absolute right-0 top-0 w-48 h-48 bg-emerald-600/5 rounded-full blur-3xl pointer-events-none"></div>
            <div className="flex items-start gap-4">
              <div className="bg-emerald-600 text-neutral-950 p-3 rounded-xl shadow-lg ring-4 ring-emerald-600/20">
                <Gamepad2 className="w-6 h-6 animate-bounce" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-neutral-100 flex items-center gap-2">
                  Xiaomi Game Turbo
                  <span className="text-[10px] bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded-full font-mono font-bold tracking-widest uppercase">
                    Dual-Core 6.0
                  </span>
                </h2>
                <p className="text-xs text-neutral-400 mt-1 max-w-2xl leading-relaxed">
                  {t.gameSubtitle}
                </p>
              </div>
            </div>
          </div>

          {/* Performance Mode Selector */}
          <div className="bg-neutral-900 border border-neutral-800/80 p-4 rounded-2xl space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-neutral-300 flex items-center gap-2">
                <Sliders className="w-3.5 h-3.5 text-emerald-400" />
                {lang === 'ar' ? 'حدد وضع الأداء النشط لهيكل الهاتف (SoC Modes)' : 'Active System-on-Chip (SoC) Performance Mode'}
              </span>
              <span className="text-[10px] font-mono font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/25 px-2 py-0.5 rounded uppercase">
                {perfMode === 'battery' ? (lang === 'ar' ? 'توفير البطارية' : 'BATTERY SAVER') :
                 perfMode === 'balanced' ? (lang === 'ar' ? 'متوازن' : 'BALANCED') :
                 perfMode === 'performance' ? (lang === 'ar' ? 'الأداء العالي' : 'HIGH PERFORMANCE') :
                 (lang === 'ar' ? 'معزز توربو النشط' : 'WILDBOOST EXTREME')}
              </span>
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2.5">
              {[
                { id: 'battery', nameAr: 'توفير البطارية 🔋', nameEn: 'Battery Saver 🔋', color: 'text-green-400 border-green-500/20 hover:bg-green-950/10', activeClass: 'bg-green-950/30 border-green-500 text-green-300 shadow shadow-green-500/10' },
                { id: 'balanced', nameAr: 'المتوازن ⚖️', nameEn: 'Balanced ⚖️', color: 'text-cyan-400 border-cyan-500/20 hover:bg-cyan-950/10', activeClass: 'bg-cyan-950/30 border-cyan-500 text-cyan-300 shadow shadow-cyan-500/10' },
                { id: 'performance', nameAr: 'الأداء العالي ⚡', nameEn: 'High Performance ⚡', color: 'text-amber-400 border-amber-500/20 hover:bg-amber-950/10', activeClass: 'bg-amber-950/30 border-amber-500 text-amber-300 shadow shadow-amber-500/10' },
                { id: 'wildboost', nameAr: 'التوربيني الأقصى 🚀', nameEn: 'WildBoost 144Hz 🚀', color: 'text-red-400 border-red-500/20 hover:bg-red-950/10', activeClass: 'bg-red-950/30 border-red-500 text-red-300 shadow shadow-red-500/10 animate-pulse' },
              ].map((m) => {
                const isActive = perfMode === m.id;
                return (
                  <button
                    key={m.id}
                    onClick={() => {
                      setPerfMode(m.id as any);
                      if (m.id === 'wildboost') {
                        setGpuBoost(true);
                      }
                      triggerNotification(
                        lang === 'ar'
                          ? `🔄 تم تحويل وضع المعالج لـ [${m.nameAr}]`
                          : `🔄 Silicon hardware profile shifted to [${m.nameEn}]`,
                        'success'
                      );
                    }}
                    className={`p-3 rounded-xl border text-xs font-bold transition-all text-center flex items-center justify-center cursor-pointer ${
                      isActive ? m.activeClass : `bg-neutral-950 border-neutral-850 text-neutral-400 hover:text-white ${m.color}`
                    }`}
                  >
                    <span>{lang === 'ar' ? m.nameAr : m.nameEn}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Sub Tab selection bar */}
          <div className="flex flex-wrap items-center gap-2 border-b border-neutral-800 pb-3">
            {[
              { id: 'library', label: t.subTabLibrary, icon: <MonitorSmartphone className="w-3.5 h-3.5" /> },
              { id: 'performance', label: t.subTabPerformance, icon: <TrendingUp className="w-3.5 h-3.5" /> },
              { id: 'wildboost', label: t.subTabWildboost, icon: <Flame className="w-3.5 h-3.5" /> },
              { id: 'blocker', label: t.subTabBlocker, icon: <BellOff className="w-3.5 h-3.5" /> }
            ].map((sub) => {
              const isSelected = subTab === sub.id;
              return (
                <button
                  key={sub.id}
                  onClick={() => setSubTab(sub.id as any)}
                  className={`flex items-center gap-2 px-3.5 py-2 text-xs font-bold rounded-lg border transition-all cursor-pointer ${
                    isSelected 
                      ? 'bg-emerald-500 text-neutral-950 border-emerald-400 font-extrabold shadow-md shadow-emerald-500/10'
                      : 'bg-neutral-900/60 border-neutral-800 text-neutral-400 hover:text-white hover:bg-neutral-800/40'
                  }`}
                >
                  {sub.icon}
                  <span>{sub.label}</span>
                </button>
              );
            })}
          </div>

          {/* Sub Tab Content blocks */}
          {subTab === 'library' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
              {/* Left Column Selected game custom configs */}
              <div className="lg:col-span-7 bg-neutral-900/90 border border-neutral-800 rounded-2xl p-5 flex flex-col justify-between">
                <div>
                  <h3 className="text-sm font-bold text-neutral-200 border-b border-neutral-800 pb-2 mb-4 flex items-center justify-between">
                    <span>{lang === 'ar' ? `تهيئات اللعبة: ${activeGameObj.name}` : `Custom Configs for: ${activeGameObj.name}`}</span>
                    <span className="text-[10px] font-mono px-2 py-0.5 bg-neutral-950 text-emerald-400 border border-neutral-800 rounded">
                      {activeGameObj.genre}
                    </span>
                  </h3>

                  <div className="space-y-4">
                    {/* Max Fps Target */}
                    <div className="bg-neutral-950 p-3 rounded-xl border border-neutral-800 flex items-center justify-between">
                      <div className={`text-right ${lang === 'ar' ? 'text-right' : 'text-left'}`}>
                        <p className="text-xs font-bold text-neutral-300">{t.fpsLock}</p>
                        <p className="text-[9px] text-neutral-500">{lang === 'ar' ? 'حدد حاجز معدل الإطارات المحكم' : 'Target frame execution threshold'}</p>
                      </div>
                      <div className="flex items-center gap-1">
                        {([60, 90, 120, 144] as const).map((fps) => {
                          const isTarget = fpsTarget === fps;
                          return (
                            <button
                              key={fps}
                              onClick={() => {
                                setFpsTarget(fps);
                                triggerNotification(`Target FPS lock capped at: ${fps} FPS`, 'success');
                              }}
                              className={`px-2.5 py-1 text-[10px] font-mono font-bold rounded border transition-all cursor-pointer ${
                                isTarget 
                                  ? 'bg-emerald-500 border-emerald-400 text-neutral-950'
                                  : 'bg-neutral-900 border-neutral-800 text-neutral-400 hover:bg-neutral-800'
                              }`}
                            >
                              {fps}
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    {/* Touch Response curve */}
                    <div className="bg-neutral-950 p-3.5 rounded-xl border border-neutral-800 space-y-2">
                      <div className="flex items-center justify-between">
                        <div className={`text-right ${lang === 'ar' ? 'text-right' : 'text-left'}`}>
                          <p className="text-xs font-bold text-neutral-300">{t.touchResponse}</p>
                          <p className="text-[9px] text-neutral-500">{lang === 'ar' ? 'سرعة حساسية الاستجابة لحركات الإيماء' : 'Sub-millisecond gaming touch rate'}</p>
                        </div>
                        <span className="text-xs font-mono font-bold text-emerald-400">{(touchResponse * 21.6).toFixed(0)} Hz</span>
                      </div>
                      <input
                        type="range"
                        min="40"
                        max="100"
                        value={touchResponse}
                        onChange={(e) => setTouchResponse(Number(e.target.value))}
                        className="w-full accent-emerald-500 h-1 bg-neutral-800 rounded-lg appearance-none cursor-pointer"
                      />
                    </div>

                    {/* AI resolution Upscale */}
                    <div className="bg-neutral-950 p-3.5 rounded-xl border border-neutral-800 flex items-center justify-between">
                      <div className={`text-right ${lang === 'ar' ? 'text-right' : 'text-left'}`}>
                        <p className="text-xs font-bold text-neutral-300">{t.resolutionLimit}</p>
                        <p className="text-[9px] text-neutral-500">{lang === 'ar' ? 'مضاعفة بكسلات الشاشة بالذكاء الاصطناعي لـ 2K Ultra HD' : 'Spatial upsampling to 2K clarity'}</p>
                      </div>
                      <button
                        onClick={() => {
                          setAiUpscaling(!aiUpscaling);
                          triggerNotification(
                            aiUpscaling 
                              ? (lang === 'ar' ? 'تم تعطيل الترقية الدقيقة لتوفير الطاقة' : 'AI Super Resolution suspended')
                              : (lang === 'ar' ? 'تم تنشيط ترقية دقة التفاصيل الرسومية لمقاومة التشويش!' : 'AI Resolution upscaling enabled successfully!'),
                            'success'
                          );
                        }}
                        className={`w-10 h-6 rounded-full p-1 transition-all cursor-pointer ${aiUpscaling ? 'bg-emerald-500' : 'bg-neutral-800'}`}
                      >
                        <div className={`w-4 h-4 rounded-full bg-neutral-950 transition-all ${aiUpscaling ? 'translate-x-4' : 'translate-x-0'}`}></div>
                      </button>
                    </div>
                  </div>
                </div>

                <button
                  onClick={handleLaunchGameSpace}
                  className="w-full bg-gradient-to-r from-emerald-500 to-indigo-600 hover:from-emerald-400 hover:to-indigo-500 text-neutral-950 p-4 rounded-xl font-black text-xs transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-emerald-500/10 mt-6"
                >
                  <Play className="w-4 h-4 fill-current" />
                  <span>{t.launchButton}</span>
                </button>
              </div>

              {/* Right Column Games library selection list */}
              <div className="lg:col-span-5 bg-neutral-900/90 border border-neutral-800 rounded-2xl p-5">
                <h3 className="text-sm font-bold text-neutral-200 mb-3 flex items-center gap-2 border-b border-neutral-800 pb-2">
                  <MonitorSmartphone className="w-4 h-4 text-emerald-500" />
                  {t.selectGame}
                </h3>
                <div className="grid grid-cols-1 gap-2.5">
                  {INITIAL_GAMES.map((game) => {
                    const isSelected = selectedGame === game.id;
                    return (
                      <button
                        key={game.id}
                        onClick={() => {
                          setSelectedGame(game.id);
                          triggerNotification(`Switched slot fully to: ${game.name}`, 'success');
                        }}
                        className={`text-right ${lang === 'ar' ? 'text-right' : 'text-left'} p-3.5 rounded-xl border transition-all flex items-center justify-between cursor-pointer ${
                          isSelected
                            ? 'bg-emerald-950/20 border-emerald-500/50 shadow-md ring-1 ring-emerald-500/20'
                            : 'bg-neutral-950 border-neutral-800/80 hover:bg-neutral-800/20'
                        }`}
                      >
                        <div>
                          <p className="text-xs font-extrabold text-neutral-200">{game.name}</p>
                          <p className="text-[10px] text-neutral-500 mt-0.5">{game.genre}</p>
                        </div>
                        <div className="text-left font-mono">
                          <span className="text-[9px] bg-neutral-900 px-2.5 py-1 rounded text-neutral-400 border border-neutral-800 font-bold uppercase whitespace-nowrap">
                            Select Config
                          </span>
                        </div>
                      </button>
                    );
                  })}
                </div>

                <div className="bg-neutral-950 p-4 rounded-xl border border-neutral-800/80 mt-5 space-y-2">
                  <p className="text-xs font-bold text-neutral-300 flex items-center gap-1">
                    <SlidersHorizontal className="w-3.5 h-3.5 text-cyan-400" />
                    {lang === 'ar' ? 'مخطط التحكم الفئوي بميكانيكا اللعبة' : 'Game Space Custom Profile Specs'}
                  </p>
                  <div className="grid grid-cols-2 gap-2 text-[10px]">
                    <div className="bg-neutral-900/40 p-2 rounded border border-neutral-800/60">
                      <span className="text-neutral-500 block">Touch sensitivity</span>
                      <span className="text-neutral-200 font-bold font-mono">{activeGameObj.touchSensitivity}% (Safe limit)</span>
                    </div>
                    <div className="bg-neutral-900/40 p-2 rounded border border-neutral-800/60">
                      <span className="text-neutral-500 block">Antilag Level</span>
                      <span className="text-neutral-200 font-bold font-mono">{activeGameObj.antiLagLevel}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {subTab === 'performance' && (
            <div className="bg-neutral-900/90 border border-neutral-800 rounded-2xl p-5 space-y-6">
              {/* FPS line chart and live values */}
              <div className="flex items-center justify-between border-b border-neutral-800 pb-2 flex-wrap gap-2">
                <h3 className="text-xs font-semibold text-neutral-300 flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-emerald-500" />
                  {t.fpsMonitor}
                </h3>
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-1">
                    <span className="text-2xl font-black font-mono text-emerald-400">
                      {gameFpsData[gameFpsData.length - 1]?.fps || 120} 
                    </span>
                    <span className="text-xs text-neutral-500">{t.fpsUnit}</span>
                  </div>
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping"></span>
                </div>
              </div>

              {/* Dynamic Vector Graph */}
              <div className="h-48 w-full bg-neutral-950 p-4 rounded-xl border border-neutral-800 flex flex-col justify-between">
                {(() => {
                  const width = 500;
                  const height = 120;
                  const minF = 30;
                  const maxF = 160;
                  const points = gameFpsData.map((d, i) => {
                    const denom = gameFpsData.length - 1;
                    const x = denom > 0 ? (i / denom) * width : 0;
                    const y = height - ((d.fps - minF) / (maxF - minF)) * height;
                    return { x, y, fps: d.fps, name: d.name };
                  });
                  const linePath = points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x.toFixed(1)} ${p.y.toFixed(1)}`).join(' ');
                  const closedPath = points.length > 0 ? `${linePath} L ${width} ${height} L 0 ${height} Z` : '';

                  return (
                    <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-full overflow-visible">
                      <defs>
                        <linearGradient id="gradientGameFps" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%" stopColor="#10b981" stopOpacity="0.25" />
                          <stop offset="100%" stopColor="#10b981" stopOpacity="0" />
                        </linearGradient>
                      </defs>
                      <line x1="0" y1={height * 0.25} x2={width} y2={height * 0.25} stroke="#1f1f1f" strokeDasharray="2 2" />
                      <line x1="0" y1={height * 0.5} x2={width} y2={height * 0.5} stroke="#1f1f1f" strokeDasharray="2 2" />
                      <line x1="0" y1={height * 0.75} x2={width} y2={height * 0.75} stroke="#1f1f1f" strokeDasharray="2 2" />

                      {points.length > 0 && <path d={closedPath} fill="url(#gradientGameFps)" />}
                      {points.length > 0 && <path d={linePath} fill="none" stroke="#10b981" strokeWidth="2.5" />}

                      {points.map((p, i) => (
                        <g key={i}>
                          <circle cx={p.x} cy={p.y} r="3.5" fill="#10b981" />
                          <text x={p.x} y={p.y - 10} textAnchor="middle" fill="#10b981" className="text-[10px] font-bold font-mono">{p.fps}</text>
                          <text x={p.x} y={height + 12} textAnchor="middle" fill="#525252" className="text-[8px] font-mono">{p.name}</text>
                        </g>
                      ))}
                    </svg>
                  );
                })()}
              </div>

              {/* Ping latency controls */}
              <div className="bg-neutral-950 p-4 border border-neutral-800 rounded-xl flex items-center justify-between flex-wrap gap-4">
                <div className="flex items-center gap-3">
                  <span className={`w-8 h-8 rounded-lg flex items-center justify-center ${pingValue <= 20 ? 'bg-emerald-950/40 text-emerald-400' : 'bg-amber-950/40 text-amber-400'}`}>
                    <Wifi className="w-4 h-4 animate-pulse" />
                  </span>
                  <div>
                    <p className="text-xs font-bold text-neutral-200">Gaming Edge Ping Latency</p>
                    <p className="text-[10px] text-neutral-500">Dual-Carrier dynamic route selection active</p>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <span className="text-2xl font-black font-mono text-emerald-400">{pingValue} ms</span>
                  <button
                    onClick={launchPingTest}
                    disabled={isMeasuringPing}
                    className="bg-neutral-900 hover:bg-neutral-800 text-neutral-300 font-bold px-3 py-1.5 rounded-lg text-xs border border-neutral-800 hover:border-neutral-700 cursor-pointer"
                  >
                    {isMeasuringPing ? 'Measuring...' : t.testNetwork}
                  </button>
                </div>
              </div>
            </div>
          )}

          {subTab === 'wildboost' && (
            <div className="bg-neutral-900/90 border border-neutral-800 rounded-2xl p-5 space-y-6">
              <h3 className="text-sm font-bold text-neutral-200 flex items-center gap-2 border-b border-neutral-800 pb-2">
                <Flame className="w-4 h-4 text-emerald-400 animate-pulse" />
                WildBoost 3.0 Performance Matrix
              </h3>
              
              <p className="text-xs text-neutral-400 leading-relaxed">
                {lang === 'ar'
                  ? 'بروتوكول تفكيك قيود استهلاك الطاقة لـ Snapdragon Master Core. يقوم بتركيز الـ Threads وعزل العمليات الهامشية لرفع استقرار المشاهد الثقيلة والحرجة بنسبة 24%.'
                  : 'Bypasses standard thermal limiters inside safe silicon thresholds. Unlocks core thread prioritization and eliminates frame pacing micro-stuttering.'}
              </p>

              <div className="space-y-3">
                {/* Switch GPU boost */}
                <div className="p-4 rounded-xl border border-neutral-800 bg-neutral-950 flex items-center justify-between">
                  <div>
                    <h4 className="text-xs font-bold text-neutral-200 flex items-center gap-2">
                      <Zap className="w-4 h-4 text-amber-500" />
                      {t.gpuBoost}
                    </h4>
                    <p className="text-[10px] text-neutral-500 mt-0.5">{gpuBoost ? t.boostOn : t.boostOff}</p>
                  </div>
                  <button
                    onClick={() => {
                      setGpuBoost(!gpuBoost);
                      triggerNotification(gpuBoost ? 'GPU Booster clocks relaxed' : 'Extreme GPU frequency boost initialized!', 'success');
                    }}
                    className={`w-10 h-6 rounded-full p-1 transition-all cursor-pointer ${gpuBoost ? 'bg-emerald-500' : 'bg-neutral-800'}`}
                  >
                    <div className={`w-4 h-4 rounded-full bg-neutral-950 transition-all ${gpuBoost ? 'translate-x-4' : 'translate-x-0'}`}></div>
                  </button>
                </div>

                {/* Overheating Protection dynamic bypass */}
                <div className="p-4 rounded-xl border border-neutral-800 bg-neutral-950 flex items-center justify-between">
                  <div>
                    <h4 className="text-xs font-bold text-neutral-200">WildBoost Instant Shader Cache Compilation</h4>
                    <p className="text-[10px] text-neutral-500 mt-0.5">Pre-compiles shaders to memory pages, bypassing CPU compile wait timers</p>
                  </div>
                  <span className="text-[10px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/25 px-2.5 py-1 rounded font-bold uppercase font-mono">
                    Locked Safe Status
                  </span>
                </div>
              </div>

              <div className="bg-emerald-950/20 border border-emerald-500/15 p-4 rounded-xl flex items-start gap-3">
                <ShieldAlert className="w-5 h-5 text-emerald-400 shrink-0" />
                <div className={`text-right ${lang === 'ar' ? 'text-right' : 'text-left'}`}>
                  <p className="text-xs font-bold text-emerald-300">Esports Liquid cooling optimization active</p>
                  <p className="text-[10px] text-neutral-400 mt-0.5 leading-relaxed">
                    {lang === 'ar'
                      ? 'تم تحسين قنوات توزيع التبريد السائل وغرف التبريد النحاسية تلقائياً للعمل بطاقة متطورة لدعم الـ WildBoost دون حدوث throttling.'
                      : 'Loop-cooling copper cells have been calibrated to handle highest Thermal Design Power (TDP) without frame drops.'}
                  </p>
                </div>
              </div>
            </div>
          )}

          {subTab === 'blocker' && (
            <div className="bg-neutral-900/90 border border-neutral-800 rounded-2xl p-5 space-y-6">
              <div className="border-b border-neutral-800 pb-3 flex items-center justify-between flex-wrap gap-2">
                <div>
                  <h3 className="text-sm font-bold text-neutral-200 flex items-center gap-2">
                    <VolumeX className="w-4 h-4 text-red-500" />
                    {lang === 'ar' ? 'حاجب ومقيد الإشعارات السلكية' : 'Zero-Distraction Gaming Zone'}
                  </h3>
                  <p className="text-xs text-neutral-400 mt-1">
                    {lang === 'ar' ? 'منع الإشعارات والمنبهات والمكالمات في الخلفية تلقائياً للتركيز في اللعب' : 'Block calls and isolate network thread queues for pure console immersion'}
                  </p>
                </div>
                <button
                  onClick={() => {
                    setDndMode(!dndMode);
                    triggerNotification(dndMode ? 'Game DND deactivated' : 'Game DND enabled. Alerts frozen.', 'success');
                  }}
                  className={`w-10 h-6 rounded-full p-1 transition-all cursor-pointer ${dndMode ? 'bg-red-500' : 'bg-neutral-800'}`}
                >
                  <div className={`w-4 h-4 rounded-full bg-neutral-950 transition-all ${dndMode ? 'translate-x-4' : 'translate-x-0'}`}></div>
                </button>
              </div>

              {/* Incoming simulations block */}
              <div className="bg-neutral-950 p-4 rounded-xl border border-neutral-800 space-y-4">
                <p className="text-xs font-bold text-neutral-300">{t.incomingCallTitle}</p>
                <div className="flex flex-wrap gap-2">
                  <button
                    onClick={simulateIncomingCall}
                    className="bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 hover:border-neutral-700 text-neutral-200 font-bold px-3.5 py-2 rounded-xl text-xs transition-all cursor-pointer grow text-center"
                  >
                    📞 {t.blockCallBtn}
                  </button>
                  <button
                    onClick={simulateIncomingSms}
                    className="bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 hover:border-neutral-700 text-neutral-200 font-bold px-3.5 py-2 rounded-xl text-xs transition-all cursor-pointer grow text-center"
                  >
                    ✉️ {t.blockSmsBtn}
                  </button>
                </div>
              </div>

              {/* Log files of block */}
              <div className="space-y-3">
                <p className="text-xs font-bold text-neutral-400 uppercase tracking-widest">{t.blockedLogsTitle}</p>
                
                {blockedItems.length === 0 ? (
                  <p className="text-xs text-neutral-500 italic text-center py-4">No blocked alerts inside current session</p>
                ) : (
                  <div className="space-y-2">
                    {blockedItems.map((item) => (
                      <div key={item.id} className="bg-neutral-950 p-3 rounded-xl border border-neutral-800 flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <span className="text-xs bg-red-950/40 text-red-400 border border-red-500/20 px-2 py-0.5 rounded font-mono uppercase">
                            {item.type}
                          </span>
                          <div className={`text-right ${lang === 'ar' ? 'text-right' : 'text-left'}`}>
                            <p className="text-xs font-bold text-neutral-200">{item.sender}</p>
                            <p className="text-[10px] text-red-400/90 leading-relaxed">{item.text}</p>
                          </div>
                        </div>
                        <span className="font-mono text-[9px] text-neutral-500">{item.time}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
