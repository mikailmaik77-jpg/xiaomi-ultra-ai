import React, { useState, useEffect } from 'react';
import { 
  Camera, 
  RefreshCw, 
  Sliders, 
  ShieldCheck, 
  ZoomIn, 
  Eye, 
  Sparkles, 
  Image as ImageIcon,
  Flame,
  Tv,
  Check,
  Video,
  Moon,
  Smartphone,
  EyeOff,
  User,
  Activity,
  Compass
} from 'lucide-react';

interface CameraStudioProps {
  lang: 'ar' | 'en';
  triggerNotification: (text: string, type?: 'success' | 'error') => void;
}

const translations = {
  ar: {
    cameraStudio: 'استوديو كاميرا الذكاء الاصطناعي',
    cameraSubtitle: 'نظام تصوير Leica الفائق ومجال البؤرة المتغير الحصري لـ Xiaomi Ultra',
    leicaModes: 'أوضاع التصوير الاحترافية Leica',
    authentic: 'لايكا الكلاسيكي (Authentic)',
    vibrant: 'لايكا الحيوي (Vibrant)',
    portrait: 'بورتريه مخصص بالذكاء الاصطناعي',
    night: 'وضع الليل الفائق (Super Night)',
    raw: 'الوضع الاحترافي عالي الدقة RAW Pro',
    apertureSetting: 'فتح وغلق شفرات حدقة عدسة Leica الميكروسكوبية',
    apertureDesc: 'ميكانيكا حقيقية بفتحة العدسة تعدل عمق العزل البؤري والتمويه الخلفي (Bokeh)',
    activeAperture: 'الفتحة النشطة',
    filters: 'عناصر المعالجة العصبية المستندة للـ NPU',
    noise: 'خفض الضجيج وإزالة الحبيبات الرقمية',
    blur: 'معالجة الاهتزاز والضبابية الحركية',
    highlight: 'إضاءة البورتريه الليلي الذكي',
    upscale: 'ترقية الدقة الفائقة Leica Master 4x',
    interactivePreview: 'مقارن المعاينة الناتجة (قبل وبعد التدخل)',
    dragSlider: 'اسحب الفاصل لمشاهدة تأثير الترقية والـ HDR الفوري',
    processing: 'جاري تشغيل المعالجات وتعديل تباين العدسة...',
    enhanceSuccess: 'تمت إعادة الإعمار ومعاينة النسبة اللونية بنجاح!',
    presetTitle: 'اختر مشهدًا ميدانيًا لاختبار عدسة Leica:',
    presetSunset: 'بورتريه الغروب الدافئ',
    presetCairo: 'أضواء القاهرة المعقدة ليلاً',
    presetSpeed: 'ثبات فائق لسيارات السباق السريعة',
    depthLevel: 'مستوى عزل الخلفية المحاكي',
    depthLow: 'عزل خلفي ضئيل (خلفية حادة)',
    depthHigh: 'عزل خلفي عميق سينمائي (f/1.4)',
    actionApply: 'تطبيق فوري لفلتر Leica الذكي ✨',
    
    // Arabic Extra translations
    subTabShoot: 'عدسة Leica وعزل البؤرة',
    subTabEnhance: 'ترقية الوضوح AI Enhance',
    subTabNight: 'الاندماج الليلي Super Night',
    subTabStabilize: 'فيديو احترافي وثبات ميكانيكي',
    
    exposureLabel: 'وقت تجميع الفوتونات الضوئية (ISO)',
    sharpnessLabel: 'التعرف على وجوه البورتريه الذكي',
    nightProgress1: 'جاري حصد حزم فوتونات الضوء على مستشعر 1 بوصة...',
    nightProgress2: 'جاري صهر وتجميع 16 إطار RAW معاً...',
    nightProgress3: 'جاري تصحيح تباين ضوء الخلفية المتشتت...',
    nightProgress4: 'تم تفريغ الصورة بدقة لا تصدق!',
    nightBtn: 'بدء التقاط فائق السطوع (4 ثوان)',
    vibrationLevel: 'محور الاهتزاز الفعلي المكتشف',
    stabilizationOn: 'تنشيط مانع الاهتزاز البصري OIS السلكي للهاتف',
    motionVectorsTitle: 'مصفوفة تتبع النبضات الحركية الفورية'
  },
  en: {
    cameraStudio: 'AI Camera Studio',
    cameraSubtitle: 'Flagship Leica optics & Variable Aperture computational engine for Xiaomi Ultra',
    leicaModes: 'Leica Custom Capture Modes',
    authentic: 'Leica Authentic Style',
    vibrant: 'Leica Vibrant Style',
    portrait: 'AI Neural Portrait Master',
    night: 'Super Night 2.0 Ultra',
    raw: '14-bit RAW Pro Studio',
    apertureSetting: 'Variable Physical Aperture Blade Dial',
    apertureDesc: 'Real electro-mechanical blades adjust depth of field and soft background blur (Bokeh)',
    activeAperture: 'Active Aperture',
    filters: 'NPU Neural Lens Processing Units',
    noise: 'ISO Noise Reduction Filter',
    blur: 'Anti-Shake & Blur Reconstruction',
    highlight: 'Active Night Glow Enhancement',
    upscale: 'Leica Master 4x Upscaler',
    interactivePreview: 'Simulated Lens Matrix (Before vs After)',
    dragSlider: 'Drag slider to reveal Leica AI Neural Reconstruction',
    processing: 'Running NPU image reconstructor & computing depth map...',
    enhanceSuccess: 'Image reconstructed successfully with Xiaomi Master Engine!',
    presetTitle: 'Choose Photo Preset to Test Processing:',
    presetSunset: 'Warm Sunset Portrait',
    presetCairo: 'Intricate City Night Detail',
    presetSpeed: 'High-speed Track Shot (Frozen Action)',
    depthLevel: 'Simulated Background Blur (Bokeh)',
    depthLow: 'Low Blur (Sharp background)',
    depthHigh: 'Deep Cinematic Bokeh (Maximum light)',
    actionApply: 'Trigger Leica Master AI ✨',
    
    // English Extra translations
    subTabShoot: 'Leica Viewport & Bokeh',
    subTabEnhance: 'AI Clarity Super Resolution',
    subTabNight: 'Super Night Frame Fusion',
    subTabStabilize: 'EIS / OIS Video Stabilizer',
    
    exposureLabel: 'Sensor Photon Acquisition (ISO Bound)',
    sharpnessLabel: 'Facial detail reconstruction factor',
    nightProgress1: 'Acquiring photon flow in large 1-inch physical sensor...',
    nightProgress2: 'Synthesizing 16 high-range RAW exposures...',
    nightProgress3: 'Calibrating dynamic dark field contrast...',
    nightProgress4: 'Night frame reconstructed beautifully!',
    nightBtn: 'Capture LowLight frame (4s Synthesize)',
    vibrationLevel: 'Realtime Gyroscope Vibration Feed',
    stabilizationOn: 'Locked Active Optical Stabilization (OIS/EIS)',
    motionVectorsTitle: 'Live Frame Alignment Tracking Vectors'
  }
};

const PRESET_PHOTOS = [
  {
    id: 'sunset',
    nameAr: 'بورتريه الغروب الدافئ',
    nameEn: 'Warm Sunset Portrait',
    url: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?q=80&w=800',
    beforeStyle: 'filter brightness-[0.75] contrast-[0.9] saturate-[0.85] blur-[1px]',
    afterStyle: 'filter brightness-[1.05] contrast-[1.15] saturate-[1.1] shadow-xl'
  },
  {
    id: 'cairo',
    nameAr: 'أضواء القاهرة المعقدة ليلاً',
    nameEn: 'Intricate City Night Detail',
    url: 'https://images.unsplash.com/photo-1506157786151-b8491531f063?q=80&w=800',
    beforeStyle: 'filter brightness-[0.6] contrast-[0.9] saturate-[0.7]',
    afterStyle: 'filter brightness-[1.15] contrast-[1.25] saturate-[1.2] drop-shadow-2xl'
  },
  {
    id: 'speed',
    nameAr: 'ثبات فائق لسيارات السباق السريعة',
    nameEn: 'High-speed Track Shot (Frozen Action)',
    url: 'https://images.unsplash.com/photo-1568605117036-5fe5e7bab0b7?q=80&w=800',
    beforeStyle: 'filter blur-[3px] brightness-[0.85] saturate-[0.9]',
    afterStyle: 'filter blur-0 brightness-[1.05] contrast-[1.1] saturate-[1.05]'
  }
];

export default function CameraStudio({ lang, triggerNotification }: CameraStudioProps) {
  const t = translations[lang];

  // Primary sub tab
  const [subTab, setSubTab] = useState<'shoot' | 'enhance' | 'night' | 'stabilize'>('shoot');

  // Camera Settings state
  const [selectedMode, setSelectedMode] = useState<string>('authentic');
  const [aperture, setAperture] = useState<number>(1.4); // f/1.4, f/1.8, f/2.0, f/2.8, f/4.0
  const [activeFilters, setActiveFilters] = useState<string[]>(['noise', 'blur']);
  const [selectedPreset, setSelectedPreset] = useState<string>('sunset');
  const [sliderPosition, setSliderPosition] = useState<number>(50);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);

  // Real Camera Streaming state
  const [webcamStream, setWebcamStream] = useState<MediaStream | null>(null);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [flashActive, setFlashActive] = useState<boolean>(false);
  
  const videoRefAfter = React.useRef<HTMLVideoElement | null>(null);
  const videoRefBefore = React.useRef<HTMLVideoElement | null>(null);

  // Clean up stream on unmount
  useEffect(() => {
    return () => {
      if (webcamStream) {
        webcamStream.getTracks().forEach((track) => track.stop());
      }
    };
  }, [webcamStream]);

  const toggleCamera = async () => {
    try {
      if (webcamStream) {
        webcamStream.getTracks().forEach((track) => track.stop());
        setWebcamStream(null);
        setCapturedImage(null);
        triggerNotification(lang === 'ar' ? 'تم إيقاف كاميرا الجهاز.' : 'Device camera stopped.', 'success');
        return;
      }
      if (typeof window === 'undefined' || !navigator || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        triggerNotification(lang === 'ar' ? '⚠️ الكاميرا الحقيقية غير مدعومة في متصفحك أو داخل هذا الإطار.' : '⚠️ Real webcam is not supported in this browser or iframe context.', 'error');
        return;
      }
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'user', width: { ideal: 1280 }, height: { ideal: 720 } }
      });
      setWebcamStream(stream);
      setCapturedImage(null);
      triggerNotification(lang === 'ar' ? 'تم الاتصال بكاميرا الجهاز بنجاح! المعاينة حية والفلترة بالذكاء الاصطناعي نشطة.' : 'Connected to device camera. Real-time AI filter active.', 'success');
    } catch (err) {
      console.error('Webcam stream error:', err);
      triggerNotification(lang === 'ar' ? '⚠️ فشل الاتصال بالكاميرا. يرجى السماح بصلاحيات الوصول للكاميرا.' : '⚠️ Failed to connect to camera. Please grant frame permissions.', 'error');
    }
  };

  const playSnapshotSound = () => {
    try {
      if (typeof window === 'undefined') return;
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) {
        console.warn('AudioContext not supported in this environment');
        return;
      }
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      
      osc.type = 'sine';
      osc.frequency.setValueAtTime(1000, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(800, ctx.currentTime + 0.1);
      
      gain.gain.setValueAtTime(0.3, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.08);
      
      osc.start(ctx.currentTime);
      osc.stop(ctx.currentTime + 0.1);
    } catch (err) {
      console.error('AudioContext sound blocked or unavailable:', err);
    }
  };

  const takeSnapshot = () => {
    setFlashActive(true);
    playSnapshotSound();
    setTimeout(() => setFlashActive(false), 200);

    let screenshotUrl = '';
    try {
      if (webcamStream && videoRefAfter.current) {
        const video = videoRefAfter.current;
        const canvas = document.createElement('canvas');
        canvas.width = video.videoWidth || 640;
        canvas.height = video.videoHeight || 480;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.translate(canvas.width, 0);
          ctx.scale(-1, 1); // Flip front camera
          ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
          screenshotUrl = canvas.toDataURL('image/jpeg');
        }
      } else {
        screenshotUrl = currentPreset.url;
      }
    } catch (e) {
      screenshotUrl = currentPreset.url;
    }

    setTimeout(() => {
      setCapturedImage(screenshotUrl);
      if (webcamStream) {
        webcamStream.getTracks().forEach((track) => track.stop());
        setWebcamStream(null);
      }
      triggerNotification(
        lang === 'ar' 
          ? '📸 تم التقاط وحفظ إطار بدقة Ultra NPU! خضع لمعالجة لايكا الحيوية.' 
          : '📸 Captured frame with Ultra NPU resolution! Advanced computational filter applied.', 
        'success'
      );
    }, 300);
  };

  // Dynamic Leica and NPU filters mapping
  const getCameraFilter = (isBefore: boolean) => {
    if (isBefore) {
      return `blur(${getBlurPixels() + 3}px) brightness(0.65) saturate(0.75) contrast(0.9)`;
    }
    
    let filters = '';
    const blurPx = Math.max(0, getBlurPixels() - (activeFilters.includes('blur') ? 6 : 0));
    if (blurPx > 0) {
      filters += `blur(${blurPx}px) `;
    }
    
    if (selectedMode === 'authentic') {
      filters += `contrast(1.25) brightness(0.95) saturate(0.9) sepia(0.05) `;
    } else if (selectedMode === 'vibrant') {
      filters += `contrast(1.15) brightness(1.05) saturate(1.4) `;
    } else if (selectedMode === 'portrait') {
      filters += `contrast(1.05) brightness(1.15) saturate(1.1) `;
    } else if (selectedMode === 'raw') {
      filters += `contrast(1.1) brightness(1.0) saturate(1.05) `;
    }
    
    if (subTab === 'enhance') {
      const b = 1 + (hdrLevel - 70) / 250;
      const c = 1 + (hdrLevel - 70) / 120;
      const s = 1 + (hdrLevel - 70) / 180;
      filters += `brightness(${b}) contrast(${c}) saturate(${s}) `;
    }
    
    return filters.trim();
  };

  // Hook up streams to video elements across all tabs
  useEffect(() => {
    if (webcamStream) {
      setTimeout(() => {
        if (videoRefAfter.current) {
          videoRefAfter.current.srcObject = webcamStream;
          videoRefAfter.current.play().catch(e => console.log('play error after', e));
        }
        if (videoRefBefore.current) {
          videoRefBefore.current.srcObject = webcamStream;
          videoRefBefore.current.play().catch(e => console.log('play error before', e));
        }
      }, 150);
    }
  }, [webcamStream, subTab]);

  // Enhance parameters
  const [sharpnessLevel, setSharpnessLevel] = useState<number>(85); // %
  const [hdrLevel, setHdrLevel] = useState<number>(90); // %

  // Night Mode capture states
  const [nightCapturing, setNightCapturing] = useState<boolean>(false);
  const [nightProgressMsg, setNightProgressMsg] = useState<string>('');
  const [nightProgressVal, setNightProgressVal] = useState<number>(0);
  const [nightSuccessPhoto, setNightSuccessPhoto] = useState<boolean>(false);

  // Video stabilization states
  const [stabilizationActive, setStabilizationActive] = useState<boolean>(true);
  const [smoothZoom, setSmoothZoom] = useState<number>(1); // x
  const [vibrationTick, setVibrationTick] = useState<number>(0);

  const toggleFilter = (filterKey: string) => {
    if (activeFilters.includes(filterKey)) {
      setActiveFilters(activeFilters.filter((f) => f !== filterKey));
    } else {
      setActiveFilters([...activeFilters, filterKey]);
    }
  };

  const handleApplyAI = () => {
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      triggerNotification(t.enhanceSuccess, 'success');
    }, 1200);
  };

  // Run dynamic vibrations when stabilizing tab is active
  useEffect(() => {
    const timer = setInterval(() => {
      setVibrationTick((prev) => {
        // Multiplier changes based on whether stabilization is active
        const intensity = stabilizationActive ? 1.5 : 8.0;
        const offset = (Math.random() * intensity - intensity / 2);
        return parseFloat(offset.toFixed(1));
      });
    }, 150);

    return () => clearInterval(timer);
  }, [stabilizationActive]);

  const currentPreset = PRESET_PHOTOS.find((p) => p.id === selectedPreset) || PRESET_PHOTOS[0];

  const getBlurPixels = () => {
    const baseBlur = aperture === 1.4 ? 10 : aperture === 1.8 ? 6 : aperture === 2.0 ? 4 : aperture === 2.8 ? 2 : 0;
    return baseBlur;
  };

  const runSuperNightSynthesis = () => {
    setNightCapturing(true);
    setNightProgressVal(0);
    setNightSuccessPhoto(false);
    setNightProgressMsg(t.nightProgress1);

    setTimeout(() => {
      setNightProgressVal(25);
      setNightProgressMsg(t.nightProgress2);
    }, 1000);

    setTimeout(() => {
      setNightProgressVal(60);
      setNightProgressMsg(t.nightProgress3);
    }, 2000);

    setTimeout(() => {
      setNightProgressVal(90);
      setNightProgressMsg(t.nightProgress4);
    }, 3000);

    setTimeout(() => {
      setNightProgressVal(100);
      setNightCapturing(false);
      setNightSuccessPhoto(true);
      triggerNotification(lang === 'ar' ? '🌌 اكتمل صهر خلايا الوضع الليلي بمستشعر 1 بوصة للقطة مضيئة!' : '🌌 Large sensor 1-inch photo fusion complete successfully!', 'success');
    }, 4000);
  };

  return (
    <div className="space-y-6" id="ai-camera-studio-section">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-red-950/40 via-neutral-900 to-neutral-900 border border-red-500/15 rounded-2xl p-5 relative overflow-hidden">
        <div className="absolute right-0 top-0 w-48 h-48 bg-red-600/5 rounded-full blur-3xl pointer-events-none"></div>
        <div className="flex items-start gap-4">
          <div className="bg-red-600 text-white p-3 rounded-xl shadow-lg ring-4 ring-red-600/20">
            <Camera className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-neutral-100 flex items-center gap-2">
              {t.cameraStudio}
              <span className="text-[10px] bg-red-600/30 text-red-400 border border-red-500/40 px-2 py-0.5 rounded-full font-mono font-bold uppercase tracking-wider">
                Leica 1-inch NPU
              </span>
            </h2>
            <p className="text-xs text-neutral-400 mt-1 max-w-2xl leading-relaxed">
              {t.cameraSubtitle}
            </p>
          </div>
        </div>
      </div>

      {/* Internal Navigation Sub-tabs */}
      <div className="flex flex-wrap items-center gap-2 border-b border-neutral-800 pb-3">
        {[
          { id: 'shoot', label: t.subTabShoot, icon: <Camera className="w-3.5 h-3.5" /> },
          { id: 'enhance', label: t.subTabEnhance, icon: <Sparkles className="w-3.5 h-3.5" /> },
          { id: 'night', label: t.subTabNight, icon: <Moon className="w-3.5 h-3.5" /> },
          { id: 'stabilize', label: t.subTabStabilize, icon: <Video className="w-3.5 h-3.5" /> }
        ].map((sub) => {
          const isSelected = subTab === sub.id;
          return (
            <button
              key={sub.id}
              onClick={() => setSubTab(sub.id as any)}
              className={`flex items-center gap-2 px-3.5 py-2 text-xs font-bold rounded-lg border transition-all cursor-pointer ${
                isSelected 
                  ? 'bg-red-600 text-white border-red-400 font-extrabold shadow-md shadow-red-600/10'
                  : 'bg-neutral-900/60 border-neutral-800 text-neutral-400 hover:text-white hover:bg-neutral-800/40'
              }`}
            >
              {sub.icon}
              <span>{sub.label}</span>
            </button>
          );
        })}
      </div>

      {subTab === 'shoot' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Controls column */}
          <div className="lg:col-span-5 space-y-6">
            
            {/* Mode selection block */}
            <div className="bg-neutral-900/90 border border-neutral-800 rounded-2xl p-5">
              <h3 className="text-xs font-bold text-neutral-200 mb-3 flex items-center gap-2 border-b border-neutral-800 pb-2">
                <Sliders className="w-4 h-4 text-red-500" />
                {t.leicaModes}
              </h3>
              <div className="grid grid-cols-1 gap-2">
                {[
                  { id: 'authentic', label: t.authentic, desc: 'Classic Leica vignette, dynamic shadows.' },
                  { id: 'vibrant', label: t.vibrant, desc: 'Lively hues, dynamic highlight rendering.' },
                  { id: 'portrait', label: t.portrait, desc: 'Flawless skin tones & 3D face structure scan.' },
                  { id: 'raw', label: t.raw, desc: 'Full 14-bit professional photo grading raw sensor.' }
                ].map((m) => (
                  <button
                    key={m.id}
                    onClick={() => {
                      setSelectedMode(m.id);
                      triggerNotification(`Active Lens Profile: ${m.label}`, 'success');
                    }}
                    className={`text-right ${lang === 'ar' ? 'text-right' : 'text-left'} p-3 rounded-xl transition-all border flex flex-col gap-0.5 cursor-pointer ${
                      selectedMode === m.id
                        ? 'bg-red-950/20 border-red-500/50 shadow-md ring-1 ring-red-500/15'
                        : 'bg-neutral-950/40 border-neutral-800/80 hover:bg-neutral-800/20'
                    }`}
                  >
                    <span className="text-xs font-bold text-neutral-200 flex items-center justify-between">
                      {m.label}
                      {selectedMode === m.id && (
                        <span className="w-1.5 h-1.5 rounded-full bg-red-500 ring-4 ring-red-500/20"></span>
                      )}
                    </span>
                    <span className="text-[10px] text-neutral-500 line-clamp-1">{m.desc}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Aperture selection block */}
            <div className="bg-neutral-900/90 border border-neutral-800 rounded-2xl p-5">
              <h3 className="text-xs font-bold text-neutral-200 mb-1 flex items-center gap-2">
                <ZoomIn className="w-4 h-4 text-amber-500" />
                {t.apertureSetting}
              </h3>
              <p className="text-[10px] text-neutral-500 mb-4">{t.apertureDesc}</p>

              <div className="flex items-center justify-around py-2.5 bg-neutral-950 rounded-xl border border-neutral-800">
                {[1.4, 1.8, 2.0, 2.8, 4.0].map((num) => (
                  <button
                    key={num}
                    onClick={() => {
                      setAperture(num);
                      triggerNotification(`Leica variable focal adjusted f/${num}`, 'success');
                    }}
                    className={`w-11 h-11 rounded-full flex flex-col items-center justify-center transition-all cursor-pointer ${
                      aperture === num
                        ? 'bg-gradient-to-b from-amber-500 to-amber-600 text-neutral-950 font-black shadow-lg ring-4 ring-amber-500/20'
                        : 'bg-neutral-900 text-neutral-400 hover:text-white border border-neutral-800'
                    }`}
                  >
                    <span className="text-[8px] uppercase font-mono">f/</span>
                    <span className="text-xs font-mono font-bold">{num}</span>
                  </button>
                ))}
              </div>

              <div className="mt-4 p-2.5 rounded-lg bg-amber-500/5 border border-amber-500/10 text-[10px] text-amber-300 flex items-center justify-between">
                <span>{t.activeAperture}: <strong className="font-mono">f/{aperture}</strong></span>
                <span>{aperture <= 1.8 ? t.depthHigh : t.depthLow}</span>
              </div>
            </div>
          </div>

          {/* Right Preview column */}
          <div className="lg:col-span-7 space-y-4">
            <div className="bg-neutral-900/90 border border-neutral-800 rounded-2xl p-5 flex flex-col h-full justify-between">
              <div>
                <div className="flex items-center justify-between mb-4 border-b border-neutral-800 pb-2">
                  <h3 className="text-xs font-bold text-neutral-200 flex items-center gap-2">
                    <Eye className="w-4 h-4 text-red-500 animate-pulse" />
                    {t.interactivePreview}
                  </h3>
                  <div className="flex items-center gap-1.5 text-[9px] font-mono font-bold text-neutral-400">
                    <span className="px-1.5 py-0.5 rounded bg-neutral-950 text-neutral-500">RAW BEFORE</span>
                    <span>▶</span>
                    <span className="px-1.5 py-0.5 rounded bg-red-600/15 text-red-400">LEICA HARMONIZED</span>
                  </div>
                </div>

                {/* Preset scene picker */}
                <div className="mb-4 space-y-2.5">
                  <div className="flex items-center justify-between">
                    <p className="text-[10px] text-neutral-400">{t.presetTitle}</p>
                    <button
                      onClick={toggleCamera}
                      className={`flex items-center gap-1.5 px-3 py-1 rounded-lg border text-[9px] font-bold font-mono transition-all cursor-pointer ${
                        webcamStream 
                          ? 'bg-emerald-500 text-neutral-950 border-emerald-400 animate-pulse' 
                          : 'bg-neutral-950 border-neutral-800 text-neutral-300 hover:text-white hover:bg-neutral-850'
                      }`}
                    >
                      <Camera className="w-3 h-3" />
                      <span>
                        {webcamStream
                          ? (lang === 'ar' ? 'إيقاف البث الحي 🟢' : 'STOP LIVE CAM 🟢')
                          : (lang === 'ar' ? 'تشغيل الكاميرا الحقيقية' : 'USE REAL WEBCAM')}
                      </span>
                    </button>
                  </div>
                  
                  {capturedImage && (
                    <div className="flex items-center justify-between p-2 rounded-xl bg-cyan-950/20 border border-cyan-500/30">
                      <span className="text-[9px] text-cyan-400 font-bold">{lang === 'ar' ? 'تم التقاط صورة من كاميرتك 📸' : 'Snapshot captured from your camera! 📸'}</span>
                      <button
                        onClick={() => setCapturedImage(null)}
                        className="text-[8px] font-bold bg-neutral-800 border border-neutral-700 px-2 py-1 rounded text-red-400 hover:bg-red-950/25 cursor-pointer"
                      >
                        {lang === 'ar' ? 'إعادة تعيين' : 'Clear Snapshot'}
                      </button>
                    </div>
                  )}

                  {!webcamStream && (
                    <div className="grid grid-cols-3 gap-2">
                      {PRESET_PHOTOS.map((pres) => (
                        <button
                          key={pres.id}
                          disabled={!!capturedImage}
                          onClick={() => {
                            setSelectedPreset(pres.id);
                            triggerNotification(`Loaded preset scenario: ${lang === 'ar' ? pres.nameAr : pres.nameEn}`, 'success');
                          }}
                          className={`p-2 rounded-xl border text-[9px] font-bold transition-all cursor-pointer disabled:opacity-30 ${
                            selectedPreset === pres.id && !capturedImage
                              ? 'bg-red-500/15 border-red-500 text-red-300 font-extrabold'
                              : 'bg-neutral-950 border-neutral-800 text-neutral-400 hover:bg-neutral-800/40'
                          }`}
                        >
                          {lang === 'ar' ? pres.nameAr : pres.nameEn}
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                {/* Slider Image/Video Viewer */}
                <div className="relative aspect-[4/3] rounded-xl overflow-hidden bg-black border border-neutral-800 select-none group">
                  {/* Layer After */}
                  {webcamStream ? (
                    <video
                      ref={videoRefAfter}
                      autoPlay
                      playsInline
                      muted
                      className="absolute inset-0 w-full h-full object-cover scale-x-[-1]"
                      style={{
                        filter: getCameraFilter(false)
                      }}
                    />
                  ) : (
                    <img
                      src={capturedImage || currentPreset.url}
                      alt="After Processing"
                      referrerPolicy="no-referrer"
                      className={`absolute inset-0 w-full h-full object-cover transition-all duration-300 ${capturedImage ? '' : currentPreset.afterStyle}`}
                      style={{
                        filter: getCameraFilter(false)
                      }}
                    />
                  )}

                  {/* Layer Before (clipped) */}
                  <div
                    className="absolute inset-0 w-full h-full object-cover overflow-hidden pointer-events-none border-r-2 border-red-500"
                    style={{ clipPath: `polygon(0 0, ${sliderPosition}% 0, ${sliderPosition}% 100%, 0 100%)` }}
                  >
                    {webcamStream ? (
                      <video
                        ref={videoRefBefore}
                        autoPlay
                        playsInline
                        muted
                        className="absolute inset-0 w-full h-full object-cover scale-x-[-1]"
                        style={{
                          width: '100%',
                          maxWidth: 'none',
                          filter: getCameraFilter(true)
                        }}
                      />
                    ) : (
                      <img
                        src={capturedImage || currentPreset.url}
                        alt="Original Raw"
                        referrerPolicy="no-referrer"
                        className={`absolute inset-0 w-full h-full object-cover ${capturedImage ? 'filter blur-[1.5px] brightness-[0.7]' : currentPreset.beforeStyle}`}
                        style={{
                          width: '100%',
                          maxWidth: 'none',
                          filter: getCameraFilter(true)
                        }}
                      />
                    )}
                    <div className="absolute top-3 left-3 bg-black/75 backdrop-blur-md px-2.5 py-1 rounded text-[8px] font-mono text-neutral-400 border border-neutral-800 tracking-wider">
                      RAW UNOPTIMIZED
                    </div>
                  </div>

                  {/* Layer after flag */}
                  <div className="absolute top-3 right-3 bg-red-600/85 backdrop-blur-md px-2.5 py-1 rounded text-[8px] font-mono text-white border border-red-500 tracking-wider font-bold">
                    {lang === 'ar' ? 'معالجة الخلايا العصبية لايكا' : 'LEICA FUSION COPROCESSOR'}
                  </div>

                  {/* Flash animation */}
                  {flashActive && (
                    <div className="absolute inset-0 bg-white z-40 transition-opacity duration-300 pointer-events-none animate-flash"></div>
                  )}

                  {/* Shutter button for snapshot */}
                  {webcamStream && (
                    <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-30">
                      <button
                        onClick={takeSnapshot}
                        type="button"
                        className="w-14 h-14 bg-red-600 border-4 border-white hover:bg-red-500 rounded-full flex items-center justify-center shadow-2xl transition-all cursor-pointer transform hover:scale-105 active:scale-95"
                        title={lang === 'ar' ? 'التقاط الصورة وحساب التباين' : 'Take Neural Snapshot'}
                      >
                        <Camera className="w-6 h-6 text-white" />
                      </button>
                    </div>
                  )}

                  {/* Grabber line indicator */}
                  <div 
                    className="absolute inset-y-0 w-1 bg-red-500 group-hover:bg-red-400 cursor-ew-resize flex items-center justify-center"
                    style={{ left: `${sliderPosition}%` }}
                  >
                    <div className="w-6 h-6 bg-red-600 text-white rounded-full flex items-center justify-center shadow-lg border border-neutral-100 text-xs font-mono font-bold select-none -translate-x-1/2">
                      ↔
                    </div>
                  </div>

                  {/* Range input element */}
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={sliderPosition}
                    onChange={(e) => setSliderPosition(Number(e.target.value))}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-ew-resize z-10"
                  />
                </div>

                <p className="text-[10px] text-center text-neutral-500 mt-2.5">
                  {t.dragSlider}
                </p>
              </div>

              <div className="mt-6 pt-4 border-t border-neutral-800/60">
                <button
                  onClick={handleApplyAI}
                  disabled={isProcessing}
                  className="w-full bg-gradient-to-r from-red-600 to-amber-600 hover:from-red-500 hover:to-amber-500 text-white p-3.5 rounded-xl font-bold text-xs transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg disabled:opacity-50"
                >
                  {isProcessing ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>{t.processing}</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4" />
                      <span>{t.actionApply}</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {subTab === 'enhance' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Parameter controls and status */}
          <div className="lg:col-span-5 space-y-6">
            <div className="bg-neutral-900/90 border border-neutral-800 rounded-2xl p-5 space-y-4">
              <div className="border-b border-neutral-800 pb-3">
                <h3 className="text-sm font-bold text-neutral-200 flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-red-500" />
                  {t.subTabEnhance}
                </h3>
                <p className="text-xs text-neutral-400 mt-1 leading-relaxed">
                  {lang === 'ar' ? 'تصحيح حدة الغلاف البكسلي واستعادة ألوان النطاق العريض بتوافق NPU ذكي' : 'Reconstruction of sub-pixel micro details using local NPU neural networks'}
                </p>
              </div>

              {/* Controllers for parameters */}
              <div className="space-y-4">
                <div className="space-y-3">
                  <div className="space-y-1">
                    <div className="flex items-center justify-between text-xs text-neutral-400">
                      <span>{t.sharpnessLabel}</span>
                      <span className="font-mono text-neutral-200 font-bold">{sharpnessLevel}%</span>
                    </div>
                    <input
                      type="range"
                      min="30"
                      max="100"
                      value={sharpnessLevel}
                      onChange={(e) => setSharpnessLevel(Number(e.target.value))}
                      className="w-full accent-red-500 h-1 bg-neutral-800 rounded appearance-none cursor-pointer"
                    />
                    <div className="flex justify-between text-[9px] text-neutral-500 font-mono pt-1">
                      <span>30% (Standard)</span>
                      <span>100% (Maximum Sharpness)</span>
                    </div>
                  </div>

                  <div className="space-y-1">
                    <div className="flex items-center justify-between text-xs text-neutral-400">
                      <span>Leica Super Contrast HDR Dynamic</span>
                      <span className="font-mono text-neutral-200 font-bold">{hdrLevel}%</span>
                    </div>
                    <input
                      type="range"
                      min="40"
                      max="100"
                      value={hdrLevel}
                      onChange={(e) => setHdrLevel(Number(e.target.value))}
                      className="w-full accent-red-500 h-1 bg-neutral-800 rounded appearance-none cursor-pointer"
                    />
                    <div className="flex justify-between text-[9px] text-neutral-500 font-mono pt-1">
                      <span>40% (Natural)</span>
                      <span>100% (Vivid AI HDR)</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Simulated Live status and Apply area */}
            <div className="bg-neutral-900/90 border border-neutral-800 rounded-2xl p-5 flex flex-col justify-between space-y-4">
              <div className="space-y-2">
                <p className="text-xs font-bold text-neutral-300 flex items-center justify-between">
                  <span>Leica High-Frequency Coprocessor Status</span>
                  <span className="flex items-center gap-1.5 text-[10px] text-emerald-400 font-semibold font-mono bg-emerald-500/10 border border-emerald-500/20 px-1.5 py-0.5 rounded-full">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                    ACTIVE
                  </span>
                </p>
                <div className="space-y-1 text-xs text-neutral-400 list-disc list-inside font-mono">
                  <p>• Multi-Exposure matrix mapping: {hdrLevel > 80 ? 'Ultra 4-exposure enabled' : 'Standard dual-iso depth'}</p>
                  <p>• Denoising filter scale: Calculated dynamic {sharpnessLevel * 14} Gigaflops</p>
                  <p>• Output Domain: 14-bit DNG with Master Colour Tuning</p>
                </div>
              </div>

              <button
                onClick={handleApplyAI}
                disabled={isProcessing}
                className="w-full bg-gradient-to-r from-red-600 to-amber-600 hover:from-red-500 hover:to-amber-500 text-white font-bold p-3.5 rounded-xl text-xs transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg disabled:opacity-50"
              >
                {isProcessing ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>{lang === 'ar' ? 'جاري شحذ مصفوفة البكسلات...' : 'Sharpening pixel layers...'}</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>{lang === 'ar' ? 'تطبيق تحسين الوضوح الفوري ✨' : 'Enhance Selected Scene 🚀'}</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Right Column: Interactive Before/After comparison slider */}
          <div className="lg:col-span-7 space-y-4">
            <div className="bg-neutral-900/90 border border-neutral-800 rounded-2xl p-5 flex flex-col h-full justify-between">
              <div>
                <div className="flex items-center justify-between mb-4 border-b border-neutral-800 pb-2">
                  <h3 className="text-xs font-bold text-neutral-200 flex items-center gap-2">
                    <Eye className="w-4 h-4 text-red-500 animate-pulse" />
                    {lang === 'ar' ? 'مقارنة تأثير الترقية والوضوح (قبل / بعد)' : 'AI Super Resolution Comparison (Before / After)'}
                  </h3>
                  <div className="flex items-center gap-1.5 text-[9px] font-mono font-bold text-neutral-400">
                    <span className="px-1.5 py-0.5 rounded bg-neutral-950 text-neutral-500">RAW BEFORE</span>
                    <span>▶</span>
                    <span className="px-1.5 py-0.5 rounded bg-red-600/15 text-red-400">AI ENHANCED</span>
                  </div>
                </div>

                {/* Preset scene picker */}
                <div className="mb-4 space-y-2">
                  <div className="flex items-center justify-between">
                    <p className="text-[10px] text-neutral-400">{t.presetTitle}</p>
                    {capturedImage && (
                      <span className="text-[9px] text-cyan-400 font-bold">{lang === 'ar' ? 'معاينة لقطتك المصفاة' : 'Previewing your captured shot'}</span>
                    )}
                  </div>
                  {!webcamStream && !capturedImage && (
                    <div className="grid grid-cols-3 gap-2">
                      {PRESET_PHOTOS.map((pres) => (
                        <button
                          key={pres.id}
                          onClick={() => {
                            setSelectedPreset(pres.id);
                            triggerNotification(`Loaded preset scenario: ${lang === 'ar' ? pres.nameAr : pres.nameEn}`, 'success');
                          }}
                          className={`p-2 rounded-xl border text-[9px] font-bold transition-all cursor-pointer ${
                            selectedPreset === pres.id
                              ? 'bg-red-500/15 border-red-500 text-red-300 font-extrabold'
                              : 'bg-neutral-950 border-neutral-800 text-neutral-400 hover:bg-neutral-800/40'
                          }`}
                        >
                          {lang === 'ar' ? pres.nameAr : pres.nameEn}
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                {/* Interactive Slider Image/Video Viewer */}
                <div className="relative aspect-[4/3] rounded-xl overflow-hidden bg-black border border-neutral-800 select-none group">
                  {/* Layer After (Reacts dynamically to sliders on the left!) */}
                  {webcamStream ? (
                    <video
                      ref={videoRefAfter}
                      autoPlay
                      playsInline
                      muted
                      className="absolute inset-0 w-full h-full object-cover scale-x-[-1]"
                      style={{
                        filter: getCameraFilter(false)
                      }}
                    />
                  ) : (
                    <img
                      src={capturedImage || currentPreset.url}
                      alt="AI Super Resolution After"
                      referrerPolicy="no-referrer"
                      className="absolute inset-0 w-full h-full object-cover transition-all duration-155"
                      style={{
                        filter: getCameraFilter(false)
                      }}
                    />
                  )}

                  {/* Layer Before (clipped to show the original lower quality photo) */}
                  <div
                    className="absolute inset-0 w-full h-full object-cover overflow-hidden pointer-events-none border-r-2 border-red-500"
                    style={{ clipPath: `polygon(0 0, ${sliderPosition}% 0, ${sliderPosition}% 100%, 0 100%)` }}
                  >
                    {webcamStream ? (
                      <video
                        ref={videoRefBefore}
                        autoPlay
                        playsInline
                        muted
                        className="absolute inset-0 w-full h-full object-cover scale-x-[-1]"
                        style={{
                          width: '100%',
                          maxWidth: 'none',
                          filter: getCameraFilter(true)
                        }}
                      />
                    ) : (
                      <img
                        src={capturedImage || currentPreset.url}
                        alt="Lower Quality Original"
                        referrerPolicy="no-referrer"
                        className="absolute inset-0 w-full h-full object-cover"
                        style={{
                          width: '100%',
                          maxWidth: 'none',
                          filter: getCameraFilter(true)
                        }}
                      />
                    )}
                    <div className="absolute top-3 left-3 bg-black/80 backdrop-blur-md px-2 py-1 rounded text-[8px] font-mono text-neutral-400 border border-neutral-800">
                      RAW UNOPTIMIZED
                    </div>
                  </div>

                  {/* Dynamic Parameter Labels pinned to After view */}
                  <div className="absolute top-3 right-3 bg-red-600/80 backdrop-blur-md px-2 py-1 rounded text-[8px] font-mono text-white border border-red-500 flex flex-col gap-0.5 items-end">
                    <span>NPU RESOLUTION BOOST</span>
                    <span className="text-[7px] text-amber-300 font-bold">SHARP: {sharpnessLevel}% | HDR: {hdrLevel}%</span>
                  </div>

                  {/* Flash animation */}
                  {flashActive && (
                    <div className="absolute inset-0 bg-white z-40 transition-opacity duration-300 pointer-events-none animate-flash"></div>
                  )}

                  {/* Grabber line indicator */}
                  <div 
                    className="absolute inset-y-0 w-1 bg-red-500 group-hover:bg-red-400 cursor-ew-resize flex items-center justify-center"
                    style={{ left: `${sliderPosition}%` }}
                  >
                    <div className="w-6 h-6 bg-red-600 text-white rounded-full flex items-center justify-center shadow-lg border border-neutral-100 text-xs font-mono font-bold select-none -translate-x-1/2">
                      ↔
                    </div>
                  </div>

                  {/* Invisible Range Input Layer to handle sliding */}
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={sliderPosition}
                    onChange={(e) => setSliderPosition(Number(e.target.value))}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-ew-resize z-10"
                  />
                </div>

                <p className="text-[10px] text-center text-neutral-500 mt-2.5">
                  {lang === 'ar' ? 'اسحب المقبض في الوسط لمشاهدة الفرق المباشر بتأثير نسب الذكاء الاصطناعي!' : 'Drag the center grabber to witness the real-time effect of AI enhancements!'}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {subTab === 'night' && (
        <div className="bg-neutral-900/90 border border-neutral-800 rounded-2xl p-6 space-y-6">
          <div className="border-b border-neutral-800 pb-3 flex items-center justify-between flex-wrap gap-2">
            <div>
              <h3 className="text-sm font-bold text-neutral-200 flex items-center gap-2">
                <Moon className="w-4 h-4 text-indigo-400 animate-pulse" />
                {t.night}
              </h3>
              <p className="text-xs text-neutral-400 mt-1">
                {lang === 'ar' ? 'صهر مستمر لـ 16 إطاراً خام بمستشعر واحد بوصة مفعم بالضوء مع صفر ضبابية' : 'RAW domain exposure blending at f/1.4 mechanical aperture limit'}
              </p>
            </div>
            <span className="text-xs bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 font-bold px-2.5 py-1 rounded-full">
              f/1.4 Physical Limit Active
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-stretch">
            {/* Capture action card */}
            <div className="bg-neutral-950 p-5 rounded-xl border border-neutral-800 flex flex-col justify-between space-y-4">
              <div className="space-y-2">
                <p className="text-xs font-bold text-neutral-300">{t.exposureLabel}</p>
                <div className="grid grid-cols-3 gap-2 text-[10px] font-mono">
                  <div className="bg-neutral-900/80 p-2 text-center rounded border border-neutral-800">
                    <span className="block text-neutral-500">Aperture</span>
                    <span className="text-neutral-200 font-bold">f/1.4 Max</span>
                  </div>
                  <div className="bg-neutral-900/80 p-2 text-center rounded border border-neutral-800">
                    <span className="block text-neutral-500">ISO Gain</span>
                    <span className="text-neutral-200 font-bold">ISO 51200</span>
                  </div>
                  <div className="bg-neutral-900/80 p-2 text-center rounded border border-neutral-800">
                    <span className="block text-neutral-500">Shutter Limit</span>
                    <span className="text-neutral-200 font-bold">1/4 Sec</span>
                  </div>
                </div>
              </div>

              <button
                onClick={runSuperNightSynthesis}
                disabled={nightCapturing}
                className="w-full bg-gradient-to-r from-indigo-600 to-indigo-800 hover:from-indigo-500 hover:to-indigo-700 text-white font-black p-4 rounded-xl text-xs transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg disabled:opacity-40"
              >
                <Moon className="w-4 h-4 fill-current text-white shrink-0" />
                <span>{nightCapturing ? 'Synthesizing...' : t.nightBtn}</span>
              </button>
            </div>

            {/* Live Progress synthesis status */}
            <div className="bg-neutral-950 p-5 rounded-xl border border-neutral-800 flex flex-col justify-center items-center text-center space-y-4">
              {nightCapturing ? (
                <div className="space-y-4 w-full">
                  <div className="flex items-center justify-center">
                    <RefreshCw className="w-8 h-8 text-indigo-400 animate-spin" />
                  </div>
                  <div className="space-y-1">
                    <p className="text-xs font-bold text-neutral-300 animate-pulse">{nightProgressMsg}</p>
                    <div className="w-full bg-neutral-900 h-1.5 rounded-full overflow-hidden border border-neutral-800">
                      <div className="bg-indigo-500 h-full transition-all duration-500" style={{ width: `${nightProgressVal}%` }}></div>
                    </div>
                  </div>
                </div>
              ) : nightSuccessPhoto ? (
                <div className="space-y-3 py-4 text-center">
                  <Check className="w-10 h-10 text-emerald-400 mx-auto animate-bounce" />
                  <p className="text-xs font-bold text-neutral-200">{lang === 'ar' ? 'اكتمل دمج الإطار فائق السطوع!' : 'Night frame integrated successfully!'}</p>
                  <p className="text-[10px] text-neutral-500 font-mono">1-inch photon capture result saved to UFS DCIM</p>
                </div>
              ) : (
                <div className="space-y-2 py-4 text-neutral-500">
                  <Moon className="w-12 h-12 text-neutral-700 mx-auto" />
                  <p className="text-xs font-bold">{lang === 'ar' ? 'مستعد للتصوير الليلي 2.0' : 'Awaiting Night Capture Trigger'}</p>
                  <img 
                    src="https://images.unsplash.com/photo-1519501025264-65ba15a82390?q=80&w=400" 
                    alt="City Night Icon" 
                    className="w-16 h-12 object-cover rounded mx-auto border border-neutral-800 brightness-30"
                  />
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {subTab === 'stabilize' && (
        <div className="bg-neutral-900/90 border border-neutral-800 rounded-2xl p-6 space-y-6">
          <div className="border-b border-neutral-800 pb-3 flex items-center justify-between flex-wrap gap-2">
            <div>
              <h3 className="text-sm font-bold text-neutral-200 flex items-center gap-2">
                <Video className="w-4 h-4 text-red-500 animate-pulse" />
                {t.subTabStabilize}
              </h3>
              <p className="text-xs text-neutral-400 mt-1">
                {lang === 'ar' ? 'تنشيط مانع الاهتزاز الميكانيكي OIS وخوارزميات الثبات الرقمي السينمائي EIS' : 'Locked mechanical Optical Image Stabilization & EIS crop calculations'}
              </p>
            </div>
            <button
              onClick={() => {
                setStabilizationActive(!stabilizationActive);
                triggerNotification(
                  stabilizationActive 
                    ? (lang === 'ar' ? 'تم إيقاف الموازنة البصرية (الكاميرا تهتز الآن)' : 'Optical Stabilization decoupled')
                    : (lang === 'ar' ? 'تم قفل وضبط الموازنة الميكانيكية OIS بنجاح!' : 'Mechanical Gyro OIS locked successfully!'),
                  'success'
                );
              }}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl border text-xs font-extrabold cursor-pointer transition-all ${
                stabilizationActive 
                  ? 'bg-emerald-500 text-neutral-950 border-emerald-400 shadow-md shadow-emerald-500/15'
                  : 'bg-neutral-950 border-neutral-850 text-neutral-400'
              }`}
            >
              <Check className="w-3.5 h-3.5 font-black" />
              <span>{t.stabilizationOn}</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-stretch">
            {/* Live stabilizing tracking vectors simulator */}
            <div className="bg-neutral-950 p-5 rounded-xl border border-neutral-800 space-y-4">
              <p className="text-xs font-bold text-neutral-300 flex items-center justify-between">
                <span>{t.motionVectorsTitle}</span>
                <span className="text-[10px] bg-red-600/10 text-red-400 font-mono border border-red-500/25 px-2 py-0.5 rounded font-bold animate-pulse">
                  GYRO LIVE
                </span>
              </p>

              {/* Dynamic Vector Alignment Target SVG */}
              <div className="h-44 bg-neutral-900 border border-neutral-850 rounded-xl relative flex items-center justify-center overflow-hidden">
                <div className="absolute inset-0 bg-radial-gradient from-red-600/5 to-transparent pointer-events-none"></div>
                
                {/* Horizontal & Vertical Crosshairs */}
                <div className="absolute inset-y-0 w-px bg-neutral-800"></div>
                <div className="absolute inset-x-0 h-px bg-neutral-800"></div>
                
                {/* Align circles */}
                <div className="absolute w-24 h-24 rounded-full border border-neutral-800"></div>
                <div className="absolute w-12 h-12 rounded-full border border-neutral-850"></div>

                {/* Shaking vibration feedback point */}
                <div 
                  className={`absolute w-3.5 h-3.5 rounded-full transition-all duration-150 ${
                    stabilizationActive ? 'bg-emerald-400 ring-4 ring-emerald-500/20' : 'bg-red-500 ring-8 ring-red-500/30 animate-pulse'
                  }`}
                  style={{
                    transform: `translate(${vibrationTick * 12}px, ${Math.sin(vibrationTick) * 32}px)`
                  }}
                ></div>

                {/* Floating telemetry metrics */}
                <div className="absolute bottom-3 left-3 text-[9px] font-mono text-neutral-500">
                  Angle Pitch: {(vibrationTick * 0.15).toFixed(2)}°
                </div>
                <div className="absolute bottom-3 right-3 text-[9px] font-mono text-neutral-500">
                  Yaw: {(vibrationTick * -0.22).toFixed(2)}°
                </div>
              </div>

              <div className="p-3 bg-neutral-900 rounded-xl border border-neutral-800/80 text-[10px] text-neutral-400 flex items-start gap-2">
                <Activity className="w-4 h-4 text-red-500 shrink-0" />
                <span>
                  {stabilizationActive 
                    ? (lang === 'ar' ? 'تم لجم واحتواء ارتجاف اليد بمقدار 8 مرات عن المعدل العام ببروتوكول شاومي لتثبيت الهياكل.' : 'OIS physical gyro motor actively dampens frame vibrations, delivering smooth 8K footage.')
                    : (lang === 'ar' ? 'الرجاء تشغيل مانع الاهتزاز لمنع تشوه الإطارات أثناء البث.' : 'Optical stabilizer bypassed. High-frequency shutter is vulnerable to direct motion shakes.')}
                </span>
              </div>
            </div>

            {/* Custom focal zoom controller */}
            <div className="bg-neutral-950 p-5 rounded-xl border border-neutral-800 flex flex-col justify-between space-y-4">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-neutral-300">Continuous Optical Zoom range</span>
                  <span className="text-xs font-mono font-bold text-red-400 bg-red-950/20 border border-red-500/25 px-2 py-0.5 rounded">
                    {smoothZoom} x
                  </span>
                </div>
                
                <input
                  type="range"
                  min="1"
                  max="120"
                  value={smoothZoom}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    setSmoothZoom(val);
                    if (val === 120) {
                      triggerNotification(lang === 'ar' ? 'تنشيط تقريب SuperZoom البصري 120x المدعم بالذكاء الاصطناعي!' : 'AI Dual-Blade Digital 120x Zoom module activated!', 'success');
                    }
                  }}
                  className="w-full accent-red-500 h-1 bg-neutral-800 rounded appearance-none cursor-pointer"
                />

                <div className="grid grid-cols-4 gap-1.5 text-center">
                  {[1, 5, 20, 120].map((z) => (
                    <button
                      key={z}
                      onClick={() => {
                        setSmoothZoom(z);
                        triggerNotification(`Continuous focal distance set to: ${z}x`, 'success');
                      }}
                      className={`py-1 rounded border text-[9px] font-bold font-mono transition-all cursor-pointer ${
                        smoothZoom === z 
                          ? 'bg-red-500 text-white border-red-400'
                          : 'bg-neutral-900 border-neutral-800 text-neutral-400 hover:text-white'
                      }`}
                    >
                      {z}x
                    </button>
                  ))}
                </div>
              </div>

              <div className="mt-4 p-3 rounded-xl bg-neutral-900 border border-neutral-800 text-[10px] text-neutral-500 flex items-start gap-2 leading-relaxed">
                <Compass className="w-4 h-4 text-amber-500 shrink-0" />
                <span>
                  {smoothZoom <= 5 
                    ? (lang === 'ar' ? 'يستخدم هاتف زوم شاومي المستشعر الرئيسي f/1.4 لضمان أعلى مستويات الضوء.' : 'Utilizes standard 50MP non-crop 1-inch prime sensor for low light clarity.')
                    : (lang === 'ar' ? 'تفعيل منشور التقريب البيريسكوبي (Periscope) مع مثبت الحركة الميكانيكي OIS.' : 'Activating high-fidelity optical periscope module with mechanical tilt stabilization.')}
                </span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
