import React, { useState, useEffect, useRef } from 'react';
import { 
  Cpu, 
  Thermometer, 
  Battery, 
  Trash2, 
  CpuIcon, 
  RefreshCw, 
  Zap, 
  ShieldAlert, 
  Sparkles, 
  CheckCircle, 
  HardDrive, 
  Check, 
  X, 
  Sliders, 
  BarChart4, 
  Info,
  Layers,
  Flame,
  Activity
} from 'lucide-react';

interface PhoneOptimizerProps {
  lang: 'ar' | 'en';
  triggerNotification: (text: string, type?: 'success' | 'error') => void;
}

const translations = {
  ar: {
    cleanerTitle: 'مُحسّن ومُنظّف الهاتف الذكيّ',
    cleanerSubtitle: 'افحص الذاكرة العشوائية RAM، نظّم الملفات المؤقتة والمهملات، وتحكم بأداء المعالج فورياً',
    statusTitle: 'احصاءات النظام الجارية (مراقبة فورية)',
    cpuHealth: 'استهلاك المعالج CPU',
    temperature: 'حرارة المعالج والنواة',
    ramUsage: 'الذاكرة العشوائية RAM',
    storageUsage: 'تخزين الهاتف الكلي',
    balanced: 'الوضع المتوازن (Balanced)',
    performance: 'وضع الأداء الفائق (Performance)',
    ultraBoost: 'وضع شاومي الأقصى (Ultra Power)',
    junkFound: 'مهملات النظام المتراكمة',
    optimizationLevel: 'مستوى استقرار النظام',
    optimizedButton: 'تنظيف وتحرير موارد النظام ✨',
    scanning: 'جاري فحص الذاكرة وإبادة الكاش المؤقت...',
    doneClean: 'تم تنظيف الهاتف واستبعاد المهملات بنجاح! حررنا ',
    batteryHealthy: 'حالة البطارية الممتازة',
    coolingActive: 'تنشيط التبريد الحراري السائل مسبقاً',
    performanceTitle: 'مستويات وملفات تحسين الأداء',
    diagnostics: 'مركز التنظيف والملفات الذكية',
    
    // Arabic Extra translations
    subTabMetrics: 'قياسات المعالج والحرارة',
    subTabJunk: 'تنظيف الملفات المؤقتة',
    subTabRam: 'تحسين الذاكرة RAM',
    subTabBattery: 'صحة وحالة البطارية',
    subTabBenchmark: 'اختبار الأداء الفائق',
    
    runBenchmark: 'تشغيل اختبار الأداء الاصطناعي (Benchmark)',
    benchmarking: 'جاري قياس سرعة المعالج وذاكرة LPDDR5X...',
    benchSuccess: 'اكتمل اختبار الأداء! النتيجة: ',
    killBtn: 'إنهاء العملية',
    ramOptimized: 'تم تحرير الذاكرة وتحسين كفاءة النفق الناقل!',
    batteryTitle: 'إحصائيات خلية الشحن 120W',
    superSaver: 'وضع التوفير الفائق للبطارية',
    chargingBoost: 'تسريع تدفق طاقة الشحن (HyperCharge)',
    thermalMap: 'خريطة التبريد السائل وغرف البخار',
    heavyCaptures: 'تنظيف مضاعفات الكاميرا المفرطة',
    obsoleteApk: 'حزم للتنظيف والملفات التالفة',
    crashLogs: 'ملفات تقارير النظام المأهولة',
    sysCaches: 'ملفات تفريغ ذاكرة التصفح والتطبيقات'
  },
  en: {
    cleanerTitle: 'Smart Phone Optimizer',
    cleanerSubtitle: 'Real-time analysis of RAM allocation, junk consolidation, CPU micro-temperatures, and battery state',
    statusTitle: 'Current Core Performance Matrices',
    cpuHealth: 'CPU Core Allocation',
    temperature: 'SoC Thermal Core Temp',
    ramUsage: 'RAM Memory Allocation',
    storageUsage: 'SoC Unified Storage',
    balanced: 'Balanced Profile',
    performance: 'Performance Boost',
    ultraBoost: 'Hyper OS Ultra Power Mode',
    junkFound: 'Accumulated Cache & Junk',
    optimizationLevel: 'System Health Diagnostics',
    optimizedButton: 'Run Storage & Memory Cleanse ✨',
    scanning: 'Scouring system logs and evicting volatile caches...',
    doneClean: 'System cleansed successfully! Recovered ',
    batteryHealthy: 'Battery Health Excellent',
    coolingActive: 'LiquidCooling matrix fully activated',
    performanceTitle: 'Performance Profiles Integration',
    diagnostics: 'Interactive Cleanse Control Panel',
    
    // English Extra translations
    subTabMetrics: 'Processor & Thermals',
    subTabJunk: 'Volatile Junk Cleansing',
    subTabRam: 'RAM Allocation Manager',
    subTabBattery: 'Battery Diagnostic Cell',
    subTabBenchmark: 'AI Synthetic Benchmark',
    
    runBenchmark: 'Launch Synthetic Benchmark Analysis',
    benchmarking: 'Computing float ops & memory read/write cycles...',
    benchSuccess: 'Benchmark Completed! Multi-Core score: ',
    killBtn: 'Kill Process',
    ramOptimized: 'RAM page-list successfully consolidated!',
    batteryTitle: '120W Charge Diagnostics Studio',
    superSaver: 'Extreme Battery Cooldown Mode',
    chargingBoost: '120W Ultra-Fast Energy Flow Rate',
    thermalMap: 'Core Thermal Dissipation Chamber State',
    heavyCaptures: 'Obsolete Camera Previews',
    obsoleteApk: 'Unused Package Archives (APKs)',
    crashLogs: 'System Error Output Logs',
    sysCaches: 'Non-volatile Cache Clusters'
  }
};

const INITIAL_BG_APPS = [
  { id: 'genshin', name: 'Genshin Pre-cache Server', usage: '1.24 GB', desc: 'Pre-loaded textures for instant loading' },
  { id: 'camera_core', name: 'Leica computational pipeline', usage: '840 MB', desc: 'Post-processing filters memory block' },
  { id: 'chrome_tabs', name: 'Chrome Engine (9 active tabs)', usage: '610 MB', desc: 'Active browser sandbox context' },
  { id: 'instagram_proc', name: 'Instagram background cache', usage: '320 MB', desc: 'Cached feed images & telemetry logs' },
  { id: 'system_ui', name: 'Xiaomi HyperOS launcher UI', usage: '480 MB', desc: 'Primary core layout renderer state' }
];

export default function PhoneOptimizer({ lang, triggerNotification }: PhoneOptimizerProps) {
  const t = translations[lang === 'en' ? 'en' : 'ar'];

  // Active sub-section within the Phone Optimizer page
  const [subTab, setSubTab] = useState<'metrics' | 'junk' | 'ram' | 'battery' | 'benchmark'>('metrics');

  // Dynamic system states
  const [cpuVal, setCpuVal] = useState<number>(42);
  const [tempVal, setTempVal] = useState<number>(38.4); // Celsius
  const [gpuTemp, setGpuTemp] = useState<number>(39.1);
  const [batteryTemp, setBatteryTemp] = useState<number>(31.5);
  const [ramVal, setRamVal] = useState<number>(11.4); // GB used
  const [ramTotal, setRamTotal] = useState<number>(16); // GB total
  const [storageVal, setStorageVal] = useState<number>(312.4); // GB used
  const [storageTotal, setStorageTotal] = useState<number>(512); // GB total
  const [junkVal, setJunkVal] = useState<number>(4.82); // GB
  const [selectedProfile, setSelectedProfile] = useState<'balanced' | 'performance' | 'ultraBoost'>('balanced');
  const [isCleaning, setIsCleaning] = useState<boolean>(false);
  const [isCooled, setIsCooled] = useState<boolean>(false);

  // Junk checkboxes
  const [junkList, setJunkList] = useState([
    { id: 'caches', name: t.sysCaches, size: 2.15, selected: true },
    { id: 'apks', name: t.obsoleteApk, size: 1.48, selected: true },
    { id: 'logs', name: t.crashLogs, size: 0.85, selected: true },
    { id: 'captures', name: t.heavyCaptures, size: 0.34, selected: false }
  ]);

  // RAM processes list
  const [bgApps, setBgApps] = useState(INITIAL_BG_APPS);

  // Battery metrics
  const [batteryHealth, setBatteryHealth] = useState<number>(98);
  const [chargeCycles, setChargeCycles] = useState<number>(114);
  const [superSaverActive, setSuperSaverActive] = useState<boolean>(false);
  const [hyperchargeBoost, setHyperchargeBoost] = useState<boolean>(true);

  // Benchmark states
  const [benchmarking, setBenchmarking] = useState<boolean>(false);
  const [benchScore, setBenchScore] = useState<{ single: number; multi: number } | null>(null);

  const prevTempRef = useRef<number>(tempVal);

  useEffect(() => {
    if (tempVal < prevTempRef.current) {
      const drop = prevTempRef.current - tempVal;
      if (drop >= 0.5) {
        triggerNotification(
          lang === 'ar'
            ? `❄️ نظام التبريد السائل وخلايا غرف البخار خفضت حرارة المعالج لـ ${tempVal.toFixed(1)}°C`
            : `❄️ Liquid cooling and vapour chambers cooled the SoC to ${tempVal.toFixed(1)}°C`,
          'success'
        );
      }
    }
    prevTempRef.current = tempVal;
  }, [tempVal, lang]);

  // Fluctuations
  useEffect(() => {
    const interval = setInterval(() => {
      setCpuVal((prev) => {
        const delta = Math.floor(Math.random() * 9) - 4;
        const next = prev + delta;
        return next < 5 ? 5 : next > 95 ? 90 : next;
      });
      setGpuTemp((prev) => {
        const delta = parseFloat((Math.random() * 0.4 - 0.2).toFixed(1));
        const next = prev + delta;
        return next < 30 ? 30 : next > 55 ? 52 : next;
      });
      setBatteryTemp((prev) => {
        const delta = parseFloat((Math.random() * 0.2 - 0.1).toFixed(1));
        const next = Math.max(26, Math.min(42, prev + delta));
        return parseFloat(next.toFixed(1));
      });
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  // Synchronize with AndroidBridge / AndroidSystem native values if available
  useEffect(() => {
    const bridge = (window as any).AndroidSystem || (window as any).AndroidBridge;
    if (!bridge) return;

    const syncHardware = () => {
      try {
        // Battery level/percent
        const realLevelRaw = typeof bridge.getBatteryLevel === 'function' ? bridge.getBatteryLevel() : (typeof bridge.getBatteryPercent === 'function' ? bridge.getBatteryPercent() : null);
        if (realLevelRaw !== null) {
          const levelNum = parseInt(String(realLevelRaw));
          if (!isNaN(levelNum)) {
            setBatteryHealth(Math.min(100, Math.max(90, levelNum + 5))); // compute a realistic dynamic health
          }
        }

        // Battery temperature
        const realTempRaw = typeof bridge.getBatteryTemperature === 'function' ? bridge.getBatteryTemperature() : null;
        if (realTempRaw !== null) {
          const realTemp = typeof realTempRaw === 'number' ? realTempRaw : parseFloat(String(realTempRaw));
          if (!isNaN(realTemp)) {
            setTempVal(realTemp + 2.4); // SoC core is typically warmer
            setBatteryTemp(realTemp);
            setGpuTemp(realTemp + 1.2);
          }
        }

        // RAM Usage
        const ramRaw = typeof bridge.getRamUsage === 'function' ? bridge.getRamUsage() : (typeof bridge.getMemoryInfo === 'function' ? bridge.getMemoryInfo() : (typeof bridge.getHardwareInfo === 'function' ? bridge.getHardwareInfo() : null));
        if (ramRaw) {
          try {
            const info = typeof ramRaw === 'object' ? ramRaw : JSON.parse(String(ramRaw));
            if (info) {
              const usedGb = info.ramUsed || info.usedRam;
              const totalGb = info.ramTotal || info.totalRam;
              if (usedGb) {
                const usedNum = parseFloat(String(usedGb));
                if (!isNaN(usedNum)) setRamVal(usedNum);
              }
              if (totalGb) {
                const totalNum = parseFloat(String(totalGb));
                if (!isNaN(totalNum)) setRamTotal(totalNum);
              }
            }
          } catch (err) {
            console.warn("Failed to parse RAM info:", err);
          }
        }

        // Storage Info
        const storageRaw = typeof bridge.getStorageInfo === 'function' ? bridge.getStorageInfo() : null;
        if (storageRaw) {
          try {
            const info = typeof storageRaw === 'object' ? storageRaw : JSON.parse(String(storageRaw));
            if (info) {
              if (info.usedSpaceGb) {
                const usedNum = parseFloat(String(info.usedSpaceGb));
                if (!isNaN(usedNum)) setStorageVal(usedNum);
              }
              if (info.totalSpaceGb) {
                const totalNum = parseFloat(String(info.totalSpaceGb));
                if (!isNaN(totalNum)) setStorageTotal(totalNum);
              }
            }
          } catch (err) {
            console.warn("Failed to parse Storage info:", err);
          }
        }

        // Apps Info
        const appsRaw = typeof bridge.getInstalledApps === 'function' ? bridge.getInstalledApps() : (typeof bridge.getAppsInfo === 'function' ? bridge.getAppsInfo() : null);
        if (appsRaw) {
          try {
            const info = typeof appsRaw === 'object' ? appsRaw : JSON.parse(String(appsRaw));
            if (info && Array.isArray(info.apps)) {
              const mapped = info.apps.map((app: any, idx: number) => ({
                id: `app_${idx}`,
                name: app.name,
                usage: `${app.ramUsedMb} MB`,
                desc: app.status
              }));
              setBgApps(mapped);
            }
          } catch (err) {
            console.warn("Failed to parse Apps info:", err);
          }
        }
      } catch (e) {
        console.error("Error reading from AndroidSystem in PhoneOptimizer:", e);
      }
    };

    syncHardware();
    const interval = setInterval(syncHardware, 3000); // 3-second automatic refresh interval requested
    return () => clearInterval(interval);
  }, []);

  // Compute calculated selected junk
  const currentSelectedJunkSize = junkList
    .filter(j => j.selected)
    .reduce((sum, item) => sum + item.size, 0);

  const handleClean = () => {
    setIsCleaning(true);
    triggerNotification(lang === 'ar' ? 'جاري فحص الكاش واستبعاد العقد التالفة...' : 'Evicting system temporary folders...', 'success');

    setTimeout(() => {
      setCpuVal(15);
      setTempVal(30.6);
      setGpuTemp(31.2);
      setRamVal(Math.max(4.2, ramVal - 2.1));
      
      const cleanedGB = currentSelectedJunkSize.toFixed(2);
      
      // Update check flags
      setJunkList(prev => prev.map(item => item.selected ? { ...item, size: 0 } : item));
      setIsCooled(true);
      setIsCleaning(false);

      triggerNotification(
        lang === 'ar'
          ? `✨ تم تنظيف الملفات المؤقتة بنجاح وتوفير ${cleanedGB} جيجابايت من التخزين!`
          : `✨ Volatile cache purge complete! Cleaned ${cleanedGB} GB from UFS 4.0 storage.`,
        'success'
      );
    }, 100);
  };

  const handleProfileChange = (profile: 'balanced' | 'performance' | 'ultraBoost') => {
    setSelectedProfile(profile);
    if (profile === 'balanced') {
      setCpuVal(35);
      setTempVal(33.4);
      triggerNotification(lang === 'ar' ? 'تم تفعيل الوضع المتوازن للمحافظة على الوقود.' : 'Balanced SoC profile loaded successfully.', 'success');
    } else if (profile === 'performance') {
      setCpuVal(72);
      setTempVal(42.1);
      triggerNotification(lang === 'ar' ? 'تم فك قيود المعالج وتفعيل ترددات النواة العليا!' : 'Performance booster active. Prime cores uncapped.', 'success');
    } else {
      setCpuVal(94);
      setTempVal(46.8);
      triggerNotification(lang === 'ar' ? 'تم تهيئة وضع الأداء الأقصى لشاومي (Ultra) لتفوق غير محدود!' : 'HyperOS Ultra Mode enabled. Vapour chamber fan status increased.', 'success');
    }
  };

  const killProcess = (id: string, name: string) => {
    setBgApps(prev => prev.filter(app => app.id !== id));
    setRamVal(prev => Math.max(4.0, prev - 0.5));
    triggerNotification(
      lang === 'ar'
        ? `🔐 تم إغلاق العملية [${name}] بأمان لتحرير مسارات RAM`
        : `🔐 Process [${name}] terminated. Volatile pages freed.`,
      'success'
    );
  };

  const optimizeAllRAM = () => {
    setIsCleaning(true);
    triggerNotification(lang === 'ar' ? 'جاري توحيد ذاكرة LPDDR5X وإطلاق خوارزمية الضغط...' : 'Consolidating LPDDR5X structures...', 'success');
    setTimeout(() => {
      setBgApps([]);
      setRamVal(4.2);
      setIsCleaning(false);
      triggerNotification(t.ramOptimized, 'success');
    }, 100);
  };

  const runBenchmarkTest = () => {
    setBenchmarking(true);
    setBenchScore(null);
    triggerNotification(lang === 'ar' ? 'بدء تشغيل اختبار الأداء وقياس قدرات النواة الثمانية...' : 'Launching standard FLOPS and compute workloads...', 'success');
    
    setTimeout(() => {
      const isPerf = selectedProfile === 'performance';
      const isUltra = selectedProfile === 'ultraBoost';
      
      const single = isUltra ? 2295 : isPerf ? 2110 : 1750;
      const multi = isUltra ? 7840 : isPerf ? 7150 : 5980;

      setCpuVal(98);
      setTempVal(49.2);

      setBenchScore({ single, multi });
      setBenchmarking(false);
      triggerNotification(`${t.benchSuccess} Single-Core: ${single} / Multi-Core: ${multi}`, 'success');
    }, 100);
  };

  return (
    <div className="space-y-6" id="phone-optimizer-section">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-neutral-900 via-neutral-900 to-amber-950/20 border border-amber-500/10 rounded-2xl p-5 relative overflow-hidden">
        <div className="absolute right-0 top-0 w-48 h-48 bg-amber-500/5 rounded-full blur-3xl pointer-events-none"></div>
        <div className="flex items-start gap-4">
          <div className="bg-amber-500 text-neutral-950 p-3 rounded-xl shadow-lg ring-4 ring-amber-500/20">
            <Cpu className="w-6 h-6 animate-spin-slow" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-neutral-100 flex items-center gap-2">
              {t.cleanerTitle}
              <span className="text-[10px] bg-amber-500/20 text-amber-400 border border-amber-500/30 px-2 py-0.5 rounded-full font-mono font-bold uppercase">
                HyperOS Core 3.0
              </span>
            </h2>
            <p className="text-xs text-neutral-400 mt-1 max-w-2xl leading-relaxed">
              {t.cleanerSubtitle}
            </p>
          </div>
        </div>
      </div>

      {/* Internal Sub-Tabs Navigation */}
      <div className="flex flex-wrap items-center gap-2 border-b border-neutral-800 pb-3">
        {[
          { id: 'metrics', label: t.subTabMetrics, icon: <Activity className="w-3.5 h-3.5" /> },
          { id: 'junk', label: t.subTabJunk, icon: <Trash2 className="w-3.5 h-3.5" /> },
          { id: 'ram', label: t.subTabRam, icon: <Zap className="w-3.5 h-3.5" /> },
          { id: 'battery', label: t.subTabBattery, icon: <Battery className="w-3.5 h-3.5" /> },
          { id: 'benchmark', label: t.subTabBenchmark, icon: <BarChart4 className="w-3.5 h-3.5" /> },
        ].map((sub) => {
          const isSelected = subTab === sub.id;
          return (
            <button
              key={sub.id}
              onClick={() => setSubTab(sub.id as any)}
              className={`flex items-center gap-2 px-3.5 py-2 text-xs font-bold rounded-lg border transition-all cursor-pointer ${
                isSelected 
                  ? 'bg-amber-500 text-neutral-950 border-amber-400 font-extrabold shadow-md shadow-amber-500/10'
                  : 'bg-neutral-900/60 border-neutral-800 text-neutral-400 hover:text-white hover:bg-neutral-800/40'
              }`}
            >
              {sub.icon}
              <span>{sub.label}</span>
            </button>
          );
        })}
      </div>

      {subTab === 'metrics' && (
        <div className="space-y-6">
          {/* Main core grids */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
            {/* Metric gauge 1: CPU */}
            <div className="bg-neutral-900/95 border border-neutral-800 rounded-xl p-5 flex flex-col items-center justify-center text-center relative overflow-hidden group">
              <div className="absolute top-2 right-2 text-[8px] font-mono text-neutral-600">CORE 0-7</div>
              <div className="w-20 h-20 rounded-full border-4 border-neutral-800 flex items-center justify-center relative shadow-inner mb-3">
                <div className={`absolute inset-0 rounded-full border-4 border-amber-500 transition-all duration-1000`} style={{ clipPath: `polygon(0 0, 100% 0, 100% ${cpuVal}%, 0 ${cpuVal}%)` }}></div>
                <span className="text-sm font-bold font-mono text-neutral-100">{cpuVal}%</span>
              </div>
              <span className="text-xs font-semibold text-neutral-300 flex items-center gap-1">
                <CpuIcon className="w-3.5 h-3.5 text-amber-500" />
                {t.cpuHealth}
              </span>
              <span className="text-[10px] text-neutral-500 mt-1 leading-snug">Cortex-X4 Master Unit</span>
            </div>

            {/* Metric gauge 2: Temp */}
            <div className="bg-neutral-900/95 border border-neutral-800 rounded-xl p-5 flex flex-col items-center justify-center text-center relative overflow-hidden group">
              <div className="absolute top-2 right-2 text-[8px] font-mono text-neutral-600">COOL-CELL 2.0</div>
              <div className="w-20 h-20 rounded-full border-4 border-neutral-800 flex items-center justify-center relative shadow-inner mb-3">
                <div className={`absolute inset-0 rounded-full border-4 ${tempVal > 40 ? 'border-red-500' : 'border-emerald-400'} transition-all duration-300`} style={{ clipPath: `polygon(0 0, 100% 0, 100% ${(tempVal/80)*100}%, 0 ${(tempVal/80)*100}%)` }}></div>
                <span className={`text-sm font-bold font-mono ${tempVal > 40 ? 'text-red-400' : 'text-emerald-400'}`}>{tempVal.toFixed(1)}°C</span>
              </div>
              <span className="text-xs font-semibold text-neutral-300 flex items-center gap-1">
                <Thermometer className={`w-3.5 h-3.5 ${tempVal > 40 ? 'text-red-500' : 'text-emerald-400'}`} />
                {t.temperature}
              </span>
              <span className="text-[10px] text-neutral-500 mt-1 leading-snug">{isCooled ? t.coolingActive : 'LiquidCool Active'}</span>
            </div>

            {/* Metric gauge 3: RAM */}
            <div className="bg-neutral-900/95 border border-neutral-800 rounded-xl p-5 flex flex-col items-center justify-center text-center relative overflow-hidden group">
              <div className="absolute top-2 right-2 text-[8px] font-mono text-neutral-600">LPDDR5X CHIP</div>
              <div className="w-20 h-20 rounded-full border-4 border-neutral-800 flex items-center justify-center relative shadow-inner mb-3">
                <div className="absolute inset-0 rounded-full border-4 border-cyan-500 transition-all duration-500" style={{ clipPath: `polygon(0 0, 100% 0, 100% ${(ramVal/ramTotal)*100}%, 0 ${(ramVal/ramTotal)*100}%)` }}></div>
                <span className="text-sm font-bold font-mono text-neutral-100">{ramVal.toFixed(1)} GB</span>
              </div>
              <span className="text-xs font-semibold text-neutral-300 flex items-center gap-1">
                <Zap className="w-3.5 h-3.5 text-cyan-400" />
                {t.ramUsage}
              </span>
              <span className="text-[10px] text-neutral-500 mt-1 leading-snug">Total: {ramTotal.toFixed(0)} GB Capacity</span>
            </div>

            {/* Metric gauge 4: Storage */}
            <div className="bg-neutral-900/95 border border-neutral-800 rounded-xl p-5 flex flex-col items-center justify-center text-center relative overflow-hidden group">
              <div className="absolute top-2 right-2 text-[8px] font-mono text-neutral-600">UFS 4.0 MASSIVE</div>
              <div className="w-20 h-20 rounded-full border-4 border-neutral-800 flex items-center justify-center relative shadow-inner mb-3">
                <div className="absolute inset-0 rounded-full border-4 border-purple-500" style={{ clipPath: `polygon(0 0, 100% 0, 100% ${(storageVal/storageTotal)*100}%, 0 ${(storageVal/storageTotal)*100}%)` }}></div>
                <span className="text-sm font-bold font-mono text-neutral-100">{storageVal.toFixed(0)} / {storageTotal.toFixed(0)}G</span>
              </div>
              <span className="text-xs font-semibold text-neutral-300 flex items-center gap-1">
                <HardDrive className="w-3.5 h-3.5 text-purple-400" />
                {t.storageUsage}
              </span>
              <span className="text-[10px] text-neutral-500 mt-1 leading-snug">Solid dual-plane flash</span>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Vapour Chamber thermals card */}
            <div className="lg:col-span-6 bg-neutral-900/90 border border-neutral-800 rounded-2xl p-5">
              <h3 className="text-sm font-bold text-neutral-200 mb-4 flex items-center gap-2">
                <Flame className="w-4 h-4 text-orange-500 animate-pulse" />
                {t.thermalMap}
              </h3>
              
              <div className="space-y-4">
                <div className="bg-neutral-950 p-3 rounded-xl border border-neutral-800 flex items-center justify-between">
                  <span className="text-xs text-neutral-300">SoC Core Thermal (Zone A)</span>
                  <div className="flex items-center gap-2">
                    <div className="w-20 bg-neutral-800 h-1.5 rounded-full overflow-hidden">
                      <div className="bg-orange-500 h-full" style={{ width: `${(tempVal/80)*100}%` }}></div>
                    </div>
                    <span className="text-xs font-mono font-bold text-orange-400">{tempVal.toFixed(1)}°C</span>
                  </div>
                </div>

                <div className="bg-neutral-950 p-3 rounded-xl border border-neutral-800 flex items-center justify-between">
                  <span className="text-xs text-neutral-300">GPU Adreno Graphic Zone (Zone B)</span>
                  <div className="flex items-center gap-2">
                    <div className="w-20 bg-neutral-800 h-1.5 rounded-full overflow-hidden">
                      <div className="bg-amber-500 h-full" style={{ width: `${(gpuTemp/80)*100}%` }}></div>
                    </div>
                    <span className="text-xs font-mono font-bold text-amber-400">{gpuTemp.toFixed(1)}°C</span>
                  </div>
                </div>

                <div className="bg-neutral-950 p-3 rounded-xl border border-neutral-800 flex items-center justify-between">
                  <span className="text-xs text-neutral-300">Smart Battery Cell Zone (Zone C)</span>
                  <div className="flex items-center gap-2">
                    <div className="w-20 bg-neutral-800 h-1.5 rounded-full overflow-hidden">
                      <div className="bg-emerald-500 h-full" style={{ width: `${(batteryTemp/50)*100}%` }}></div>
                    </div>
                    <span className="text-xs font-mono font-bold text-emerald-400">{batteryTemp.toFixed(1)}°C</span>
                  </div>
                </div>
              </div>

              <div className="mt-4 p-3 rounded-xl bg-neutral-950 border border-neutral-800 text-[10px] text-neutral-400 flex items-start gap-2">
                <Info className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                <span>
                  {lang === 'ar' 
                    ? 'يتحكم نظام غرف البخار السائل الحلقية فائق السرعة بمستوى انتقال الحرارة بشكل تلقائي ومبرمج تماماً لحماية خلايا السيليكون.'
                    : 'The loop-vapour cooling system leverages physical heat conduction loops to maximize sustained high clock speeds without thermal throttling.'}
                </span>
              </div>
            </div>

            {/* Performance Profiles widget */}
            <div className="lg:col-span-6 bg-neutral-900/90 border border-neutral-800 rounded-2xl p-5">
              <h3 className="text-sm font-bold text-neutral-200 mb-3 flex items-center gap-2">
                <CpuIcon className="w-4 h-4 text-amber-500" />
                {t.performanceTitle}
              </h3>
              <div className="space-y-3">
                {[
                  { id: 'balanced', title: t.balanced, desc: lang === 'ar' ? 'يحكم استهلاك الطاقة مع توفير تجربة استخدام ناعمة وعمر بطارية مثالي.' : 'Automates frequency management for flawless day-to-day balance.', icon: <Zap className="w-4 h-4 text-green-400" /> },
                  { id: 'performance', title: t.performance, desc: lang === 'ar' ? 'يرفع تردد النوى الثقيلة لفتح مستقر للتطبيقات بمقدار مرتين.' : 'Directly commands powerful prime cores. Ideal for serious multi-tasking.', icon: <Zap className="w-4 h-4 text-amber-400 animate-pulse" /> },
                  { id: 'ultraBoost', title: t.ultraBoost, desc: lang === 'ar' ? 'يحطم سقف المعالجة، تبريد توربيني، وخرق لترددات النواة لألعاب ثقيلة.' : 'Bypasses standard thermal limiters. Delivers maximum benchmark score.', icon: <CheckCircle className="w-4 h-4 text-red-500" /> }
                ].map((p) => {
                  const isActive = selectedProfile === p.id;
                  return (
                    <button
                      key={p.id}
                      onClick={() => handleProfileChange(p.id as any)}
                      className={`w-full text-right ${lang === 'ar' ? 'text-right' : 'text-left'} p-3 rounded-xl border transition-all flex flex-col gap-1 cursor-pointer ${
                        isActive
                          ? 'bg-amber-950/20 border-amber-500/50 shadow-md ring-1 ring-amber-500/20'
                          : 'bg-neutral-950/40 border-neutral-800/80 hover:bg-neutral-800/20'
                      }`}
                    >
                      <div className="flex items-center justify-between w-full">
                        <span className="text-xs font-bold text-neutral-200 flex items-center gap-2">
                          {p.icon}
                          {p.title}
                        </span>
                        {isActive && (
                          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20 font-bold uppercase">
                            ACTIVE
                          </span>
                        )}
                      </div>
                      <span className="text-[10px] text-neutral-400 leading-relaxed">{p.desc}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}

      {subTab === 'junk' && (
        <div className="bg-neutral-900/90 border border-neutral-800 rounded-2xl p-6 space-y-6">
          <div className="border-b border-neutral-800 pb-3 flex items-center justify-between flex-wrap gap-2">
            <div>
              <h3 className="text-sm font-bold text-neutral-200 flex items-center gap-2">
                <Trash2 className="w-4 h-4 text-amber-500" />
                {t.diagnostics}
              </h3>
              <p className="text-xs text-neutral-400 mt-1">
                {lang === 'ar' ? 'حدد المجموعات التي تود غربلتها وتصفيتها لتحرير هائل للذاكرة' : 'Select directory clusters to cleanse & scrub from UFS 4.0 channels'}
              </p>
            </div>
            {/* Displaying trash bytes count */}
            <div className="bg-neutral-950 px-4 py-2 rounded-xl border border-neutral-800 flex items-center gap-4">
              <div>
                <p className="text-[8px] font-mono text-neutral-500 uppercase tracking-wider">{t.junkFound}</p>
                <p className="text-xl font-bold font-mono text-amber-500">{currentSelectedJunkSize.toFixed(2)} GB</p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {junkList.map((item) => (
              <button
                key={item.id}
                onClick={() => {
                  setJunkList(prev => prev.map(j => j.id === item.id ? { ...j, selected: !j.selected } : j));
                }}
                disabled={item.size === 0}
                className={`flex items-center justify-between p-4 rounded-xl border transition-all text-right cursor-pointer ${
                  item.size === 0 
                  ? 'opacity-40 bg-neutral-950/20 border-neutral-900 cursor-not-allowed'
                  : item.selected
                    ? 'bg-amber-950/20 border-amber-500/30 shadow-md'
                    : 'bg-neutral-950 border-neutral-800/80 hover:bg-neutral-800/20'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`w-5 h-5 rounded flex items-center justify-center border transition-all ${
                    item.selected ? 'bg-amber-500 border-amber-400 text-neutral-950' : 'border-neutral-700 text-transparent'
                  }`}>
                    <Check className="w-3.5 h-3.5 font-bold" />
                  </div>
                  <div className={`text-right ${lang === 'ar' ? 'text-right' : 'text-left'}`}>
                    <p className="text-xs font-bold text-neutral-200">{item.name}</p>
                    <p className="text-[9px] text-neutral-500">{item.size === 0 ? 'Cleaned' : 'System generated directory'}</p>
                  </div>
                </div>
                <div className="font-mono text-sm font-bold text-neutral-300">
                  {item.size.toFixed(2)} GB
                </div>
              </button>
            ))}
          </div>

          <button
            onClick={handleClean}
            disabled={isCleaning || currentSelectedJunkSize === 0}
            className="w-full bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-neutral-950 p-4 rounded-xl font-black text-xs transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-amber-500/10 disabled:opacity-40"
          >
            {isCleaning ? (
              <>
                <RefreshCw className="w-4.5 h-4.5 animate-spin" />
                <span>{t.scanning}</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4.5 h-4.5" />
                <span>{t.optimizedButton}</span>
              </>
            )}
          </button>
        </div>
      )}

      {subTab === 'ram' && (
        <div className="bg-neutral-900/90 border border-neutral-800 rounded-2xl p-6 space-y-6">
          <div className="flex items-center justify-between border-b border-neutral-800 pb-3 flex-wrap gap-2">
            <div>
              <h3 className="text-sm font-bold text-neutral-200 flex items-center gap-2">
                <Zap className="w-4 h-4 text-cyan-400" />
                {lang === 'ar' ? 'إدارة قنوات الذاكرة المؤقتة RAM' : 'LPDDR5X Bus Channels Manager'}
              </h3>
              <p className="text-xs text-neutral-400 mt-1">
                {lang === 'ar' ? 'التحكم في العمليات النشطة في الخلفية وإفراغ الذاكرة المستهلكة فورياً' : 'Close rogue background services to flush standard thread layouts'}
              </p>
            </div>
            <button
              onClick={optimizeAllRAM}
              className="bg-cyan-500 hover:bg-cyan-400 text-neutral-950 font-bold px-3 py-1.5 rounded-lg text-xs transition-all cursor-pointer shadow shadow-cyan-500/15"
            >
              🚀 {lang === 'ar' ? 'تحسين كلي سلكي' : 'Optimise LPDDR5X Core'}
            </button>
          </div>

          {bgApps.length === 0 ? (
            <div className="bg-neutral-950 rounded-xl p-8 border border-neutral-800 text-center space-y-3">
              <CheckCircle className="w-10 h-10 text-emerald-400 mx-auto animate-bounce" />
              <p className="text-xs font-bold text-neutral-200">{lang === 'ar' ? 'تم تحسين الذاكرة RAM بالكامل! لا توجد عمليات مهملة.' : 'RAM optimized fully! LPDDR5X is running on flawless slate.'}</p>
              <p className="text-[10px] text-neutral-500">{lang === 'ar' ? `استهلاك الذاكرة المؤقتة: ${ramVal.toFixed(1)} جيجا / ${ramTotal.toFixed(0)} جيجا` : `Volatile pool consumption: ${ramVal.toFixed(1)} GB / ${ramTotal.toFixed(0)} GB`}</p>
            </div>
          ) : (
            <div className="space-y-2.5">
              {bgApps.map((app) => (
                <div key={app.id} className="bg-neutral-950 p-3.5 border border-neutral-800/80 rounded-xl flex items-center justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-neutral-900 border border-neutral-800 flex items-center justify-center">
                      <Cpu className="w-4 h-4 text-cyan-400 animate-pulse" />
                    </div>
                    <div className={`text-right ${lang === 'ar' ? 'text-right' : 'text-left'}`}>
                      <p className="text-xs font-semibold text-neutral-200">{app.name}</p>
                      <p className="text-[9px] text-neutral-500">{app.desc}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-xs font-mono font-bold text-cyan-400 bg-cyan-950/20 border border-cyan-500/20 px-2 py-0.5 rounded">
                      {app.usage}
                    </span>
                    <button
                      onClick={() => killProcess(app.id, app.name)}
                      className="text-[10px] text-neutral-400 hover:text-red-400 hover:bg-red-950/40 border border-neutral-800 hover:border-red-500/30 px-2.5 py-1 rounded-lg transition-all cursor-pointer flex items-center gap-1"
                    >
                      <X className="w-3 h-3" />
                      <span>{t.killBtn}</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {subTab === 'battery' && (
        <div className="bg-neutral-900/90 border border-neutral-800 rounded-2xl p-6 space-y-6">
          <div className="border-b border-neutral-800 pb-3 flex items-center justify-between flex-wrap gap-2">
            <div>
              <h3 className="text-sm font-bold text-neutral-200 flex items-center gap-2">
                <Battery className="w-4 h-4 text-emerald-400" />
                {t.batteryTitle}
              </h3>
              <p className="text-xs text-neutral-400 mt-1">
                {lang === 'ar' ? 'مراقبة فورية لأداء البطارية ومستشعرات الشحن الذكية' : 'Deep health and live current diagnostic logs for dual-cell anode'}
              </p>
            </div>
            <span className="text-xs font-mono bg-emerald-500/15 border border-emerald-500/25 text-emerald-400 px-2.5 py-1 rounded-full font-bold">
              98% Health (Excellent)
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-neutral-950 p-4 rounded-xl border border-neutral-800 text-center space-y-1">
              <span className="text-[10px] text-neutral-500 uppercase font-mono">Charge Cycles</span>
              <p className="text-xl font-mono font-bold text-neutral-200">{chargeCycles} Cycles</p>
              <p className="text-[9px] text-neutral-500">Premium Silicon Battery Anode</p>
            </div>

            <div className="bg-neutral-950 p-4 rounded-xl border border-neutral-800 text-center space-y-1">
              <span className="text-[10px] text-neutral-500 uppercase font-mono">Voltage / Output</span>
              <p className="text-xl font-mono font-bold text-neutral-200">4.42 V</p>
              <p className="text-[9px] text-neutral-500">Strict Smart Safe Fuse Active</p>
            </div>

            <div className="bg-neutral-950 p-4 rounded-xl border border-neutral-800 text-center space-y-1">
              <span className="text-[10px] text-neutral-500 uppercase font-mono">Cell Temperature</span>
              <p className="text-xl font-mono font-bold text-neutral-200">{batteryTemp.toFixed(1)} °C</p>
              <p className="text-[9px] text-neutral-500">Vapour cooling active</p>
            </div>
          </div>

          {/* Interactive controls */}
          <div className="space-y-3">
            {/* Super Saver toggle */}
            <div className="flex items-center justify-between p-3.5 rounded-xl bg-neutral-950 border border-neutral-800">
              <div className={`text-right ${lang === 'ar' ? 'text-right' : 'text-left'}`}>
                <p className="text-xs font-bold text-neutral-200 flex items-center gap-1">
                  <Zap className="w-3.5 h-3.5 text-emerald-400" />
                  {t.superSaver}
                </p>
                <p className="text-[10px] text-neutral-500">{superSaverActive ? 'Slowing background clocks entirely' : 'Optimal CPU discharge mode'}</p>
              </div>
              <button
                onClick={() => {
                  setSuperSaverActive(!superSaverActive);
                  if (!superSaverActive) {
                    setCpuVal(8);
                    setRamVal(4.5);
                    triggerNotification(lang === 'ar' ? 'تم تنشيط وضع السكون الفائق للبطارية!' : 'Extreme saving active. Background limit reached.', 'success');
                  } else {
                    setCpuVal(30);
                    triggerNotification(lang === 'ar' ? 'تم استئناف التشغيل العادي للواجهة.' : 'Deactivated super battery saver mode.', 'success');
                  }
                }}
                className={`w-10 h-6 rounded-full p-1 transition-all cursor-pointer ${superSaverActive ? 'bg-emerald-500' : 'bg-neutral-800'}`}
              >
                <div className={`w-4 h-4 rounded-full bg-neutral-950 transition-all ${superSaverActive ? 'translate-x-4' : 'translate-x-0'}`}></div>
              </button>
            </div>

            {/* Hypercharge boost */}
            <div className="flex items-center justify-between p-3.5 rounded-xl bg-neutral-950 border border-neutral-800">
              <div className={`text-right ${lang === 'ar' ? 'text-right' : 'text-left'}`}>
                <p className="text-xs font-bold text-neutral-200 flex items-center gap-1">
                  <Flame className="w-3.5 h-3.5 text-amber-500 animate-pulse" />
                  {t.chargingBoost}
                </p>
                <p className="text-[10px] text-neutral-500">{hyperchargeBoost ? 'Bypasses standard safe ramp to charge 0-100% in 18m' : 'Standard charging flow rate'}</p>
              </div>
              <button
                onClick={() => {
                  setHyperchargeBoost(!hyperchargeBoost);
                  triggerNotification(
                    hyperchargeBoost 
                      ? (lang === 'ar' ? 'تم إيقاف تسريع تدفق الشحن للحفاظ على طول العمر.' : 'Hypercharge disabled standard ramp model.')
                      : (lang === 'ar' ? 'تم فتح حد طاقة الشحن بقوة 120W التوربينية الغالية!' : '120W maximum flow unlocked! Boost on.'),
                    'success'
                  );
                }}
                className={`w-10 h-6 rounded-full p-1 transition-all cursor-pointer ${hyperchargeBoost ? 'bg-amber-500' : 'bg-neutral-800'}`}
              >
                <div className={`w-4 h-4 rounded-full bg-neutral-950 transition-all ${hyperchargeBoost ? 'translate-x-4' : 'translate-x-0'}`}></div>
              </button>
            </div>
          </div>
        </div>
      )}

      {subTab === 'benchmark' && (
        <div className="bg-neutral-900/90 border border-neutral-800 rounded-2xl p-6 space-y-6">
          <div className="border-b border-neutral-800 pb-3">
            <h3 className="text-sm font-bold text-neutral-200 flex items-center gap-2">
              <BarChart4 className="w-4 h-4 text-purple-400" />
              {t.subTabBenchmark}
            </h3>
            <p className="text-xs text-neutral-400 mt-1">
              {lang === 'ar' ? 'قم بتشغيل اختبار الأداء لقياس سرعة نواة Snapdragon وقنوات LPDDR5X بمؤشرات قياسية' : 'Run realistic workload simulation directly inside the sandbox container environment'}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-stretch">
            {/* Controller card */}
            <div className="bg-neutral-950 p-5 rounded-xl border border-neutral-800 flex flex-col justify-between space-y-4">
              <div className="space-y-2">
                <p className="text-xs font-bold text-neutral-200">{lang === 'ar' ? 'خصائص الاختبار الفردية والكلية' : 'Test Suite Scope'}</p>
                <ul className="text-[10px] text-neutral-400 space-y-1 text-right list-disc pr-4">
                  <li>{lang === 'ar' ? 'تخليق ذري للمهام الرياضية المرتفعة' : 'Single Thread scalar floating math routines'}</li>
                  <li>{lang === 'ar' ? 'معالجات الذكاء الاصطناعي والصور المحاكية' : 'AI camera feature prediction rendering workloads'}</li>
                  <li>{lang === 'ar' ? 'اختبار النطاق الترددي للـ Memory read limits' : 'UFS 4.0 storage random transfer IOPS analysis'}</li>
                </ul>
              </div>

              <button
                onClick={runBenchmarkTest}
                disabled={benchmarking}
                className="w-full bg-gradient-to-r from-purple-500 to-indigo-600 hover:from-purple-400 hover:to-indigo-500 text-neutral-950 font-black p-3 rounded-xl text-xs transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-40"
              >
                {benchmarking ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>{t.benchmarking}</span>
                  </>
                ) : (
                  <>
                    <Activity className="w-4 h-4 fill-neutral-950 text-neutral-950" />
                    <span>{t.runBenchmark}</span>
                  </>
                )}
              </button>
            </div>

            {/* Results card */}
            <div className="bg-neutral-950 p-5 rounded-xl border border-neutral-800 flex flex-col justify-center items-center text-center relative overflow-hidden">
              {benchmarking ? (
                <div className="space-y-4 py-8">
                  <RefreshCw className="w-8 h-8 text-purple-400 animate-spin mx-auto" />
                  <p className="text-xs font-semibold text-neutral-300 animate-pulse">{lang === 'ar' ? 'جاري ضخ العمليات الرياضية...' : 'Calculating floating point operations...'}</p>
                </div>
              ) : benchScore ? (
                <div className="space-y-4 w-full">
                  <p className="text-xs font-bold uppercase text-purple-400 tracking-wider">Antigravity score verified</p>
                  
                  <div className="grid grid-cols-2 gap-4 w-full">
                    <div className="bg-neutral-900/80 p-3 rounded-xl border border-neutral-800">
                      <p className="text-[9px] text-neutral-500 uppercase">Single-Core Score</p>
                      <p className="text-2xl font-black font-mono text-neutral-200 mt-1">{benchScore.single}</p>
                    </div>

                    <div className="bg-neutral-900/80 p-3 rounded-xl border border-neutral-800">
                      <p className="text-[9px] text-neutral-500 uppercase">Multi-Core Score</p>
                      <p className="text-2xl font-black font-mono text-purple-400 mt-1">{benchScore.multi}</p>
                    </div>
                  </div>

                  <div className="p-2.5 rounded-lg bg-indigo-950/20 border border-indigo-500/20 text-[10px] text-indigo-300">
                    🏆 {lang === 'ar' ? 'يتجاوز هاتف هواتف Xiaomi 17 Ultra نسبة 99.4% من الأجهزة القياسية!' : 'Your Xiaomi device outperforms 99.4% of existing smartphone benchmarks!'}
                  </div>
                </div>
              ) : (
                <div className="space-y-2 py-8 text-neutral-500">
                  <BarChart4 className="w-12 h-12 text-neutral-700 mx-auto" />
                  <p className="text-xs font-bold">{lang === 'ar' ? 'لا توجود نقاط اختبار مسجلة' : 'No Benchmark results generated yet'}</p>
                  <p className="text-[10px]">{lang === 'ar' ? 'أطلق الاختبار بالألوان الزاهية لرؤية تصنيف نوى المعالج' : 'Launch analyze suite above to start calculating core performance'}</p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
