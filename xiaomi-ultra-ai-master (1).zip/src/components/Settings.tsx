import React, { useState, useEffect } from 'react';
import { 
  Sliders, 
  Globe, 
  Moon, 
  RotateCcw, 
  Info, 
  Cpu, 
  ShieldAlert, 
  CheckCircle,
  Smartphone
} from 'lucide-react';

interface SettingsProps {
  lang: 'ar' | 'en';
  setLang: (newLang: 'ar' | 'en') => void;
  triggerNotification: (text: string, type?: 'success' | 'error') => void;
}

interface DeviceState {
  model: string;
  brand: string;
  androidVersion: string;
  sdkVersion: string;
  processor: string;
}

export default function Settings({ lang, setLang, triggerNotification }: SettingsProps) {
  // Performance mode state
  const [perfMode, setPerfMode] = useState<string>(() => {
    return localStorage.getItem('perfMode') || 'balanced';
  });

  // Night Mode state (OLED black vs classic twilight slate)
  const [nightMode, setNightMode] = useState<boolean>(() => {
    return localStorage.getItem('nightMode') !== 'false';
  });

  // Device Info state with fallbacks
  const [deviceInfo, setDeviceInfo] = useState<DeviceState>({
    model: 'Xiaomi 17 Ultra',
    brand: 'Xiaomi',
    androidVersion: '16.0',
    sdkVersion: '35',
    processor: 'Snapdragon 8 Gen 5 Elite'
  });

  useEffect(() => {
    const bridge = (window as any).AndroidSystem || (window as any).AndroidBridge;
    if (bridge && typeof bridge.getDeviceInfo === 'function') {
      try {
        const raw = bridge.getDeviceInfo();
        const parsed = typeof raw === 'object' ? raw : JSON.parse(String(raw));
        if (parsed) {
          setDeviceInfo({
            model: parsed.model || 'Xiaomi 17 Ultra',
            brand: parsed.brand || 'Xiaomi',
            androidVersion: parsed.androidVersion || '16.0',
            sdkVersion: String(parsed.sdkVersion || '35'),
            processor: parsed.processor || 'Snapdragon 8 Gen 5 Elite'
          });
        }
      } catch (e) {
        console.warn("Failed to query native device info:", e);
      }
    }
  }, []);

  const handlePerfModeChange = (mode: string) => {
    setPerfMode(mode);
    localStorage.setItem('perfMode', mode);
    
    const bridge = (window as any).AndroidSystem || (window as any).AndroidBridge;
    if (bridge && typeof bridge.saveSetting === 'function') {
      bridge.saveSetting('perfMode', mode);
    }

    const messages = {
      ar: {
        balanced: 'تم تفعيل الملف المتوازن لحفظ الطاقة ذكياً.',
        performance: 'تم تمكين وضع الأداء العالي لمعالجة Snapdragon!',
        ultraBoost: 'تم تشغيل WildBoost Ultra لكسر سرعة المعالج القصوى!'
      },
      en: {
        balanced: 'Balanced performance profile enabled successfully.',
        performance: 'High Performance Snapdragon profile engaged!',
        ultraBoost: 'WildBoost Ultra overclock engaged for heavy tasks!'
      }
    };
    const safeLang = lang === 'en' ? 'en' : 'ar';
    triggerNotification((messages as any)[safeLang][mode], 'success');
  };

  const handleNightModeToggle = () => {
    const next = !nightMode;
    setNightMode(next);
    localStorage.setItem('nightMode', String(next));
    
    // Toggle class on document body for dark/OLED black themes
    if (next) {
      document.documentElement.classList.add('oled-black');
    } else {
      document.documentElement.classList.remove('oled-black');
    }

    triggerNotification(
      lang === 'ar' 
        ? (next ? 'تم تفعيل وضع السواد المطلق OLED لحفظ خلايا الطاقة.' : 'تم الانتقال للمظهر الكلاسيكي المتوهج.')
        : (next ? 'Absolute OLED Black engaged for supreme panel efficiency.' : 'Classic Slate display styling engaged.'),
      'success'
    );
  };

  const handleResetSettings = () => {
    localStorage.clear();
    setPerfMode('balanced');
    setNightMode(true);
    setLang('ar');
    document.documentElement.classList.add('oled-black');

    const bridge = (window as any).AndroidSystem || (window as any).AndroidBridge;
    if (bridge && typeof bridge.saveSetting === 'function') {
      bridge.saveSetting('perfMode', 'balanced');
      bridge.saveSetting('nightMode', 'true');
      bridge.saveSetting('lang', 'ar');
    }

    triggerNotification(
      lang === 'ar' ? 'تمت إعادة تعيين تفضيلات النظام للوضع الافتراضي المصنعي' : 'System parameters reset to factory default state',
      'success'
    );
  };

  const t = {
    ar: {
      title: 'إعدادات النظام الفائقة Settings',
      subtitle: 'تحكم في تهيئة العتاد والأداء وتخصيص تجربة الاستخدام لجهازك',
      perfSection: 'ملف توزيع طاقة المعالج',
      perfDesc: 'تحديد مستويات تبريد Snapdragon ومعدلات الاستهلاك',
      balanced: 'متوازن (Balanced)',
      performance: 'الأداء الفائق (Performance)',
      wildboost: 'بركان شاومي (WildBoost Ultra)',
      uiSection: 'مظهر واجهة المستخدم',
      uiDesc: 'تخصيص مستويات سطوع وتناسق تباين الألوان',
      nightLabel: 'سواد شاشات OLED المطلق',
      nightDesc: 'إطفاء البكسلات السوداء تماماً لتقليص انبعاث الضوء وهدر الطاقة',
      resetSection: 'الصيانة وإعادة التعيين',
      resetDesc: 'إلغاء التهيئة المخصصة وإرجاع ملفات التعريف للحالة الافتراضية',
      resetBtn: 'إعادة ضبط المصنع الافتراضي',
      infoSection: 'تفاصيل ومواصفات عتاد الجهاز الحقيقي',
      infoDesc: 'قراءة مواصفات الهاتف المتصل عبر Android System Bridge',
      model: 'طراز الهاتف:',
      brand: 'العلامة التجارية:',
      os: 'إصدار الأندرويد:',
      sdk: 'مستوى واجهة API:',
      soc: 'وحدة المعالجة المركزية (SoC):',
      saveSuccess: 'تمت المزامنة وحفظ الخيارات بنجاح!'
    },
    en: {
      title: 'Advanced Settings Panel',
      subtitle: 'Modify hardware profiles, language toggles, and visual system states',
      perfSection: 'Processor Performance Profile',
      perfDesc: 'Configure thermal thresholds and core clock speed caps',
      balanced: 'Balanced Profile',
      performance: 'Performance Mode',
      wildboost: 'WildBoost Ultra Overclock',
      uiSection: 'Display Style Configuration',
      uiDesc: 'Tailor UI color depth, lighting levels, and screen appearance',
      nightLabel: 'OLED Pure Pitch Black',
      nightDesc: 'Turn off dark pixels entirely for true infinite contrast and maximum battery life',
      resetSection: 'Maintenance & Diagnostics',
      resetDesc: 'Clear local state variables and restore software parameter defaults',
      resetBtn: 'Reset to Factory Defaults',
      infoSection: 'Native Device Hardware Specifications',
      infoDesc: 'Read internal hardware identifiers linked through Android System Bridge',
      model: 'Device Model:',
      brand: 'Manufacturer Brand:',
      os: 'Android OS Version:',
      sdk: 'API SDK Level:',
      soc: 'Central Processing Unit (SoC):',
      saveSuccess: 'Configurations saved and synced with hardware!'
    }
  }[lang === 'en' ? 'en' : 'ar'];

  return (
    <div className="bg-neutral-900/90 border border-neutral-800 rounded-2xl p-6 space-y-6 animate-fade-in" id="settings-card">
      {/* Header */}
      <div className="border-b border-neutral-800 pb-3 flex items-center justify-between">
        <div>
          <h2 className="text-md font-black text-neutral-100 flex items-center gap-2">
            <Sliders className="w-5 h-5 text-amber-500 animate-pulse" />
            {t.title}
          </h2>
          <p className="text-xs text-neutral-400 mt-1">{t.subtitle}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Profile Performance settings */}
        <div className="space-y-6">
          {/* Performance Profiles */}
          <div className="bg-neutral-950 p-4 rounded-xl border border-neutral-850 space-y-3">
            <h3 className="text-xs font-bold text-neutral-200 flex items-center gap-2">
              <Cpu className="w-4 h-4 text-amber-500" />
              {t.perfSection}
            </h3>
            <p className="text-[10px] text-neutral-500">{t.perfDesc}</p>
            <div className="grid grid-cols-1 gap-2 pt-1">
              {[
                { id: 'balanced', name: t.balanced, color: 'border-amber-500/20 text-neutral-400', activeColor: 'bg-amber-950/20 border-amber-500 text-amber-400' },
                { id: 'performance', name: t.performance, color: 'border-red-500/20 text-neutral-400', activeColor: 'bg-red-950/20 border-red-500 text-red-400' },
                { id: 'ultraBoost', name: t.wildboost, color: 'border-purple-500/20 text-neutral-400', activeColor: 'bg-purple-950/20 border-purple-500 text-purple-400 font-extrabold' }
              ].map((m) => {
                const isActive = perfMode === m.id;
                return (
                  <button
                    key={m.id}
                    onClick={() => handlePerfModeChange(m.id)}
                    className={`w-full text-right p-3 rounded-lg border text-xs font-semibold transition-all cursor-pointer flex items-center justify-between ${
                      isActive ? m.activeColor : `bg-neutral-900/30 border-neutral-800 hover:bg-neutral-900 ${m.color}`
                    }`}
                  >
                    <span className="font-mono text-[9px] uppercase opacity-60">[{m.id}]</span>
                    <span>{m.name}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Night Mode OLED Toggle & Language Option */}
          <div className="bg-neutral-950 p-4 rounded-xl border border-neutral-850 space-y-4">
            <h3 className="text-xs font-bold text-neutral-200 flex items-center gap-2">
              <Moon className="w-4 h-4 text-cyan-400" />
              {t.uiSection}
            </h3>
            <p className="text-[10px] text-neutral-500">{t.uiDesc}</p>

            <div className="flex items-center justify-between pt-1 border-t border-neutral-900/80 pt-2.5">
              <div>
                <h4 className="text-xs font-semibold text-neutral-300">{t.nightLabel}</h4>
                <p className="text-[9px] text-neutral-500 max-w-[220px]">{t.nightDesc}</p>
              </div>
              <button
                onClick={handleNightModeToggle}
                className={`px-3 py-1.5 rounded-lg border text-xs font-bold transition-all cursor-pointer ${
                  nightMode 
                    ? 'bg-cyan-950/30 border-cyan-500/50 text-cyan-400 shadow shadow-cyan-500/10' 
                    : 'bg-neutral-900 border-neutral-800 text-neutral-500'
                }`}
              >
                {nightMode ? (lang === 'ar' ? 'نشط' : 'Active') : (lang === 'ar' ? 'معطل' : 'Disabled')}
              </button>
            </div>

            {/* Language Selection inside settings directly */}
            <div className="flex items-center justify-between pt-2.5 border-t border-neutral-900/80">
              <div>
                <h4 className="text-xs font-semibold text-neutral-300">{lang === 'ar' ? 'لغة واجهة لوحة التحكم' : 'Control Center Vocabulary'}</h4>
                <p className="text-[9px] text-neutral-500">{lang === 'ar' ? 'تغيير اللغة بين العربية والإنجليزية' : 'Toggle language parameters'}</p>
              </div>
              <div className="flex gap-1">
                <button
                  onClick={() => { setLang('ar'); localStorage.setItem('lang', 'ar'); }}
                  className={`px-2.5 py-1 text-[10px] font-bold rounded-lg border transition-all cursor-pointer ${
                    lang === 'ar' ? 'bg-amber-500/20 border-amber-500 text-amber-400' : 'bg-neutral-900 border-neutral-800 text-neutral-500'
                  }`}
                >
                  عربي
                </button>
                <button
                  onClick={() => { setLang('en'); localStorage.setItem('lang', 'en'); }}
                  className={`px-2.5 py-1 text-[10px] font-bold rounded-lg border transition-all cursor-pointer ${
                    lang === 'en' ? 'bg-amber-500/20 border-amber-500 text-amber-400' : 'bg-neutral-900 border-neutral-800 text-neutral-500'
                  }`}
                >
                  EN
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Device Information & Reset Option */}
        <div className="space-y-6">
          {/* Hardware Specs info */}
          <div className="bg-neutral-950 p-4 rounded-xl border border-neutral-850 space-y-3">
            <h3 className="text-xs font-bold text-neutral-200 flex items-center gap-2">
              <Smartphone className="w-4 h-4 text-purple-400" />
              {t.infoSection}
            </h3>
            <p className="text-[10px] text-neutral-500">{t.infoDesc}</p>
            
            <div className="space-y-2.5 pt-1 text-xs">
              <div className="bg-neutral-900/60 p-2.5 rounded-lg border border-neutral-850 flex items-center justify-between">
                <span className="text-neutral-500 font-mono text-[10px]">{t.brand}</span>
                <span className="font-bold text-neutral-200">{deviceInfo.brand}</span>
              </div>
              <div className="bg-neutral-900/60 p-2.5 rounded-lg border border-neutral-850 flex items-center justify-between">
                <span className="text-neutral-500 font-mono text-[10px]">{t.model}</span>
                <span className="font-bold text-neutral-200">{deviceInfo.model}</span>
              </div>
              <div className="bg-neutral-900/60 p-2.5 rounded-lg border border-neutral-850 flex items-center justify-between">
                <span className="text-neutral-500 font-mono text-[10px]">{t.os}</span>
                <span className="font-bold text-emerald-400">{deviceInfo.androidVersion}</span>
              </div>
              <div className="bg-neutral-900/60 p-2.5 rounded-lg border border-neutral-850 flex items-center justify-between">
                <span className="text-neutral-500 font-mono text-[10px]">{t.sdk}</span>
                <span className="font-bold text-cyan-400 font-mono">{deviceInfo.sdkVersion}</span>
              </div>
              <div className="bg-neutral-900/60 p-2.5 rounded-lg border border-neutral-850 flex items-center justify-between">
                <span className="text-neutral-500 font-mono text-[10px]">{t.soc}</span>
                <span className="font-mono text-purple-400 font-semibold">{deviceInfo.processor}</span>
              </div>
            </div>
          </div>

          {/* Reset button card */}
          <div className="bg-neutral-950 p-4 rounded-xl border border-neutral-850 space-y-3">
            <h3 className="text-xs font-bold text-neutral-200 flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-red-500 animate-pulse" />
              {t.resetSection}
            </h3>
            <p className="text-[10px] text-neutral-500">{t.resetDesc}</p>
            <button
              onClick={handleResetSettings}
              className="w-full bg-red-950/20 hover:bg-red-950/45 border border-red-500/30 hover:border-red-500/50 text-red-400 py-3 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-2 shadow"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>{t.resetBtn}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
