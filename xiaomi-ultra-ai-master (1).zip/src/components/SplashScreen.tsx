import React, { useState, useEffect } from 'react';
import { Cpu, ShieldCheck, Sparkles, Activity } from 'lucide-react';

interface SplashScreenProps {
  onComplete: () => void;
  lang: 'ar' | 'en';
}

export default function SplashScreen({ onComplete, lang }: SplashScreenProps) {
  const [progress, setProgress] = useState(0);
  const [statusText, setStatusText] = useState('');

  const t = {
    ar: {
      initializing: 'جاري تهيئة قنوات النظام الفائقة...',
      loadingHardware: 'قراءة مواصفات عتاد Xiaomi Ultra المتصل...',
      calibratingSensors: 'معايرة مستشعرات الحركة والاهتزاز Leica...',
      securingThreads: 'تأمين خيوط المعالجة ومراقبة الخلفية...',
      ready: 'النظام جاهز للتشغيل!',
      modelBadge: 'فئة الأداء الفائق 17 Ultra',
      coprocessor: 'نظام المعالجة الذكي للعلامة التجارية',
    },
    en: {
      initializing: 'Initializing supercomputing channels...',
      loadingHardware: 'Querying Xiaomi Ultra native hardware specifications...',
      calibratingSensors: 'Calibrating Leica gyro and motion sensors...',
      securingThreads: 'Securing thread pools and background monitoring...',
      ready: 'System fully synchronized!',
      modelBadge: '17 Ultra Flagship Core',
      coprocessor: 'Intelligent System Coprocessor',
    }
  }[lang === 'en' ? 'en' : 'ar'];

  useEffect(() => {
    // Elegant, fast loading progress
    const steps = [
      { prg: 15, text: t.initializing },
      { prg: 45, text: t.loadingHardware },
      { prg: 70, text: t.calibratingSensors },
      { prg: 90, text: t.securingThreads },
      { prg: 100, text: t.ready }
    ];

    let currentStep = 0;
    setStatusText(steps[0].text);

    const interval = setInterval(() => {
      setProgress((prev) => {
        const next = prev + 1.5;
        
        // Update status text based on progress
        const matchedStep = steps.find(s => next >= s.prg && s.prg > (steps[currentStep]?.prg || 0));
        if (matchedStep) {
          const matchedIdx = steps.indexOf(matchedStep);
          if (matchedIdx > currentStep) {
            currentStep = matchedIdx;
            setStatusText(matchedStep.text);
          }
        }

        if (next >= 100) {
          clearInterval(interval);
          setTimeout(() => {
            onComplete();
          }, 300); // Small pause at 100% for aesthetic pacing
          return 100;
        }
        return next;
      });
    }, 25); // ~1.6 seconds total animation for realistic, high-speed premium feel

    return () => clearInterval(interval);
  }, [onComplete, t]);

  return (
    <div className="fixed inset-0 bg-neutral-950 text-neutral-100 flex flex-col items-center justify-between p-8 font-sans antialiased z-50 overflow-hidden select-none">
      {/* Absolute ambient lights */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 h-80 bg-amber-500/10 rounded-full blur-[120px] pointer-events-none animate-pulse"></div>
      <div className="absolute bottom-10 left-10 w-48 h-48 bg-red-500/5 rounded-full blur-[100px] pointer-events-none"></div>

      {/* Empty spacer for alignment */}
      <div></div>

      {/* Center Branded Logo & Subtitle */}
      <div className="flex flex-col items-center justify-center text-center space-y-6 max-w-sm">
        {/* Animated Brand Emblem */}
        <div className="relative group">
          {/* External glowing ring */}
          <div className="absolute inset-0 bg-gradient-to-tr from-amber-500 to-amber-600 rounded-3xl blur-xl opacity-30 animate-pulse"></div>
          
          {/* Main shield */}
          <div className="relative bg-neutral-900 border border-neutral-800 rounded-3xl p-5 shadow-2xl flex items-center justify-center">
            <Cpu className="w-12 h-12 text-amber-500 animate-spin-slow" />
            <div className="absolute -top-1 -right-1 bg-amber-500 text-neutral-950 p-1 rounded-lg border border-neutral-900 shadow-md">
              <ShieldCheck className="w-4 h-4 font-bold" />
            </div>
          </div>
        </div>

        {/* Brand Text */}
        <div className="space-y-1">
          <h1 className="text-xl font-black tracking-tight text-neutral-100 flex items-center justify-center gap-2">
            XIAOMI
            <span className="text-amber-500 bg-amber-500/10 border border-amber-500/30 px-2 py-0.5 rounded-md text-[10px] font-mono tracking-widest font-black">
              ULTRA AI
            </span>
          </h1>
          <p className="text-xs font-bold text-neutral-400 font-mono tracking-widest uppercase opacity-75">
            Master HUD Suite
          </p>
        </div>
      </div>

      {/* Loading Progression and Bottom Brand Indicators */}
      <div className="w-full max-w-xs space-y-6">
        {/* Progress Bar & Status Text */}
        <div className="space-y-3">
          <div className="flex items-center justify-between text-[10px] font-semibold text-neutral-400">
            <span className="font-mono text-amber-500/90">{progress.toFixed(0)}%</span>
            <span className="font-mono flex items-center gap-1">
              <Activity className="w-3 h-3 text-amber-500 animate-pulse" />
              {t.coprocessor}
            </span>
          </div>

          {/* Glowing track */}
          <div className="h-[3px] bg-neutral-900 rounded-full overflow-hidden border border-neutral-900/40 relative">
            <div 
              className="h-full bg-gradient-to-r from-amber-500 to-amber-400 transition-all duration-75 rounded-full shadow-[0_0_8px_rgba(245,158,11,0.5)]"
              style={{ width: `${progress}%` }}
            ></div>
          </div>

          <p className="text-[10px] font-bold text-neutral-400 text-center animate-pulse h-4 truncate">
            {statusText}
          </p>
        </div>

        {/* Footer Brand Info */}
        <div className="flex flex-col items-center justify-center space-y-1.5 pt-4 border-t border-neutral-900/60">
          <span className="text-[9px] font-mono font-bold text-amber-500/60 uppercase tracking-widest">
            {t.modelBadge}
          </span>
          <span className="text-[8px] text-neutral-600 font-mono uppercase tracking-widest">
            Secure Android System Bridge
          </span>
        </div>
      </div>
    </div>
  );
}
