export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  timestamp: Date;
}

export interface GameProfile {
  id: string;
  name: string;
  genre: string;
  fpsTarget: 60 | 90 | 120 | 144;
  currentFps: number;
  gpuBoost: boolean;
  dndMode: boolean;
  temperatureLimit: number; // in Celsius
  isOptimized: boolean;
}

export interface CameraSetting {
  mode: 'leica-authentic' | 'leica-vibrant' | 'ai-portrait' | 'ultra-night' | 'raw-pro';
  aperture: number; // e.g. 1.4, 1.8, 2.0, 4.0
  hdrLevel: 'off' | 'auto' | 'max-ultra';
  stabilization: 'eis' | 'ois-pro' | 'hyper-steady';
  aiBeauty: number; // 0-100
  upscaleLevel: '1x' | '2x' | '4x-ultra-hd';
}

export interface SystemMetrics {
  cpuUsage: number; // %
  ramTotal: number; // GB
  ramUsed: number; // GB
  temperature: number; // °C
  batteryLevel: number; // %
  batteryHealth: 'Excellent' | 'Good' | 'Service Required';
  storageTotal: number; // GB
  storageUsed: number; // GB
  signalStrength: number; // dBm or percentage
}
